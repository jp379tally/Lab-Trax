import { Router } from "express";
import { and, desc, eq, gte, lte, or, sum } from "drizzle-orm";
import { z } from "zod";
import { db } from "../db";
import {
  caseEvents,
  caseRestorations,
  cases,
  invoiceLineItems,
  invoices,
  organizationMemberships,
  payments,
} from "../../shared/schema";
import { writeAuditLog } from "../lib/audit";
import { calculateLineTotal, sumMoney } from "../lib/case";
import { HttpError, ok } from "../lib/http";
import { BILLING_ROLES, requireAnyRole, requireMembership } from "../lib/rbac";
import { asyncHandler } from "../middleware/async-handler";
import { requireAuth } from "../middleware/auth";

const router = Router();
router.use(requireAuth);

function nextInvoiceNumber(caseNumber: string) {
  return `INV-${caseNumber}`;
}

router.post(
  "/cases/:caseId/generate-invoice",
  asyncHandler(async (req, res) => {
    const found = await db.query.cases.findFirst({
      where: eq(cases.id, req.params.caseId),
    });
    if (!found) throw new HttpError(404, "Case not found.");
    await requireAnyRole(
      (req as any).auth.userId,
      found.labOrganizationId,
      BILLING_ROLES
    );

    const restorations = await db.query.caseRestorations.findMany({
      where: eq(caseRestorations.caseId, found.id),
    });
    if (!restorations.length)
      throw new HttpError(
        400,
        "Cannot generate an invoice with no restorations."
      );

    const [invoice] = await db
      .insert(invoices)
      .values({
        invoiceNumber: nextInvoiceNumber(found.caseNumber),
        caseId: found.id,
        labOrganizationId: found.labOrganizationId,
        providerOrganizationId: found.providerOrganizationId,
        status: "draft",
        createdByUserId: (req as any).auth.userId,
        updatedByUserId: (req as any).auth.userId,
      })
      .onConflictDoNothing()
      .returning();

    const targetInvoice =
      invoice ??
      (await db.query.invoices.findFirst({
        where: eq(
          invoices.invoiceNumber,
          nextInvoiceNumber(found.caseNumber)
        ),
      }));
    if (!targetInvoice)
      throw new HttpError(500, "Invoice could not be generated.");

    if (invoice) {
      const itemsToInsert = restorations.map((restoration, index) => ({
        invoiceId: targetInvoice.id,
        caseRestorationId: restoration.id,
        description: `${restoration.restorationType} - Tooth ${restoration.toothNumber}`,
        quantity: restoration.quantity,
        unitPrice: restoration.unitPrice,
        lineTotal: calculateLineTotal(
          restoration.quantity,
          restoration.unitPrice
        ),
        sortOrder: index,
      }));
      await db.insert(invoiceLineItems).values(itemsToInsert);
    }

    const items = await db.query.invoiceLineItems.findMany({
      where: eq(invoiceLineItems.invoiceId, targetInvoice.id),
      orderBy: [invoiceLineItems.sortOrder],
    });
    const subtotal = sumMoney(items.map((item) => item.lineTotal));

    const [updatedInvoice] = await db
      .update(invoices)
      .set({
        subtotal,
        total: subtotal,
        balanceDue: subtotal,
        updatedByUserId: (req as any).auth.userId,
        issuedAt: new Date(),
        status: "open",
      })
      .where(eq(invoices.id, targetInvoice.id))
      .returning();

    const user = (req as any).user;
    await db.insert(caseEvents).values({
      caseId: found.id,
      eventType: "invoice_generated",
      actorUserId: (req as any).auth.userId,
      actorOrganizationId: found.labOrganizationId,
      actorInitials: user?.initials || "SYS",
      metadataJson: {
        invoiceId: updatedInvoice.id,
        invoiceNumber: updatedInvoice.invoiceNumber,
      },
    });

    return ok(res, updatedInvoice, invoice ? 201 : 200);
  })
);

router.get(
  "/",
  asyncHandler(async (req, res) => {
    const memberships =
      await db.query.organizationMemberships.findMany({
        where: eq(
          organizationMemberships.userId,
          (req as any).auth.userId
        ),
      });
    const orgIds = memberships
      .filter((m: any) => m.status === "active")
      .map((m: any) => m.organizationId);

    const rows = orgIds.length
      ? await db.query.invoices.findMany({
          where: or(
            ...orgIds.flatMap((orgId: string) => [
              eq(invoices.labOrganizationId, orgId),
              eq(invoices.providerOrganizationId, orgId),
            ])
          ),
          orderBy: [desc(invoices.createdAt)],
        })
      : [];

    return ok(res, rows);
  })
);

router.get(
  "/:invoiceId",
  asyncHandler(async (req, res) => {
    const invoice = await db.query.invoices.findFirst({
      where: eq(invoices.id, req.params.invoiceId),
    });
    if (!invoice) throw new HttpError(404, "Invoice not found.");

    const labMember = await requireMembership(
      (req as any).auth.userId,
      invoice.labOrganizationId
    ).catch(() => null);
    const providerMember = await requireMembership(
      (req as any).auth.userId,
      invoice.providerOrganizationId
    ).catch(() => null);
    if (!labMember && !providerMember)
      throw new HttpError(403, "You do not have access to this invoice.");

    const items = await db.query.invoiceLineItems.findMany({
      where: eq(invoiceLineItems.invoiceId, invoice.id),
      orderBy: [invoiceLineItems.sortOrder],
    });
    const paymentRows = await db.query.payments.findMany({
      where: eq(payments.invoiceId, invoice.id),
      orderBy: [desc(payments.paidAt)],
    });
    return ok(res, { ...invoice, items, payments: paymentRows });
  })
);

router.patch(
  "/:invoiceId",
  asyncHandler(async (req, res) => {
    const invoice = await db.query.invoices.findFirst({
      where: eq(invoices.id, req.params.invoiceId),
    });
    if (!invoice) throw new HttpError(404, "Invoice not found.");
    await requireAnyRole(
      (req as any).auth.userId,
      invoice.labOrganizationId,
      BILLING_ROLES
    );

    const input = z
      .object({
        status: z
          .enum(["draft", "open", "partially_paid", "paid", "void"])
          .optional(),
        tax: z.coerce.number().min(0).optional(),
        discount: z.coerce.number().min(0).optional(),
        dueAt: z.string().datetime().optional(),
      })
      .parse(req.body);

    const items = await db.query.invoiceLineItems.findMany({
      where: eq(invoiceLineItems.invoiceId, invoice.id),
    });
    const subtotal = sumMoney(items.map((item) => item.lineTotal));
    const tax =
      input.tax !== undefined ? input.tax.toFixed(2) : invoice.tax;
    const discount =
      input.discount !== undefined
        ? input.discount.toFixed(2)
        : invoice.discount;
    const total = (
      Number(subtotal) +
      Number(tax) -
      Number(discount)
    ).toFixed(2);

    const paidSum = await db
      .select({ value: sum(payments.amount) })
      .from(payments)
      .where(eq(payments.invoiceId, invoice.id));
    const paid = Number(paidSum[0]?.value ?? 0);
    const balanceDue = (Number(total) - paid).toFixed(2);

    const [updated] = await db
      .update(invoices)
      .set({
        status: input.status ?? invoice.status,
        tax,
        discount,
        total,
        balanceDue,
        dueAt: input.dueAt ? new Date(input.dueAt) : invoice.dueAt,
        updatedByUserId: (req as any).auth.userId,
      })
      .where(eq(invoices.id, invoice.id))
      .returning();

    await writeAuditLog({
      req,
      organizationId: invoice.labOrganizationId,
      action: "invoice_updated",
      entityType: "invoice",
      entityId: invoice.id,
      beforeJson: invoice,
      afterJson: updated,
    });
    return ok(res, updated);
  })
);

router.post(
  "/:invoiceId/payments",
  asyncHandler(async (req, res) => {
    const invoice = await db.query.invoices.findFirst({
      where: eq(invoices.id, req.params.invoiceId),
    });
    if (!invoice) throw new HttpError(404, "Invoice not found.");
    await requireAnyRole(
      (req as any).auth.userId,
      invoice.labOrganizationId,
      BILLING_ROLES
    );

    const input = z
      .object({
        amount: z.coerce.number().positive(),
        paymentMethod: z.enum(["card", "ach", "check", "cash", "other"]),
        referenceNumber: z.string().optional(),
      })
      .parse(req.body);

    const [payment] = await db
      .insert(payments)
      .values({
        invoiceId: invoice.id,
        amount: input.amount.toFixed(2),
        paymentMethod: input.paymentMethod,
        referenceNumber: input.referenceNumber ?? null,
        recordedByUserId: (req as any).auth.userId,
      })
      .returning();

    const paidRows = await db
      .select({ value: sum(payments.amount) })
      .from(payments)
      .where(eq(payments.invoiceId, invoice.id));
    const paid = Number(paidRows[0]?.value ?? 0);
    const balanceDue = Math.max(
      Number(invoice.total) - paid,
      0
    ).toFixed(2);
    const status =
      balanceDue === "0.00"
        ? "paid"
        : paid > 0
        ? "partially_paid"
        : invoice.status;

    const [updatedInvoice] = await db
      .update(invoices)
      .set({
        balanceDue,
        status,
        updatedByUserId: (req as any).auth.userId,
      })
      .where(eq(invoices.id, invoice.id))
      .returning();

    if (invoice.caseId) {
      const user = (req as any).user;
      await db.insert(caseEvents).values({
        caseId: invoice.caseId,
        eventType: "payment_received",
        actorUserId: (req as any).auth.userId,
        actorOrganizationId: invoice.labOrganizationId,
        actorInitials: user?.initials || "SYS",
        metadataJson: {
          invoiceId: invoice.id,
          paymentId: payment.id,
          amount: payment.amount,
        },
      });
    }

    return ok(res, { payment, invoice: updatedInvoice }, 201);
  })
);

router.get(
  "/reports/sales",
  asyncHandler(async (req, res) => {
    const query = z
      .object({
        organizationId: z.string(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      })
      .parse(req.query);

    await requireAnyRole(
      (req as any).auth.userId,
      query.organizationId,
      BILLING_ROLES
    );

    const rows = await db.query.invoices.findMany({
      where: and(
        eq(invoices.labOrganizationId, query.organizationId),
        query.dateFrom
          ? gte(invoices.createdAt, new Date(query.dateFrom))
          : undefined,
        query.dateTo
          ? lte(invoices.createdAt, new Date(query.dateTo))
          : undefined
      ),
    });

    const totalSales = rows
      .reduce((acc, row) => acc + Number(row.total), 0)
      .toFixed(2);
    const openBalance = rows
      .reduce((acc, row) => acc + Number(row.balanceDue), 0)
      .toFixed(2);

    return ok(res, {
      totalSales,
      openBalance,
      invoices: rows.length,
      paidInvoices: rows.filter((row) => row.status === "paid").length,
      openInvoices: rows.filter(
        (row) => row.status !== "paid" && row.status !== "void"
      ).length,
    });
  })
);

export default router;
