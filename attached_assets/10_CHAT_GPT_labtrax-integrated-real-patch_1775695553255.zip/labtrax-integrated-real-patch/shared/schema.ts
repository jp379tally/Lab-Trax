import { sql } from "drizzle-orm";
import { pgTable, text, varchar, boolean, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password"),
  passwordHash: text("password_hash"),
  email: text("email"),
  phone: text("phone"),
  userType: text("user_type").default("lab"),
  role: text("role").default("user"),
  licenseNumber: text("license_number"),
  practiceName: text("practice_name"),
  doctorName: text("doctor_name"),
  practiceAddress: text("practice_address"),
  practicePhone: text("practice_phone"),
  phoneContactName: text("phone_contact_name"),
  accountNumber: text("account_number"),
  wantsUpdates: boolean("wants_updates").default(false),
  primaryOrganizationId: varchar("primary_organization_id"),
  affiliationStatus: text("affiliation_status").default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(),
  name: text("name").notNull(),
  normalizedName: text("normalized_name").notNull(),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  createdByUserId: varchar("created_by_user_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  normalizedNameIdx: uniqueIndex("organizations_normalized_name_idx").on(table.normalizedName),
}));

export const organizationMemberships = pgTable("organization_memberships", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull(),
  userId: varchar("user_id").notNull(),
  role: text("role").notNull().default("user"),
  status: text("status").notNull().default("active"),
  invitedByUserId: varchar("invited_by_user_id"),
  approvedByUserId: varchar("approved_by_user_id"),
  createdAt: timestamp("created_at").defaultNow(),
}, (table) => ({
  uniqueMembership: uniqueIndex("org_memberships_unique_user_org_idx").on(table.organizationId, table.userId),
}));

export const organizationJoinRequests = pgTable("organization_join_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull(),
  requestingUserId: varchar("requesting_user_id").notNull(),
  targetAdminUsername: text("target_admin_username"),
  requestedRole: text("requested_role").notNull().default("user"),
  message: text("message"),
  status: text("status").notNull().default("pending"),
  reviewedByUserId: varchar("reviewed_by_user_id"),
  reviewedAt: timestamp("reviewed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const organizationInvites = pgTable("organization_invites", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  organizationId: varchar("organization_id").notNull(),
  adminUserId: varchar("admin_user_id").notNull(),
  targetUserId: varchar("target_user_id"),
  targetUsername: text("target_username").notNull(),
  targetEmail: text("target_email"),
  role: text("role").notNull().default("user"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const labCases = pgTable("lab_cases", {
  id: varchar("id").primaryKey(),
  ownerId: varchar("owner_id").notNull(),
  organizationId: varchar("organization_id"),
  providerOrganizationId: varchar("provider_organization_id"),
  caseData: text("case_data").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({ username: true, password: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type LabCaseRow = typeof labCases.$inferSelect;
