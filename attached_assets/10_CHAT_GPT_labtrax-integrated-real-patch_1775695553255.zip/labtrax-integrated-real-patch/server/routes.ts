import type { Express } from "express";
import { createServer, type Server } from "node:http";
import OpenAI from "openai";
import nodemailer from "nodemailer";
import sharp from "sharp";
import { storage } from "./storage";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

function normalizeRole(role?: string | null): "admin" | "user" {
  return role === "admin" ? "admin" : "user";
}

const DEFAULT_USERS = [
  { username: "admin", password: "123", userType: "lab", role: "admin", practiceName: "Southern Dental Restoration" },
  { username: "tech", password: "tech123", userType: "lab", role: "user", practiceName: "Southern Dental Restoration" },
  { username: "JPPhillips", password: "Master1!", email: "john.phillips3@yahoo.com", phone: "850-363-3336", userType: "master_admin", role: "admin", accountNumber: "MA-001" },
];

async function seedDefaultUsers() {
  for (const def of DEFAULT_USERS) {
    const existing = await storage.getUserByUsername(def.username);
    if (!existing) {
      const user = await storage.createUser(def as any);
      if (def.practiceName && def.userType === "lab") {
        let org = await storage.getOrganizationByName("lab", def.practiceName);
        if (!org) {
          org = await storage.createOrganization({ type: "lab", name: def.practiceName, createdByUserId: user.id });
        }
        await storage.createMembership({ organizationId: org.id, userId: user.id, role: def.role === "admin" ? "owner" : "user", status: "active" });
        await storage.updateUser(user.id, { primaryOrganizationId: org.id, practiceName: org.name, affiliationStatus: "active", role: def.role as any });
      }
      console.log(`[SEED] Created default user: ${def.username}`);
    }
  }
}

function shapeUser(user: any) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    phone: user.phone,
    userType: user.userType,
    role: user.role,
    licenseNumber: user.licenseNumber,
    practiceName: user.practiceName,
    doctorName: user.doctorName,
    practiceAddress: user.practiceAddress,
    practicePhone: user.practicePhone,
    phoneContactName: user.phoneContactName,
    accountNumber: user.accountNumber,
    primaryOrganizationId: user.primaryOrganizationId || null,
    affiliationStatus: user.affiliationStatus || "active",
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  await seedDefaultUsers();

  app.get("/api/health", (_req, res) => {
    res.status(200).json({ ok: true, timestamp: new Date().toISOString() });
  });

  app.post("/api/check-username", async (req, res) => {
    const { username } = req.body;
    if (!username || typeof username !== "string") return res.status(400).json({ error: "Username required" });
    const existing = await storage.getUserByUsername(username.trim());
    res.json({ available: !existing });
  });

  app.get("/api/labs/groups", async (_req, res) => {
    const groups = await storage.listLabGroups();
    res.json({ groups });
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password, email, phone, userType, role, licenseNumber, practiceName, doctorName, practiceAddress, practicePhone, phoneContactName, accountNumber, wantsUpdates } = req.body;
      if (!username || !password) return res.status(400).json({ error: "Username and password required" });
      const existing = await storage.getUserByUsername(username.trim());
      if (existing) return res.status(409).json({ error: "Username already taken." });
      if (email) {
        const existingEmail = await storage.getUserByEmail(email.trim());
        if (existingEmail) return res.status(409).json({ error: "An account with this email already exists." });
      }

      const effectiveUserType = userType || "lab";
      const requestedRole = normalizeRole(role);
      const user = await storage.createUser({
        username: username.trim(),
        password,
        email: email || null,
        phone: phone || null,
        userType: effectiveUserType,
        role: requestedRole,
        licenseNumber: licenseNumber || null,
        practiceName: practiceName || null,
        doctorName: doctorName || null,
        practiceAddress: practiceAddress || null,
        practicePhone: practicePhone || null,
        phoneContactName: phoneContactName || null,
        accountNumber: accountNumber || null,
        wantsUpdates: wantsUpdates || false,
      });

      let responseMessage = "Account created.";
      let pendingJoinRequest = false;
      let organization = null as any;
      const requestedOrgName = (practiceName || "").trim();
      if ((effectiveUserType === "lab" || effectiveUserType === "provider") && requestedOrgName) {
        const orgType = effectiveUserType === "provider" ? "provider" : "lab";
        let org = await storage.getOrganizationByName(orgType as any, requestedOrgName);
        if (!org) {
          org = await storage.createOrganization({ type: orgType as any, name: requestedOrgName, address: practiceAddress || null, phone: practicePhone || null, email: email || null, createdByUserId: user.id });
          await storage.createMembership({ organizationId: org.id, userId: user.id, role: "owner", status: "active" });
          await storage.updateUser(user.id, { primaryOrganizationId: org.id, practiceName: org.name, affiliationStatus: "active", role: "admin" });
          organization = org;
          responseMessage = `${org.name} created and linked to your account.`;
        } else if (requestedRole === "admin") {
          await storage.createJoinRequest({ organizationId: org.id, requestingUserId: user.id, requestedRole: "admin", message: `${user.username} requested admin access to ${org.name}.` });
          await storage.updateUser(user.id, { primaryOrganizationId: org.id, practiceName: org.name, affiliationStatus: "pending" });
          organization = org;
          pendingJoinRequest = true;
          responseMessage = `Your request to join ${org.name} as admin is pending approval.`;
        } else {
          await storage.createJoinRequest({ organizationId: org.id, requestingUserId: user.id, requestedRole: "user", message: `${user.username} would like to join ${org.name}.` });
          await storage.updateUser(user.id, { primaryOrganizationId: org.id, practiceName: org.name, affiliationStatus: "pending" });
          organization = org;
          pendingJoinRequest = true;
          responseMessage = `Your request to join ${org.name} has been sent to the lab admin.`;
        }
      }

      const freshUser = (await storage.getUser(user.id)) || user;
      res.json({ success: true, user: shapeUser(freshUser), organization, pendingJoinRequest, message: responseMessage });
    } catch (error: any) {
      console.error("Registration error:", error?.message || error);
      res.status(500).json({ error: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) return res.status(400).json({ error: "Username and password required" });
      const user = await storage.verifyUser(username.trim(), password);
      if (!user) return res.status(401).json({ error: "Invalid username or password." });
      const memberships = await storage.getMembershipsByUserId(user.id);
      res.json({ success: true, user: shapeUser(user), memberships: memberships.map(m => ({ organizationId: m.organizationId, organizationName: m.organization?.name || "", organizationType: m.organization?.type || user.userType, role: m.role, status: m.status })) });
    } catch (error: any) {
      console.error("Login error:", error?.message || error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    const username = (req.query.username as string) || (req.headers["x-username"] as string) || "";
    if (!username) return res.status(400).json({ error: "username required" });
    const user = await storage.getUserByUsername(username);
    if (!user) return res.status(404).json({ error: "User not found" });
    const memberships = await storage.getMembershipsByUserId(user.id);
    res.json({ user: shapeUser(user), memberships: memberships.map(m => ({ organizationId: m.organizationId, organizationName: m.organization?.name || "", organizationType: m.organization?.type || user.userType, role: m.role, status: m.status })) });
  });

  app.get("/api/auth/users", async (_req, res) => {
    try {
      const allUsers = await storage.getPublicUsers();
      res.json({ users: allUsers });
    } catch (error: any) {
      console.error("Get users error:", error?.message || error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/labs/join-requests", async (req, res) => {
    const adminUsername = (req.query.adminUsername as string) || "";
    const admin = await storage.getUserByUsername(adminUsername);
    if (!admin) return res.json({ requests: [] });
    const requests = await storage.listJoinRequestsForAdmin(admin.id);
    res.json({ requests });
  });

  app.post("/api/labs/join-requests/:id/respond", async (req, res) => {
    const { id } = req.params;
    const { adminUsername, accept, role } = req.body;
    const admin = await storage.getUserByUsername(adminUsername);
    if (!admin) return res.status(404).json({ error: "Admin not found" });
    const result = await storage.respondToJoinRequest(id, admin.id, !!accept, normalizeRole(role));
    if (!result.success) return res.status(400).json(result);
    res.json({ success: true });
  });

  app.get("/api/labs/invites", async (req, res) => {
    const username = (req.query.username as string) || "";
    const user = await storage.getUserByUsername(username);
    if (!user) return res.json({ invites: [] });
    const invites = await storage.listInvitesForUser(user.id, user.username);
    res.json({ invites });
  });

  app.post("/api/labs/invites", async (req, res) => {
    const { adminUsername, targetUsername, targetEmail, role } = req.body;
    const admin = await storage.getUserByUsername(adminUsername);
    const target = await storage.getUserByUsername(targetUsername);
    if (!admin || !target) return res.status(404).json({ error: "User not found" });
    if (!admin.primaryOrganizationId) return res.status(400).json({ error: "Admin is not linked to a lab" });
    const invite = await storage.createInvite({ organizationId: admin.primaryOrganizationId, adminUserId: admin.id, targetUserId: target.id, targetUsername: target.username, targetEmail: targetEmail || target.email || null, role: normalizeRole(role) });
    res.json({ success: true, invite });
  });

  app.post("/api/labs/invites/:id/respond", async (req, res) => {
    const { id } = req.params;
    const { username, accept } = req.body;
    const user = await storage.getUserByUsername(username);
    if (!user) return res.status(404).json({ error: "User not found" });
    const result = await storage.respondToInvite(id, user.id, !!accept);
    if (!result.success) return res.status(400).json(result);
    res.json({ success: true });
  });

  app.post("/api/labs/leave", async (req, res) => {
    const { username } = req.body;
    const user = await storage.getUserByUsername(username);
    if (!user) return res.status(404).json({ error: "User not found" });
    const result = await storage.leaveOrganization(user.id);
    if (!result.success) return res.status(400).json(result);
    res.json({ success: true });
  });

  app.put("/api/auth/users/:id/profile", async (req, res) => {
    try {
      const { id } = req.params;
      const authUser = req.headers["x-user-id"] as string;
      if (!authUser || authUser !== id) return res.status(403).json({ error: "Unauthorized" });
      const user = await storage.getUser(id);
      if (!user) return res.status(404).json({ error: "User not found" });
      const { practiceName, practiceAddress, practicePhone, email, phone } = req.body;
      const updates: any = {};
      if (practiceName !== undefined) updates.practiceName = practiceName;
      if (practiceAddress !== undefined) updates.practiceAddress = practiceAddress;
      if (practicePhone !== undefined) updates.practicePhone = practicePhone;
      if (email !== undefined) updates.email = email;
      if (phone !== undefined) updates.phone = phone;
      const updated = await storage.updateUser(id, updates);
      res.json({ success: true, user: updated });
    } catch {
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  app.put("/api/auth/users/:id/password", async (req, res) => {
    try {
      const { id } = req.params;
      const { currentPassword, newPassword } = req.body;
      const user = await storage.getUser(id);
      if (!user) return res.status(404).json({ error: "User not found" });
      const verified = await storage.verifyUser(user.username, currentPassword);
      if (!verified) return res.status(401).json({ error: "Current password is incorrect" });
      await storage.updateUser(id, { passwordHash: null as any, password: newPassword as any });
      await storage.verifyUser(user.username, newPassword);
      res.json({ success: true });
    } catch {
      res.status(500).json({ error: "Failed to update password" });
    }
  });

  app.delete("/api/auth/users/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const authUser = req.headers["x-user-id"] as string;
      if (!authUser || authUser !== id) return res.status(403).json({ error: "You can only delete your own account." });
      const user = await storage.getUser(id);
      if (!user) return res.status(404).json({ error: "User not found" });
      const deleted = await storage.deleteUser(id);
      if (deleted) res.json({ success: true });
      else res.status(500).json({ error: "Failed to delete user" });
    } catch {
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  app.post("/api/cases", async (req, res) => {
    try {
      const { id, ownerId, caseData, organizationId } = req.body;
      if (!id || !ownerId || !caseData) return res.status(400).json({ error: "id, ownerId, and caseData are required" });
      await storage.upsertCase(id, ownerId, typeof caseData === "string" ? caseData : JSON.stringify(caseData), organizationId || null);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Upsert case error:", error?.message || error);
      res.status(500).json({ error: "Failed to save case" });
    }
  });

  app.put("/api/cases/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { ownerId, caseData, organizationId } = req.body;
      if (!caseData || !ownerId) return res.status(400).json({ error: "ownerId and caseData are required" });
      await storage.upsertCase(id, ownerId, typeof caseData === "string" ? caseData : JSON.stringify(caseData), organizationId || null);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Update case error:", error?.message || error);
      res.status(500).json({ error: "Failed to update case" });
    }
  });

  app.get("/api/cases", async (req, res) => {
    try {
      const ownerIdsParam = req.query.ownerIds as string;
      if (!ownerIdsParam) return res.json({ cases: [] });
      const ownerIds = ownerIdsParam.split(",").filter(Boolean);
      const rows = await storage.getCasesByOwnerIds(ownerIds);
      const cases = rows.map(r => { try { return JSON.parse(r.caseData); } catch { return null; } }).filter(Boolean);
      res.json({ cases });
    } catch (error: any) {
      console.error("Get cases error:", error?.message || error);
      res.status(500).json({ error: "Failed to fetch cases" });
    }
  });

  app.delete("/api/cases/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteCase(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Delete case error:", error?.message || error);
      res.status(500).json({ error: "Failed to delete case" });
    }
  });

  const server = createServer(app);
  return server;
}
