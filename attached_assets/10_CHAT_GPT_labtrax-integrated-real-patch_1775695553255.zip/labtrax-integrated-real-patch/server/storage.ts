import { type User, users, labCases, organizations, organizationMemberships, organizationJoinRequests, organizationInvites } from "../shared/schema";
import { db } from "./db";
import { and, eq, inArray, sql } from "drizzle-orm";
import crypto from "node:crypto";

function normalizeName(value?: string | null): string {
  return (value || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const derived = crypto.scryptSync(password, salt, 64).toString("hex");
  return `scrypt:${salt}:${derived}`;
}

function verifyHash(password: string, storedHash?: string | null): boolean {
  if (!storedHash || !storedHash.startsWith("scrypt:")) return false;
  const [, salt, expected] = storedHash.split(":");
  const actual = crypto.scryptSync(password, salt, 64).toString("hex");
  return crypto.timingSafeEqual(Buffer.from(actual, "hex"), Buffer.from(expected, "hex"));
}

export class DatabaseStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(sql`lower(${users.username}) = lower(${username})`);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(sql`lower(${users.email}) = lower(${email})`);
    return user;
  }

  async verifyUser(username: string, password: string): Promise<User | undefined> {
    const user = await this.getUserByUsername(username);
    if (!user) return undefined;
    if (user.passwordHash) return verifyHash(password, user.passwordHash) ? user : undefined;
    if (user.password && user.password === password) {
      await this.updateUser(user.id, { passwordHash: hashPassword(password), password: null as any });
      return (await this.getUser(user.id)) || user;
    }
    return undefined;
  }

  async createUser(userData: Partial<User> & { username: string; password: string }): Promise<User> {
    const [user] = await db.insert(users).values({
      username: userData.username,
      password: null,
      passwordHash: hashPassword(userData.password),
      email: userData.email || null,
      phone: userData.phone || null,
      userType: userData.userType || "lab",
      role: userData.role || "user",
      licenseNumber: userData.licenseNumber || null,
      practiceName: userData.practiceName || null,
      doctorName: userData.doctorName || null,
      practiceAddress: userData.practiceAddress || null,
      practicePhone: userData.practicePhone || null,
      phoneContactName: userData.phoneContactName || null,
      accountNumber: userData.accountNumber || null,
      wantsUpdates: userData.wantsUpdates || false,
      primaryOrganizationId: userData.primaryOrganizationId || null,
      affiliationStatus: userData.affiliationStatus || "active",
    }).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> { return db.select().from(users); }

  async getPublicUsers(): Promise<any[]> {
    const rows = await db.select().from(users);
    return rows.map(u => ({
      id: u.id,
      username: u.username,
      email: u.email,
      phone: u.phone,
      userType: u.userType,
      role: u.role,
      licenseNumber: u.licenseNumber,
      practiceName: u.practiceName,
      doctorName: u.doctorName,
      practiceAddress: u.practiceAddress,
      practicePhone: u.practicePhone,
      phoneContactName: u.phoneContactName,
      accountNumber: u.accountNumber,
      organizationId: u.primaryOrganizationId || null,
      affiliationStatus: u.affiliationStatus || "active",
    }));
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const [updated] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    await db.delete(organizationMemberships).where(eq(organizationMemberships.userId, id));
    await db.delete(organizationJoinRequests).where(eq(organizationJoinRequests.requestingUserId, id));
    const result = await db.delete(users).where(eq(users.id, id)).returning();
    return result.length > 0;
  }

  async getOrganizationByName(type: "lab" | "provider", name: string) {
    const [org] = await db.select().from(organizations).where(and(eq(organizations.type, type), eq(organizations.normalizedName, normalizeName(name))));
    return org;
  }

  async createOrganization(data: { type: "lab" | "provider"; name: string; address?: string | null; phone?: string | null; email?: string | null; createdByUserId?: string | null; }) {
    const [org] = await db.insert(organizations).values({
      type: data.type,
      name: data.name.trim(),
      normalizedName: normalizeName(data.name),
      address: data.address || null,
      phone: data.phone || null,
      email: data.email || null,
      createdByUserId: data.createdByUserId || null,
    }).returning();
    return org;
  }

  async createMembership(data: { organizationId: string; userId: string; role: "owner" | "admin" | "user"; status: "active" | "pending" | "invited" | "declined"; invitedByUserId?: string | null; approvedByUserId?: string | null; }) {
    const existing = await db.select().from(organizationMemberships).where(and(eq(organizationMemberships.organizationId, data.organizationId), eq(organizationMemberships.userId, data.userId)));
    if (existing[0]) {
      const [updated] = await db.update(organizationMemberships).set({
        role: data.role,
        status: data.status,
        invitedByUserId: data.invitedByUserId || null,
        approvedByUserId: data.approvedByUserId || null,
      }).where(eq(organizationMemberships.id, existing[0].id)).returning();
      return updated;
    }
    const [membership] = await db.insert(organizationMemberships).values(data).returning();
    return membership;
  }

  async listLabGroups() {
    const orgs = await db.select().from(organizations).where(eq(organizations.type, "lab"));
    const memberships = orgs.length ? await db.select().from(organizationMemberships).where(inArray(organizationMemberships.organizationId, orgs.map(o => o.id))) : [];
    const usersRows = await db.select().from(users);
    const userMap = new Map(usersRows.map(u => [u.id, u]));
    return orgs.map(org => {
      const adminMembership = memberships.find(m => m.organizationId === org.id && (m.role === "owner" || m.role === "admin") && m.status === "active");
      const adminUser = adminMembership ? userMap.get(adminMembership.userId) : undefined;
      return {
        organizationId: org.id,
        practiceName: org.name,
        username: adminUser?.username || "",
        practiceAddress: org.address || "",
      };
    });
  }

  async createJoinRequest(data: { organizationId: string; requestingUserId: string; targetAdminUsername?: string | null; requestedRole: "admin" | "user"; message?: string | null; }) {
    const existing = await db.select().from(organizationJoinRequests).where(and(eq(organizationJoinRequests.organizationId, data.organizationId), eq(organizationJoinRequests.requestingUserId, data.requestingUserId), eq(organizationJoinRequests.status, "pending")));
    if (existing[0]) return existing[0];
    await this.createMembership({ organizationId: data.organizationId, userId: data.requestingUserId, role: data.requestedRole, status: "pending" });
    const [row] = await db.insert(organizationJoinRequests).values({ ...data, status: "pending" }).returning();
    return row;
  }

  async listJoinRequestsForAdmin(adminUserId: string) {
    const memberships = await db.select().from(organizationMemberships).where(and(eq(organizationMemberships.userId, adminUserId), eq(organizationMemberships.status, "active")));
    const allowedOrgIds = memberships.filter(m => m.role === "owner" || m.role === "admin").map(m => m.organizationId);
    if (!allowedOrgIds.length) return [];
    const requests = await db.select().from(organizationJoinRequests).where(inArray(organizationJoinRequests.organizationId, allowedOrgIds));
    const requestors = requests.length ? await db.select().from(users).where(inArray(users.id, requests.map(r => r.requestingUserId))) : [];
    const userMap = new Map(requestors.map(u => [u.id, u]));
    return requests.map(r => ({
      id: r.id,
      requestingUsername: userMap.get(r.requestingUserId)?.username || "unknown",
      targetAdminUsername: r.targetAdminUsername || "",
      message: r.message || "",
      status: r.status === "accepted" ? "accepted" : r.status === "declined" ? "declined" : "pending",
      createdAt: r.createdAt ? new Date(r.createdAt).getTime() : Date.now(),
      organizationId: r.organizationId,
      requestingUserId: r.requestingUserId,
      requestedRole: r.requestedRole,
    }));
  }

  async respondToJoinRequest(requestId: string, adminUserId: string, accept: boolean, role?: "admin" | "user") {
    const [request] = await db.select().from(organizationJoinRequests).where(eq(organizationJoinRequests.id, requestId));
    if (!request) return { success: false, error: "Request not found" };
    const adminMemberships = await db.select().from(organizationMemberships).where(and(eq(organizationMemberships.userId, adminUserId), eq(organizationMemberships.organizationId, request.organizationId), eq(organizationMemberships.status, "active")));
    const isAdmin = adminMemberships.some(m => m.role === "owner" || m.role === "admin");
    if (!isAdmin) return { success: false, error: "Unauthorized" };
    const requestedUser = await this.getUser(request.requestingUserId);
    const org = await db.select().from(organizations).where(eq(organizations.id, request.organizationId));
    if (!requestedUser || !org[0]) return { success: false, error: "Invalid request" };
    if (accept) {
      await this.createMembership({ organizationId: request.organizationId, userId: request.requestingUserId, role: (role || request.requestedRole || "user") as any, status: "active", approvedByUserId: adminUserId });
      await this.updateUser(request.requestingUserId, {
        primaryOrganizationId: request.organizationId,
        affiliationStatus: "active",
        practiceName: org[0].name,
        role: (role || request.requestedRole || "user") as any,
      });
    } else {
      await this.createMembership({ organizationId: request.organizationId, userId: request.requestingUserId, role: (request.requestedRole || "user") as any, status: "declined", approvedByUserId: adminUserId });
      await this.updateUser(request.requestingUserId, { affiliationStatus: "declined" });
    }
    await db.update(organizationJoinRequests).set({ status: accept ? "accepted" : "declined", reviewedByUserId: adminUserId, reviewedAt: new Date() }).where(eq(organizationJoinRequests.id, requestId));
    return { success: true };
  }

  async getMembershipsByUserId(userId: string) {
    const memberships = await db.select().from(organizationMemberships).where(eq(organizationMemberships.userId, userId));
    const orgIds = memberships.map(m => m.organizationId);
    const orgs = orgIds.length ? await db.select().from(organizations).where(inArray(organizations.id, orgIds)) : [];
    const orgMap = new Map(orgs.map(o => [o.id, o]));
    return memberships.map(m => ({ ...m, organization: orgMap.get(m.organizationId) || null }));
  }

  async createInvite(data: { organizationId: string; adminUserId: string; targetUserId?: string | null; targetUsername: string; targetEmail?: string | null; role: "admin" | "user"; }) {
    const [row] = await db.insert(organizationInvites).values({ ...data, status: "pending" }).returning();
    if (data.targetUserId) {
      await this.createMembership({ organizationId: data.organizationId, userId: data.targetUserId, role: data.role, status: "invited", invitedByUserId: data.adminUserId });
    }
    return row;
  }

  async listInvitesForUser(userId: string, username: string) {
    const rows = await db.select().from(organizationInvites).where(sql`(${organizationInvites.targetUserId} = ${userId} OR lower(${organizationInvites.targetUsername}) = lower(${username}))`);
    const orgs = rows.length ? await db.select().from(organizations).where(inArray(organizations.id, rows.map(r => r.organizationId))) : [];
    const orgMap = new Map(orgs.map(o => [o.id, o]));
    const admins = rows.length ? await db.select().from(users).where(inArray(users.id, rows.map(r => r.adminUserId))) : [];
    const adminMap = new Map(admins.map(a => [a.id, a]));
    return rows.map(r => ({
      id: r.id,
      adminUsername: adminMap.get(r.adminUserId)?.username || "",
      adminLabName: orgMap.get(r.organizationId)?.name || "",
      targetUsername: r.targetUsername,
      targetEmail: r.targetEmail || "",
      role: r.role as "admin" | "user",
      status: r.status === "accepted" ? "accepted" : r.status === "declined" ? "declined" : "pending",
      createdAt: r.createdAt ? new Date(r.createdAt).getTime() : Date.now(),
      organizationId: r.organizationId,
    }));
  }

  async respondToInvite(inviteId: string, userId: string, accept: boolean) {
    const [invite] = await db.select().from(organizationInvites).where(eq(organizationInvites.id, inviteId));
    if (!invite) return { success: false, error: "Invite not found" };
    if (accept) {
      await this.createMembership({ organizationId: invite.organizationId, userId, role: invite.role as any, status: "active", approvedByUserId: invite.adminUserId, invitedByUserId: invite.adminUserId });
      const org = await db.select().from(organizations).where(eq(organizations.id, invite.organizationId));
      await this.updateUser(userId, { primaryOrganizationId: invite.organizationId, affiliationStatus: "active", practiceName: org[0]?.name || null, role: invite.role as any });
    } else {
      await this.updateUser(userId, { affiliationStatus: "declined" });
    }
    await db.update(organizationInvites).set({ status: accept ? "accepted" : "declined" }).where(eq(organizationInvites.id, inviteId));
    return { success: true };
  }

  async leaveOrganization(userId: string) {
    const memberships = await this.getMembershipsByUserId(userId);
    const active = memberships.find(m => m.status === "active");
    if (!active) return { success: false, error: "No active membership" };
    if (active.role === "owner") return { success: false, error: "Owner cannot leave without transferring ownership" };
    await db.update(organizationMemberships).set({ status: "declined" }).where(eq(organizationMemberships.id, active.id));
    await this.updateUser(userId, { primaryOrganizationId: null as any, affiliationStatus: "none", practiceName: null as any, role: "user" });
    return { success: true };
  }

  async upsertCase(id: string, ownerId: string, caseData: string, organizationId?: string | null): Promise<void> {
    const owner = await this.getUser(ownerId);
    const orgId = organizationId || owner?.primaryOrganizationId || null;
    await db.insert(labCases).values({ id, ownerId, organizationId: orgId, caseData, updatedAt: new Date() })
      .onConflictDoUpdate({ target: labCases.id, set: { ownerId, organizationId: orgId, caseData, updatedAt: new Date() } });
  }

  async getCasesByOwnerIds(ownerIds: string[]): Promise<{ id: string; ownerId: string; caseData: string }[]> {
    if (ownerIds.length === 0) return [];
    const ownerRows = await db.select().from(users).where(inArray(users.id, ownerIds));
    const orgIds = Array.from(new Set(ownerRows.map(u => u.primaryOrganizationId).filter(Boolean) as string[]));
    const rows = orgIds.length
      ? await db.select().from(labCases).where(sql`(${labCases.ownerId} = ANY(${ownerIds}) OR ${labCases.organizationId} = ANY(${orgIds}))`)
      : await db.select().from(labCases).where(inArray(labCases.ownerId, ownerIds));
    return rows.map(r => ({ id: r.id, ownerId: r.ownerId, caseData: r.caseData }));
  }

  async deleteCase(id: string): Promise<void> { await db.delete(labCases).where(eq(labCases.id, id)); }
}

export const storage = new DatabaseStorage();
