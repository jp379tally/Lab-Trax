import React, { useEffect, useMemo, useState } from "react";
import { View, Text, TextInput, Pressable, StyleSheet, Alert, ScrollView } from "react-native";
import { useAuth } from "@/lib/auth-context";
import { apiRequest } from "@/lib/query-client";

export default function LoginScreen() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [userType, setUserType] = useState<"lab" | "provider">("lab");
  const [role, setRole] = useState<"admin" | "user">("admin");
  const [practiceName, setPracticeName] = useState("");
  const [doctorName, setDoctorName] = useState("");
  const [practiceAddress, setPracticeAddress] = useState("");
  const [practicePhone, setPracticePhone] = useState("");
  const [existingLabs, setExistingLabs] = useState<any[]>([]);
  const [joinExistingLab, setJoinExistingLab] = useState(false);
  const [selectedExistingLab, setSelectedExistingLab] = useState<string>("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (mode !== "signup") return;
    apiRequest("GET", "/api/labs/groups").then(async (res) => {
      const data = await res.json();
      setExistingLabs(data.groups || []);
    }).catch(() => setExistingLabs([]));
  }, [mode]);

  const resolvedPracticeName = useMemo(() => {
    if (userType === "lab" && joinExistingLab && selectedExistingLab) return selectedExistingLab;
    return practiceName.trim();
  }, [userType, joinExistingLab, selectedExistingLab, practiceName]);

  async function handleSignIn() {
    setLoading(true);
    const result = await login(username.trim(), password);
    setLoading(false);
    if (!result.success) Alert.alert("Sign In Failed", result.error || "Unable to sign in.");
  }

  async function handleSignUp() {
    if (!username.trim() || !password.trim() || !resolvedPracticeName.trim()) {
      Alert.alert("Missing Information", "Username, password, and organization/lab name are required.");
      return;
    }
    setLoading(true);
    const result = await register({
      username: username.trim(),
      password,
      email: email.trim() || undefined,
      userType,
      role,
      practiceName: resolvedPracticeName,
      doctorName: doctorName.trim() || undefined,
      practiceAddress: practiceAddress.trim() || undefined,
      practicePhone: practicePhone.trim() || undefined,
    });
    setLoading(false);
    if (!result.success) {
      Alert.alert("Sign Up Failed", result.error || "Unable to create account.");
      return;
    }
    Alert.alert(result.pendingJoinRequest ? "Request Sent" : "Account Created", result.message || "Success");
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>LabTrax</Text>
      <Text style={styles.subtitle}>{mode === "signin" ? "Sign in" : "Create account"}</Text>

      <View style={styles.switchRow}>
        <Pressable style={[styles.switchBtn, mode === "signin" && styles.switchBtnActive]} onPress={() => setMode("signin")}><Text style={styles.switchText}>Sign In</Text></Pressable>
        <Pressable style={[styles.switchBtn, mode === "signup" && styles.switchBtnActive]} onPress={() => setMode("signup")}><Text style={styles.switchText}>Sign Up</Text></Pressable>
      </View>

      <TextInput style={styles.input} placeholder="Username" value={username} onChangeText={setUsername} autoCapitalize="none" />
      <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />

      {mode === "signup" && (
        <>
          <TextInput style={styles.input} placeholder="Email (optional)" value={email} onChangeText={setEmail} autoCapitalize="none" />
          <View style={styles.row}>
            <Pressable style={[styles.choice, userType === "lab" && styles.choiceActive]} onPress={() => setUserType("lab")}><Text>Lab</Text></Pressable>
            <Pressable style={[styles.choice, userType === "provider" && styles.choiceActive]} onPress={() => setUserType("provider")}><Text>Provider</Text></Pressable>
          </View>
          <View style={styles.row}>
            <Pressable style={[styles.choice, role === "admin" && styles.choiceActive]} onPress={() => setRole("admin")}><Text>Admin</Text></Pressable>
            <Pressable style={[styles.choice, role === "user" && styles.choiceActive]} onPress={() => setRole("user")}><Text>User</Text></Pressable>
          </View>

          {userType === "lab" && role === "user" && existingLabs.length > 0 && (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>Join an existing lab?</Text>
              <View style={styles.row}>
                <Pressable style={[styles.choice, !joinExistingLab && styles.choiceActive]} onPress={() => setJoinExistingLab(false)}><Text>Create New</Text></Pressable>
                <Pressable style={[styles.choice, joinExistingLab && styles.choiceActive]} onPress={() => setJoinExistingLab(true)}><Text>Join Existing</Text></Pressable>
              </View>
              {joinExistingLab && existingLabs.map((lab) => (
                <Pressable key={lab.organizationId} style={[styles.labItem, selectedExistingLab === lab.practiceName && styles.labItemActive]} onPress={() => setSelectedExistingLab(lab.practiceName)}>
                  <Text style={styles.labTitle}>{lab.practiceName}</Text>
                  <Text style={styles.labSub}>{lab.practiceAddress || ""}</Text>
                </Pressable>
              ))}
            </View>
          )}

          {(!joinExistingLab || userType !== "lab" || role !== "user") && (
            <>
              <TextInput style={styles.input} placeholder={userType === "lab" ? "Lab name" : "Practice name"} value={practiceName} onChangeText={setPracticeName} />
              <TextInput style={styles.input} placeholder="Doctor name (optional)" value={doctorName} onChangeText={setDoctorName} />
              <TextInput style={styles.input} placeholder="Address (optional)" value={practiceAddress} onChangeText={setPracticeAddress} />
              <TextInput style={styles.input} placeholder="Phone (optional)" value={practicePhone} onChangeText={setPracticePhone} />
            </>
          )}
        </>
      )}

      <Pressable style={styles.submit} onPress={mode === "signin" ? handleSignIn : handleSignUp}>
        <Text style={styles.submitText}>{loading ? "Please wait..." : mode === "signin" ? "Sign In" : "Create Account"}</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flexGrow: 1, padding: 24, justifyContent: "center", backgroundColor: "#0f172a" },
  title: { fontSize: 34, color: "white", fontWeight: "800", marginBottom: 6 },
  subtitle: { fontSize: 18, color: "#cbd5e1", marginBottom: 18 },
  switchRow: { flexDirection: "row", gap: 10, marginBottom: 18 },
  switchBtn: { flex: 1, padding: 12, borderRadius: 12, backgroundColor: "#1e293b", alignItems: "center" },
  switchBtnActive: { backgroundColor: "#3b82f6" },
  switchText: { color: "white", fontWeight: "700" },
  input: { backgroundColor: "white", padding: 14, borderRadius: 12, marginBottom: 12 },
  row: { flexDirection: "row", gap: 10, marginBottom: 12 },
  choice: { flex: 1, backgroundColor: "#e2e8f0", padding: 12, borderRadius: 12, alignItems: "center" },
  choiceActive: { backgroundColor: "#93c5fd" },
  submit: { backgroundColor: "#22c55e", padding: 16, borderRadius: 14, alignItems: "center", marginTop: 8 },
  submitText: { color: "white", fontSize: 16, fontWeight: "800" },
  card: { backgroundColor: "#1e293b", borderRadius: 14, padding: 14, marginBottom: 12 },
  cardTitle: { color: "white", fontWeight: "700", marginBottom: 10 },
  labItem: { backgroundColor: "#334155", borderRadius: 12, padding: 12, marginTop: 8 },
  labItemActive: { backgroundColor: "#2563eb" },
  labTitle: { color: "white", fontWeight: "700" },
  labSub: { color: "#cbd5e1", marginTop: 4 },
});
