# What this patch fixes right now

## Backend
- Passwords are no longer stored/compared only in plain text going forward.
- Users are linked to labs/providers through real organization records and memberships.
- Signup can create an organization or create a pending join request.
- Cases are linked to organizations so all active members of the same lab can see them.
- Replit deployment now builds the Expo web bundle before publishing.

## Frontend
- The Login screen is simplified and wired to the real backend organization flow.
- New lab users can pick `Create New` or `Join Existing`.
- Sign-up now surfaces the server response like `Request Sent`.

## Still to clean up later
- The old admin dashboard in `lib/app-context.tsx` still contains local-only join-request/invite state.
- That dashboard should be migrated to the new `/api/labs/join-requests` and `/api/labs/invites` endpoints in a second pass.
