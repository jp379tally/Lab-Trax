# LabTrax Real Integrated Patch

This patch is built against your uploaded LabTrax source tree.

## Replace these files in your existing repo
- `shared/schema.ts`
- `server/storage.ts`
- `server/routes.ts`
- `lib/auth-context.tsx`
- `components/LoginScreen.tsx`
- `scripts/deploy-build.sh`

## Then run
1. `npm install`
2. Run the SQL in `sql/001_integrated_patch.sql`
3. `npm run db:push` if you want Drizzle to reconcile the schema too
4. Redeploy

## What this patch changes
- hashes passwords with Node `scrypt`
- adds real organizations and memberships
- creates pending join requests instead of fake local-only lab joining
- returns lab groups from the server
- links cases to organizations so all active members of a lab can see them
- adds admin endpoints to list/respond to join requests and invites
- fixes the Replit deploy build script so Expo web assets are actually built

## Important
This is a real integrated patch, but it is still not a complete finished product.
The giant admin dashboard and some old local-only invitation screens in `lib/app-context.tsx` still need a later cleanup pass if you want the whole app to be fully server-driven.
This patch is meant to make the live auth, signup, lab linking, and deployment behavior actually change right now.
