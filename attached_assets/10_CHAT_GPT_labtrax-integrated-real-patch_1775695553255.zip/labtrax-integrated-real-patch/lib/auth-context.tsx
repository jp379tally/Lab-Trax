import React, { createContext, useContext, useState, useEffect, useRef, useCallback, ReactNode } from "react";
import { AppState, AppStateStatus, Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as LocalAuthentication from "expo-local-authentication";
import { logAudit } from "./audit";
import { getApiUrl, resilientFetch } from "./query-client";

interface StoredUser {
  id?: string;
  username: string;
  password?: string;
  email?: string;
  phone?: string;
  wantsUpdates?: boolean;
  userType?: "provider" | "lab" | "master_admin";
  licenseNumber?: string;
  practiceName?: string;
  doctorName?: string;
  practiceAddress?: string;
  practicePhone?: string;
  phoneContactName?: string;
  role?: "user" | "admin";
  accountNumber?: string;
  primaryOrganizationId?: string | null;
  affiliationStatus?: string;
}

interface AuthContextValue {
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  currentUser: string | null;
  currentUserId: string | null;
  userType: "provider" | "lab" | "master_admin" | null;
  profilePicUri: string | null;
  setProfilePicUri: (uri: string | null) => void;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithBiometric: () => Promise<{ success: boolean; error?: string }>;
  register: (data: any) => Promise<{ success: boolean; error?: string; message?: string; pendingJoinRequest?: boolean }>;
  logout: () => void;
  deleteAccount: () => Promise<{ success: boolean; error?: string }>;
  registeredUsers: StoredUser[];
  isLocked: boolean;
  unlockWithBiometric: () => Promise<{ success: boolean; error?: string }>;
  unlockWithPassword: (password: string) => { success: boolean; error?: string };
  changePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; error?: string }>;
  updateUserProfile: (updates: any) => Promise<{ success: boolean; error?: string }>;
  resetInactivityTimer: () => void;
  refreshUsers: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const AUTH_KEY = "@drivesync_auth";
const PROFILE_PIC_KEY = "@drivesync_profile_pic";
const BIOMETRIC_USER_KEY = "@drivesync_biometric_user";
const INACTIVITY_TIMEOUT_MS = 3 * 60 * 1000;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAuthLoading, setIsAuthLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [userType, setUserType] = useState<"provider" | "lab" | "master_admin" | null>(null);
  const [registeredUsers, setRegisteredUsers] = useState<StoredUser[]>([]);
  const [profilePicUri, setProfilePicUriState] = useState<string | null>(null);
  const [isLocked, setIsLocked] = useState(false);
  const [currentPassword, setCurrentPassword] = useState<string | null>(null);
  const inactivityTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const appStateRef = useRef<AppStateStatus>(AppState.currentState);

  const resetInactivityTimer = useCallback(() => {
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    inactivityTimerRef.current = setTimeout(() => setIsLocked(true), INACTIVITY_TIMEOUT_MS);
  }, []);

  useEffect(() => { if (!isAuthenticated || isLocked) return; resetInactivityTimer(); return () => inactivityTimerRef.current && clearTimeout(inactivityTimerRef.current); }, [isAuthenticated, isLocked, resetInactivityTimer]);
  useEffect(() => {
    if (!isAuthenticated) return;
    const subscription = AppState.addEventListener("change", (nextState: AppStateStatus) => {
      if (appStateRef.current.match(/active/) && nextState.match(/inactive|background/)) {
        if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
        inactivityTimerRef.current = setTimeout(() => setIsLocked(true), INACTIVITY_TIMEOUT_MS);
      } else if (nextState === "active" && !isLocked) {
        resetInactivityTimer();
      }
      appStateRef.current = nextState;
    });
    return () => subscription.remove();
  }, [isAuthenticated, isLocked, resetInactivityTimer]);
  useEffect(() => { loadAuth(); }, []);

  async function fetchAllUsers() {
    try {
      const res = await resilientFetch("/api/auth/users");
      if (res.ok) {
        const data = await res.json();
        setRegisteredUsers(data.users || []);
        return data.users || [];
      }
    } catch {}
    return registeredUsers;
  }

  async function loadAuth() {
    try {
      const savedAuth = await AsyncStorage.getItem(AUTH_KEY);
      await fetchAllUsers();
      if (savedAuth) {
        const auth = JSON.parse(savedAuth);
        if (auth.loggedIn && auth.username) {
          setIsAuthenticated(true);
          setCurrentUser(auth.username);
          setCurrentUserId(auth.userId || null);
          setUserType(auth.userType || "lab");
          setCurrentPassword(auth.password || null);
          setIsLocked(true);
          const userPicKey = `${PROFILE_PIC_KEY}_${auth.userId || auth.username}`;
          const savedPic = await AsyncStorage.getItem(userPicKey);
          setProfilePicUriState(savedPic);
        }
      }
    } finally {
      setIsAuthLoading(false);
    }
  }

  async function setProfilePicUri(uri: string | null) {
    setProfilePicUriState(uri);
    const picKey = `${PROFILE_PIC_KEY}_${currentUserId || currentUser}`;
    if (uri) await AsyncStorage.setItem(picKey, uri);
    else await AsyncStorage.removeItem(picKey);
  }

  async function login(username: string, password: string) {
    try {
      const res = await resilientFetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password }) });
      const data = await res.json();
      if (!res.ok || !data.success) return { success: false, error: data.error || "Invalid username or password." };
      const user = data.user;
      setIsAuthenticated(true); setCurrentUser(user.username); setCurrentUserId(user.id); setUserType(user.userType || "lab"); setCurrentPassword(password);
      await AsyncStorage.setItem(AUTH_KEY, JSON.stringify({ loggedIn: true, username: user.username, userId: user.id, userType: user.userType || "lab", password }));
      await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify({ username: user.username, password }));
      await fetchAllUsers();
      const userPicKey = `${PROFILE_PIC_KEY}_${user.id || user.username}`;
      const savedPic = await AsyncStorage.getItem(userPicKey);
      setProfilePicUriState(savedPic);
      logAudit("LOGIN", username, "User authenticated");
      return { success: true };
    } catch (e: any) {
      return { success: false, error: `Connection error: ${e?.message || "Network request failed"}. Server: ${getApiUrl()}` };
    }
  }

  async function loginWithBiometric() {
    try {
      const stored = await AsyncStorage.getItem(BIOMETRIC_USER_KEY);
      if (!stored) return { success: false, error: "No saved credentials. Please sign in with your password first." };
      const { username, password } = JSON.parse(stored);
      return await login(username, password);
    } catch {
      return { success: false, error: "Could not retrieve saved credentials." };
    }
  }

  async function register(data: any) {
    try {
      const res = await resilientFetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const result = await res.json();
      if (!res.ok || !result.success) return { success: false, error: result.error || "Registration failed." };
      const user = result.user;
      setIsAuthenticated(true); setCurrentUser(user.username); setCurrentUserId(user.id); setUserType(user.userType || data.userType || "lab"); setCurrentPassword(data.password);
      await AsyncStorage.setItem(AUTH_KEY, JSON.stringify({ loggedIn: true, username: user.username, userId: user.id, userType: user.userType || "lab", password: data.password }));
      await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify({ username: user.username, password: data.password }));
      await fetchAllUsers();
      logAudit("REGISTER", user.username, result.message || "Account created");
      return { success: true, message: result.message, pendingJoinRequest: !!result.pendingJoinRequest };
    } catch {
      return { success: false, error: "Registration failed. Please try again." };
    }
  }

  function logout() { setIsAuthenticated(false); setCurrentUser(null); setCurrentUserId(null); setUserType(null); setCurrentPassword(null); setIsLocked(false); AsyncStorage.removeItem(AUTH_KEY); }
  async function deleteAccount() { try { const res = await resilientFetch(`/api/auth/users/${currentUserId}`, { method: "DELETE", headers: { "x-user-id": currentUserId || "" } }); if (!res.ok) { const d = await res.json().catch(()=>({})); return { success: false, error: d.error || "Failed to delete account" }; } logout(); return { success: true }; } catch (e: any) { return { success: false, error: e?.message || "Failed to delete account" }; } }
  async function unlockWithBiometric() { if (Platform.OS === "web") return { success: true }; try { const result = await LocalAuthentication.authenticateAsync({ promptMessage: "Unlock LabTrax", fallbackLabel: "Use password", disableDeviceFallback: false }); if (result.success) { setIsLocked(false); resetInactivityTimer(); return { success: true }; } return { success: false, error: "Biometric authentication failed." }; } catch { return { success: false, error: "Biometric authentication failed." }; } }
  function unlockWithPassword(password: string) { if (currentPassword && password === currentPassword) { setIsLocked(false); resetInactivityTimer(); return { success: true }; } return { success: false, error: "Incorrect password." }; }
  async function changePassword(currentPasswordInput: string, newPassword: string) { try { const res = await resilientFetch(`/api/auth/users/${currentUserId}/password`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ currentPassword: currentPasswordInput, newPassword }) }); const data = await res.json(); if (!res.ok || !data.success) return { success: false, error: data.error || "Failed to update password" }; setCurrentPassword(newPassword); const saved = await AsyncStorage.getItem(AUTH_KEY); if (saved) { const auth = JSON.parse(saved); auth.password = newPassword; await AsyncStorage.setItem(AUTH_KEY, JSON.stringify(auth)); } await AsyncStorage.setItem(BIOMETRIC_USER_KEY, JSON.stringify({ username: currentUser, password: newPassword })); return { success: true }; } catch (e: any) { return { success: false, error: e?.message || "Failed to update password" }; } }
  async function updateUserProfile(updates: any) { try { const res = await resilientFetch(`/api/auth/users/${currentUserId}/profile`, { method: "PUT", headers: { "Content-Type": "application/json", "x-user-id": currentUserId || "" }, body: JSON.stringify(updates) }); const data = await res.json(); if (!res.ok || !data.success) return { success: false, error: data.error || "Failed to update profile" }; await fetchAllUsers(); return { success: true }; } catch (e: any) { return { success: false, error: e?.message || "Failed to update profile" }; } }
  async function refreshUsers() { await fetchAllUsers(); }

  return <AuthContext.Provider value={{ isAuthenticated, isAuthLoading, currentUser, currentUserId, userType, profilePicUri, setProfilePicUri, login, loginWithBiometric, register, logout, deleteAccount, registeredUsers, isLocked, unlockWithBiometric, unlockWithPassword, changePassword, updateUserProfile, resetInactivityTimer, refreshUsers }}>{children}</AuthContext.Provider>;
}

export function useAuth() { const ctx = useContext(AuthContext); if (!ctx) throw new Error("useAuth must be used within AuthProvider"); return ctx; }
