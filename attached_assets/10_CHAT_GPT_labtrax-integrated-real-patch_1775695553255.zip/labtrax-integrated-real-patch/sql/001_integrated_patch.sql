ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS primary_organization_id varchar;
ALTER TABLE users ADD COLUMN IF NOT EXISTS affiliation_status text DEFAULT 'active';

CREATE TABLE IF NOT EXISTS organizations (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  name text NOT NULL,
  normalized_name text NOT NULL,
  address text,
  phone text,
  email text,
  created_by_user_id varchar,
  created_at timestamp DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS organizations_normalized_name_idx ON organizations(normalized_name);

CREATE TABLE IF NOT EXISTS organization_memberships (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id varchar NOT NULL,
  user_id varchar NOT NULL,
  role text NOT NULL DEFAULT 'user',
  status text NOT NULL DEFAULT 'active',
  invited_by_user_id varchar,
  approved_by_user_id varchar,
  created_at timestamp DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS org_memberships_unique_user_org_idx ON organization_memberships(organization_id, user_id);

CREATE TABLE IF NOT EXISTS organization_join_requests (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id varchar NOT NULL,
  requesting_user_id varchar NOT NULL,
  target_admin_username text,
  requested_role text NOT NULL DEFAULT 'user',
  message text,
  status text NOT NULL DEFAULT 'pending',
  reviewed_by_user_id varchar,
  reviewed_at timestamp,
  created_at timestamp DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organization_invites (
  id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id varchar NOT NULL,
  admin_user_id varchar NOT NULL,
  target_user_id varchar,
  target_username text NOT NULL,
  target_email text,
  role text NOT NULL DEFAULT 'user',
  status text NOT NULL DEFAULT 'pending',
  created_at timestamp DEFAULT now()
);

ALTER TABLE lab_cases ADD COLUMN IF NOT EXISTS organization_id varchar;
ALTER TABLE lab_cases ADD COLUMN IF NOT EXISTS provider_organization_id varchar;
