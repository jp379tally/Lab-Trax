#!/usr/bin/env bash
set -euo pipefail

echo "[deploy-build] installing dependencies"
npm install

echo "[deploy-build] building Expo static web bundle"
npm run expo:static:build

if [ ! -f static-build/index.html ]; then
  echo "[deploy-build] ERROR: static-build/index.html not found"
  exit 1
fi

echo "[deploy-build] building server bundle"
npm run server:build

echo "[deploy-build] done"
