LabTrax Join/Invite Fix

Fixes join/invite not delivering between users.
Uses server-side persistence instead of device-to-device logic.
