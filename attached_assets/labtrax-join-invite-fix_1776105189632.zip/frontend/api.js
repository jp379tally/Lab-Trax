export async function getJoinRequests(labId, token){
  const res = await fetch(`/api/labs/${labId}/join-requests`,{
    headers:{Authorization:`Bearer ${token}`}
  })
  return res.json()
}

export async function getInvites(token){
  const res = await fetch(`/api/users/me/invites`,{
    headers:{Authorization:`Bearer ${token}`}
  })
  return res.json()
}
