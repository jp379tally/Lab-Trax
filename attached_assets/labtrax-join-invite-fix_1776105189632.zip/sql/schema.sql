CREATE TABLE IF NOT EXISTS join_requests (
  id SERIAL PRIMARY KEY,
  lab_id INT,
  user_id INT,
  status TEXT DEFAULT 'pending'
);

CREATE TABLE IF NOT EXISTS lab_invites (
  id SERIAL PRIMARY KEY,
  lab_id INT,
  invited_user_id INT,
  invited_phone TEXT,
  status TEXT DEFAULT 'pending'
);
