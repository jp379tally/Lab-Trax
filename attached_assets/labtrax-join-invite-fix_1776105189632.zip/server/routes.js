app.post('/api/labs/:labId/join-requests', async (req,res)=>{
  const { labId } = req.params
  const userId = req.user.id
  await db.query('INSERT INTO join_requests (lab_id,user_id) VALUES ($1,$2)',[labId,userId])
  res.json({success:true})
})

app.get('/api/labs/:labId/join-requests', async (req,res)=>{
  const { labId } = req.params
  const result = await db.query('SELECT * FROM join_requests WHERE lab_id=$1 AND status=$2',[labId,'pending'])
  res.json(result.rows)
})

app.post('/api/labs/:labId/invites', async (req,res)=>{
  const { labId } = req.params
  const { invitedUserId } = req.body
  await db.query('INSERT INTO lab_invites (lab_id,invited_user_id) VALUES ($1,$2)',[labId,invitedUserId])
  res.json({success:true})
})
