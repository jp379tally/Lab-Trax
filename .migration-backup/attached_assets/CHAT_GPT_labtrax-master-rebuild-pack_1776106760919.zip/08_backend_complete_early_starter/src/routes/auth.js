const express = require('express');
const router = express.Router();

router.post('/login', async (req, res) => {
  res.json({ message: 'login route placeholder' });
});

router.post('/register', async (req, res) => {
  res.json({ message: 'register route placeholder' });
});

module.exports = router;
