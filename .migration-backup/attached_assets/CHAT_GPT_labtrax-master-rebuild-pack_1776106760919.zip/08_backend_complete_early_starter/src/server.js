require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.send('OK');
});

app.listen(process.env.PORT || 3000, () => {
  console.log('Server running');
});
