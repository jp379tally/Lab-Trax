# LabTrax HIPAA-Ready Backend

## Setup

1. Install dependencies:
npm install

2. Create .env:
DATABASE_URL=your_db_url
JWT_SECRET=your_secret
PORT=3000

3. Run:
npm run dev

## Key Features
- Auth with bcrypt + JWT
- Organizations (lab/provider)
- Membership roles
- Cases + timeline events
- Provider submission approval
- Invoices + payments
- Audit logs

## API Flow Order
1. Auth
2. Organizations
3. Memberships
4. Cases
5. Submissions
6. Invoices
