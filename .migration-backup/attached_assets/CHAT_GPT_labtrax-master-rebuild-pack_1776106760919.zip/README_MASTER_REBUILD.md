# LabTrax Master Rebuild Pack

This folder combines the rebuild materials created across this project into one drag-and-drop package for Replit.

## What this pack contains

### Core build sequence
1. `01_phase2_core_system`
   - auth
   - organizations
   - memberships
   - invites
   - join requests
   - audit log foundation

2. `02_phase3_case_invoice_system`
   - cases
   - restorations
   - timeline/events
   - provider submission queue
   - invoices
   - payments

3. `03_phase4_security_files_permissions`
   - permissions middleware
   - secure attachment metadata
   - signed upload/download placeholders
   - protected submission approval routes
   - protected invoice secure-link route
   - organization connection checks

4. `04_phase5_frontend_wiring`
   - API client
   - auth context
   - portal router
   - role guard
   - file upload helper
   - frontend case/invoice hooks

5. `05_phase6_polish_onboarding_notifications`
   - onboarding structure
   - notification stubs
   - admin settings scaffold
   - release checklist
   - UX polish helpers

### Supporting packs
6. `06_backend_with_scanner_integrations`
   - early integration framework for iTero / 3Shape / SHINING
   - import queue placeholders

7. `07_replit_deployment_fix`
   - deploy-build fix for Replit so Expo web is built before deployment

8. `08_backend_complete_early_starter`
   - earlier starter shell

9. `09_backend_rewrite_early_starter`
   - earlier rewrite starter

## Recommended order in Replit

### Option A: clean rebuild in a fresh Replit project
Use this if you want the least confusion.

#### Backend merge order
1. Start with `01_phase2_core_system`
2. Layer in `02_phase3_case_invoice_system`
3. Layer in `03_phase4_security_files_permissions`
4. Add selected pieces from `06_backend_with_scanner_integrations`
5. Apply `07_replit_deployment_fix`

#### Frontend merge order
1. Start with your current LabTrax frontend
2. Merge in `04_phase5_frontend_wiring`
3. Add `05_phase6_polish_onboarding_notifications`

### Option B: keep your current repo and merge into it
1. Back up your current Replit project first
2. Copy backend files phase by phase
3. Run SQL in order
4. Wire frontend to new API
5. Apply deploy fix
6. Test each flow before moving on

## SQL order
Run these in this exact order:
1. `01_phase2_core_system/sql/001_phase2_core.sql`
2. `02_phase3_case_invoice_system/sql/002_phase3.sql`
3. `03_phase4_security_files_permissions/sql/003_phase4_security.sql`

## Required environment variables

At minimum:
- `DATABASE_URL`
- `JWT_SECRET`
- `PORT`

Recommended additional values:
- `CORS_ORIGIN`
- `JWT_EXPIRES_IN`
- `INVITE_EXPIRES_HOURS`
- `STORAGE_PROVIDER`
- `STORAGE_BUCKET`
- `STORAGE_REGION`
- `SIGNED_URL_TTL_SECONDS`

## Master implementation checklist

### Foundation
- [ ] Create a fresh backup of the current Replit app
- [ ] Upload backend phases
- [ ] Install dependencies
- [ ] Create `.env`
- [ ] Run SQL in order
- [ ] Start backend
- [ ] Confirm `/api/health`

### Auth and orgs
- [ ] Register user
- [ ] Login user
- [ ] Create lab organization
- [ ] Create provider organization
- [ ] Create join request
- [ ] Approve join request
- [ ] Send invite
- [ ] Accept invite
- [ ] Confirm role restrictions

### Cases and invoices
- [ ] Create case
- [ ] Add two zirconia restorations
- [ ] Confirm quantity logic
- [ ] Generate invoice
- [ ] Record payment

### Security and files
- [ ] Generate signed upload URL
- [ ] Upload file
- [ ] Mark upload complete
- [ ] Attach file to case
- [ ] Confirm provider visibility rules
- [ ] Confirm internal-lab-only visibility rules
- [ ] Approve provider submission
- [ ] Reject provider submission
- [ ] Confirm case event logging

### Frontend wiring
- [ ] Set API URL in `04_phase5_frontend_wiring/src/api/client.ts`
- [ ] Wrap app in `AuthProvider`
- [ ] Route app through `PortalRouter`
- [ ] Use `RequireRole` for admin/billing UI
- [ ] Use signed upload helper for case attachments

### Deployment
- [ ] Replace deploy build script from `07_replit_deployment_fix`
- [ ] Set Replit deployment build command
- [ ] Redeploy
- [ ] Confirm `/app` loads
- [ ] Confirm JS bundles return JavaScript, not HTML

## Important honesty note
This pack is a strong rebuild starter and consolidation of the work created in this project. It is not a finished, one-click complete production app. You will still need to merge and wire pieces together in Replit, especially:
- your existing Expo UI screens
- real storage credentials
- scanner vendor-specific integrations
- MFA
- vendor BAAs and production HIPAA controls

## Suggested final architecture
- PostgreSQL
- Express backend
- JWT auth
- organization memberships
- case timeline
- secure attachments
- provider approval queue
- invoice engine
- frontend auth context + portal guards
- Replit deploy build that exports Expo web

## Where to start first
Open:
- `01_phase2_core_system/README.md`
- `04_phase5_frontend_wiring/README.md`
- `07_replit_deployment_fix`

Then merge in order.
