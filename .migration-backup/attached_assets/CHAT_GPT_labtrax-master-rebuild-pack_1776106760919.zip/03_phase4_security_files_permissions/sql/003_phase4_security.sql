CREATE TABLE IF NOT EXISTS organization_connections (
  id BIGSERIAL PRIMARY KEY,
  lab_organization_id BIGINT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  provider_organization_id BIGINT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  status TEXT NOT NULL CHECK (status IN ('pending', 'active', 'rejected', 'inactive')),
  requested_by_org_id BIGINT NULL REFERENCES organizations(id),
  requested_by_user_id BIGINT NULL REFERENCES users(id),
  approved_by_user_id BIGINT NULL REFERENCES users(id),
  approved_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS secure_attachments (
  id BIGSERIAL PRIMARY KEY,
  organization_id BIGINT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  case_id BIGINT NULL REFERENCES cases(id) ON DELETE SET NULL,
  uploaded_by_user_id BIGINT NOT NULL REFERENCES users(id),
  storage_key TEXT NOT NULL UNIQUE,
  original_file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  size_bytes BIGINT NULL,
  attachment_type TEXT NOT NULL DEFAULT 'general',
  visibility TEXT NOT NULL CHECK (visibility IN ('internal_lab_only', 'shared_with_provider')),
  upload_status TEXT NOT NULL CHECK (upload_status IN ('pending_upload', 'uploaded', 'failed')) DEFAULT 'pending_upload',
  uploaded_at TIMESTAMPTZ NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS case_locations (
  id BIGSERIAL PRIMARY KEY,
  case_id BIGINT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  location_code TEXT NOT NULL,
  location_name TEXT NOT NULL,
  moved_by_user_id BIGINT NOT NULL REFERENCES users(id),
  moved_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  notes TEXT NULL
);

ALTER TABLE cases
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW();

ALTER TABLE case_events
  ADD COLUMN IF NOT EXISTS actor_user_id BIGINT NULL REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS actor_organization_id BIGINT NULL REFERENCES organizations(id),
  ADD COLUMN IF NOT EXISTS actor_initials TEXT NULL,
  ADD COLUMN IF NOT EXISTS metadata_json JSONB NOT NULL DEFAULT '{}'::jsonb;

ALTER TABLE case_submission_queue
  ADD COLUMN IF NOT EXISTS submitted_by_user_id BIGINT NULL REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS submitted_by_organization_id BIGINT NULL REFERENCES organizations(id),
  ADD COLUMN IF NOT EXISTS submission_type TEXT NULL,
  ADD COLUMN IF NOT EXISTS payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS reviewed_by_user_id BIGINT NULL REFERENCES users(id),
  ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMPTZ NULL,
  ADD COLUMN IF NOT EXISTS review_notes TEXT NULL;

ALTER TABLE invoices
  ADD COLUMN IF NOT EXISTS lab_organization_id BIGINT NULL REFERENCES organizations(id),
  ADD COLUMN IF NOT EXISTS provider_organization_id BIGINT NULL REFERENCES organizations(id);

CREATE INDEX IF NOT EXISTS idx_org_connections_lab_provider
  ON organization_connections(lab_organization_id, provider_organization_id);

CREATE INDEX IF NOT EXISTS idx_secure_attachments_case
  ON secure_attachments(case_id);

CREATE INDEX IF NOT EXISTS idx_secure_attachments_org
  ON secure_attachments(organization_id);

CREATE INDEX IF NOT EXISTS idx_case_locations_case
  ON case_locations(case_id);
