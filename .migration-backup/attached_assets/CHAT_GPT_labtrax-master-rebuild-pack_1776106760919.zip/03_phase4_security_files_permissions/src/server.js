require("dotenv").config();
const express = require("express");
const cors = require("cors");

const filesRoutes = require("./routes/files");
const casesRoutes = require("./routes/casesProtected");
const invoicesRoutes = require("./routes/invoicesProtected");
const submissionsRoutes = require("./routes/submissionsProtected");

const app = express();

app.use(cors({
  origin: process.env.CORS_ORIGIN === "*" ? true : process.env.CORS_ORIGIN,
  credentials: true,
}));
app.use(express.json({ limit: "10mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "labtrax-phase4-security-files-permissions" });
});

app.use("/api/files", filesRoutes);
app.use("/api/cases", casesRoutes);
app.use("/api/invoices", invoicesRoutes);
app.use("/api/submissions", submissionsRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({
    error: err.message || "Internal server error",
  });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`LabTrax Phase 4 server running on ${port}`);
});
