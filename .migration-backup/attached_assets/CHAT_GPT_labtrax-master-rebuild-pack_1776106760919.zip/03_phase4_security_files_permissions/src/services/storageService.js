const { buildStorageKey } = require("../utils/fileKeys");

const ttlSeconds = Number(process.env.SIGNED_URL_TTL_SECONDS || 900);

function buildSignedPlaceholderUrl(action, key) {
  const encodedKey = encodeURIComponent(key);
  return `https://example-storage.local/${action}/${encodedKey}?expires_in=${ttlSeconds}`;
}

async function createSignedUpload({
  organizationId,
  caseId = null,
  attachmentType = "general",
  originalFileName,
  contentType = "application/octet-stream",
  sizeBytes = null,
}) {
  const key = buildStorageKey({
    organizationId,
    caseId,
    attachmentType,
    originalFileName,
  });

  return {
    storageKey: key,
    uploadUrl: buildSignedPlaceholderUrl("upload", key),
    expiresInSeconds: ttlSeconds,
    contentType,
    sizeBytes,
  };
}

async function createSignedDownload({ storageKey }) {
  return {
    downloadUrl: buildSignedPlaceholderUrl("download", storageKey),
    expiresInSeconds: ttlSeconds,
  };
}

module.exports = {
  createSignedUpload,
  createSignedDownload,
};
