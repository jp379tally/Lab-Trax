const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { requireCaseAccess, requireCaseRole, requireConnectedOrganizations } = require("../middleware/access");
const { badRequest } = require("../utils/errors");
const { logAudit, getRequestIp } = require("../utils/audit");

const router = express.Router();

router.get("/:caseId/attachments", requireAuth, requireCaseAccess, async (req, res, next) => {
  try {
    const attachments = await query(
      `
        SELECT id, case_id, original_file_name, content_type, size_bytes, attachment_type, visibility, upload_status, uploaded_at, created_at
        FROM secure_attachments
        WHERE case_id = $1
          AND upload_status = 'uploaded'
          AND (
            visibility = 'shared_with_provider'
            OR (
              visibility = 'internal_lab_only'
              AND $2 = 'lab'
            )
          )
        ORDER BY created_at DESC
      `,
      [req.caseRecord.id, req.caseAccess.side]
    );

    res.json({ attachments: attachments.rows });
  } catch (error) {
    next(error);
  }
});

router.post("/:caseId/attachments", requireAuth, requireCaseAccess, requireCaseRole({
  labRoles: ["owner", "admin", "user"],
  providerRoles: ["owner", "admin", "user"],
}), requireConnectedOrganizations, async (req, res, next) => {
  try {
    const { attachmentId } = req.body;
    if (!attachmentId) {
      throw badRequest("attachmentId is required");
    }

    const attachmentResult = await query(
      `SELECT * FROM secure_attachments WHERE id = $1`,
      [attachmentId]
    );
    const attachment = attachmentResult.rows[0];
    if (!attachment) {
      throw badRequest("Attachment not found");
    }

    const updated = await query(
      `
        UPDATE secure_attachments
        SET case_id = $1, updated_at = NOW()
        WHERE id = $2
        RETURNING *
      `,
      [req.caseRecord.id, attachmentId]
    );

    await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'attachment_added',$2,$3,$4,$5)
      `,
      [
        req.caseRecord.id,
        req.user.id,
        req.caseAccess.membership.organization_id,
        req.user.initials,
        JSON.stringify({
          attachmentId,
          side: req.caseAccess.side,
        }),
      ]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: req.caseAccess.membership.organization_id,
      action: "case_attachment_added",
      entityType: "case",
      entityId: req.caseRecord.id,
      metadata: { attachmentId },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.status(201).json({ attachment: updated.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.post("/:caseId/status-changes", requireAuth, requireCaseAccess, requireCaseRole({
  labRoles: ["owner", "admin", "user"],
  providerRoles: [],
}), async (req, res, next) => {
  try {
    const { newStatus, note = null } = req.body;
    if (!newStatus) {
      throw badRequest("newStatus is required");
    }

    const updatedCase = await query(
      `
        UPDATE cases
        SET status = $1, updated_at = NOW()
        WHERE id = $2
        RETURNING *
      `,
      [newStatus, req.caseRecord.id]
    );

    const event = await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'status_changed',$2,$3,$4,$5)
        RETURNING *
      `,
      [
        req.caseRecord.id,
        req.user.id,
        req.caseAccess.membership.organization_id,
        req.user.initials,
        JSON.stringify({
          oldStatus: req.caseRecord.status,
          newStatus,
          note,
        }),
      ]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: req.caseAccess.membership.organization_id,
      action: "case_status_changed",
      entityType: "case",
      entityId: req.caseRecord.id,
      metadata: { from: req.caseRecord.status, to: newStatus },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({
      case: updatedCase.rows[0],
      event: event.rows[0],
    });
  } catch (error) {
    next(error);
  }
});

router.post("/:caseId/location-changes", requireAuth, requireCaseAccess, requireCaseRole({
  labRoles: ["owner", "admin", "user"],
  providerRoles: [],
}), async (req, res, next) => {
  try {
    const { locationCode, locationName, note = null } = req.body;
    if (!locationCode || !locationName) {
      throw badRequest("locationCode and locationName are required");
    }

    const location = await query(
      `
        INSERT INTO case_locations
        (case_id, location_code, location_name, moved_by_user_id, moved_at, notes)
        VALUES ($1,$2,$3,$4,NOW(),$5)
        RETURNING *
      `,
      [req.caseRecord.id, locationCode, locationName, req.user.id, note]
    );

    const event = await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'location_changed',$2,$3,$4,$5)
        RETURNING *
      `,
      [
        req.caseRecord.id,
        req.user.id,
        req.caseAccess.membership.organization_id,
        req.user.initials,
        JSON.stringify({ locationCode, locationName, note }),
      ]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: req.caseAccess.membership.organization_id,
      action: "case_location_changed",
      entityType: "case",
      entityId: req.caseRecord.id,
      metadata: { locationCode, locationName },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.status(201).json({
      location: location.rows[0],
      event: event.rows[0],
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
