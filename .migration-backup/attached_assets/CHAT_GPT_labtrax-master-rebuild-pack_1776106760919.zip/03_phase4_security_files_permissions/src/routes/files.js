const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { requireOrgMembership, requireCaseAccess, requireCaseRole } = require("../middleware/access");
const { badRequest, notFound, forbidden } = require("../utils/errors");
const { createSignedUpload, createSignedDownload } = require("../services/storageService");
const { logAudit, getRequestIp } = require("../utils/audit");

const router = express.Router();

router.post("/upload-url", requireAuth, requireOrgMembership, async (req, res, next) => {
  try {
    const {
      organizationId,
      caseId = null,
      attachmentType = "general",
      originalFileName,
      contentType = "application/octet-stream",
      sizeBytes = null,
      visibility = "shared_with_provider",
    } = req.body;

    if (!originalFileName) {
      throw badRequest("originalFileName is required");
    }
    if (!["internal_lab_only", "shared_with_provider"].includes(visibility)) {
      throw badRequest("Invalid visibility");
    }

    const upload = await createSignedUpload({
      organizationId,
      caseId,
      attachmentType,
      originalFileName,
      contentType,
      sizeBytes,
    });

    const result = await query(
      `
        INSERT INTO secure_attachments
        (
          organization_id,
          case_id,
          uploaded_by_user_id,
          storage_key,
          original_file_name,
          content_type,
          size_bytes,
          attachment_type,
          visibility,
          upload_status
        )
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,'pending_upload')
        RETURNING *
      `,
      [
        organizationId,
        caseId,
        req.user.id,
        upload.storageKey,
        originalFileName,
        contentType,
        sizeBytes,
        attachmentType,
        visibility,
      ]
    );

    const attachment = result.rows[0];

    await logAudit({
      userId: req.user.id,
      organizationId,
      action: "secure_attachment_upload_url_created",
      entityType: "secure_attachment",
      entityId: attachment.id,
      metadata: { caseId, originalFileName, visibility, attachmentType },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.status(201).json({
      attachment,
      upload,
    });
  } catch (error) {
    next(error);
  }
});

router.post("/:attachmentId/mark-upload-complete", requireAuth, async (req, res, next) => {
  try {
    const attachmentId = Number(req.params.attachmentId);
    const result = await query(
      `
        SELECT *
        FROM secure_attachments
        WHERE id = $1
      `,
      [attachmentId]
    );

    const attachment = result.rows[0];
    if (!attachment) {
      throw notFound("Attachment not found");
    }

    const membershipResult = await query(
      `
        SELECT id, role
        FROM organization_memberships
        WHERE organization_id = $1
          AND user_id = $2
          AND status = 'active'
      `,
      [attachment.organization_id, req.user.id]
    );

    if (membershipResult.rowCount === 0) {
      throw forbidden("No access to this attachment");
    }

    const updated = await query(
      `
        UPDATE secure_attachments
        SET upload_status = 'uploaded', uploaded_at = NOW(), updated_at = NOW()
        WHERE id = $1
        RETURNING *
      `,
      [attachmentId]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: attachment.organization_id,
      action: "secure_attachment_uploaded",
      entityType: "secure_attachment",
      entityId: attachmentId,
      metadata: { caseId: attachment.case_id },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({ attachment: updated.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.get("/:attachmentId/download-url", requireAuth, async (req, res, next) => {
  try {
    const attachmentId = Number(req.params.attachmentId);
    const result = await query(
      `
        SELECT sa.*, c.lab_organization_id, c.provider_organization_id
        FROM secure_attachments sa
        LEFT JOIN cases c ON c.id = sa.case_id
        WHERE sa.id = $1
      `,
      [attachmentId]
    );

    const attachment = result.rows[0];
    if (!attachment) {
      throw notFound("Attachment not found");
    }
    if (attachment.upload_status !== "uploaded") {
      throw badRequest("Attachment is not fully uploaded");
    }

    let hasAccess = false;

    if (attachment.case_id) {
      const labMembership = await query(
        `SELECT id, role FROM organization_memberships WHERE organization_id = $1 AND user_id = $2 AND status = 'active'`,
        [attachment.lab_organization_id, req.user.id]
      );
      const providerMembership = await query(
        `SELECT id, role FROM organization_memberships WHERE organization_id = $1 AND user_id = $2 AND status = 'active'`,
        [attachment.provider_organization_id, req.user.id]
      );

      if (labMembership.rowCount > 0) hasAccess = true;
      if (providerMembership.rowCount > 0 && attachment.visibility === "shared_with_provider") hasAccess = true;
    } else {
      const orgMembership = await query(
        `SELECT id FROM organization_memberships WHERE organization_id = $1 AND user_id = $2 AND status = 'active'`,
        [attachment.organization_id, req.user.id]
      );
      if (orgMembership.rowCount > 0) hasAccess = true;
    }

    if (!hasAccess) {
      throw forbidden("No access to this attachment");
    }

    const download = await createSignedDownload({ storageKey: attachment.storage_key });

    await logAudit({
      userId: req.user.id,
      organizationId: attachment.organization_id,
      action: "secure_attachment_download_url_created",
      entityType: "secure_attachment",
      entityId: attachmentId,
      metadata: { caseId: attachment.case_id, visibility: attachment.visibility },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({
      attachment: {
        id: attachment.id,
        original_file_name: attachment.original_file_name,
        content_type: attachment.content_type,
        size_bytes: attachment.size_bytes,
        visibility: attachment.visibility,
      },
      download,
    });
  } catch (error) {
    next(error);
  }
});

router.post("/case/:caseId/attach-existing", requireAuth, requireCaseAccess, requireCaseRole({
  labRoles: ["owner", "admin", "user"],
  providerRoles: ["owner", "admin", "user"],
}), async (req, res, next) => {
  try {
    const attachmentId = Number(req.body.attachmentId);
    if (!attachmentId) {
      throw badRequest("attachmentId is required");
    }

    const attachmentResult = await query(
      `SELECT * FROM secure_attachments WHERE id = $1`,
      [attachmentId]
    );
    const attachment = attachmentResult.rows[0];
    if (!attachment) {
      throw notFound("Attachment not found");
    }
    if (attachment.organization_id !== req.caseAccess.membership.organization_id) {
      throw forbidden("Attachment must belong to the acting organization");
    }

    const updated = await query(
      `
        UPDATE secure_attachments
        SET case_id = $1, updated_at = NOW()
        WHERE id = $2
        RETURNING *
      `,
      [req.caseRecord.id, attachmentId]
    );

    await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'attachment_added',$2,$3,$4,$5)
      `,
      [
        req.caseRecord.id,
        req.user.id,
        req.caseAccess.membership.organization_id,
        req.user.initials,
        JSON.stringify({ attachmentId }),
      ]
    );

    res.json({ attachment: updated.rows[0] });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
