const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { loadMembership } = require("../middleware/access");
const { forbidden, notFound, badRequest } = require("../utils/errors");
const { logAudit, getRequestIp } = require("../utils/audit");

const router = express.Router();

async function loadSubmission(submissionId) {
  const result = await query(
    `
      SELECT csq.*, c.lab_organization_id, c.provider_organization_id
      FROM case_submission_queue csq
      INNER JOIN cases c ON c.id = csq.case_id
      WHERE csq.id = $1
    `,
    [submissionId]
  );
  return result.rows[0] || null;
}

router.post("/:submissionId/approve", requireAuth, async (req, res, next) => {
  try {
    const submissionId = Number(req.params.submissionId);
    const submission = await loadSubmission(submissionId);
    if (!submission) {
      throw notFound("Submission not found");
    }
    if (submission.status !== "pending_review") {
      throw badRequest("Submission is not pending_review");
    }

    const labMembership = await loadMembership(req.user.id, submission.lab_organization_id);
    if (!labMembership || !["owner", "admin"].includes(labMembership.role)) {
      throw forbidden("Only lab owner/admin can approve submissions");
    }

    const updated = await query(
      `
        UPDATE case_submission_queue
        SET status = 'approved', reviewed_by_user_id = $1, reviewed_at = NOW()
        WHERE id = $2
        RETURNING *
      `,
      [req.user.id, submissionId]
    );

    await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'provider_submission_approved',$2,$3,$4,$5)
      `,
      [
        submission.case_id,
        req.user.id,
        submission.lab_organization_id,
        req.user.initials,
        JSON.stringify({
          submissionId,
          submissionType: submission.submission_type,
        }),
      ]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: submission.lab_organization_id,
      action: "provider_submission_approved",
      entityType: "case_submission_queue",
      entityId: submissionId,
      metadata: { caseId: submission.case_id, submissionType: submission.submission_type },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({ submission: updated.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.post("/:submissionId/reject", requireAuth, async (req, res, next) => {
  try {
    const submissionId = Number(req.params.submissionId);
    const submission = await loadSubmission(submissionId);
    if (!submission) {
      throw notFound("Submission not found");
    }
    if (submission.status !== "pending_review") {
      throw badRequest("Submission is not pending_review");
    }

    const labMembership = await loadMembership(req.user.id, submission.lab_organization_id);
    if (!labMembership || !["owner", "admin"].includes(labMembership.role)) {
      throw forbidden("Only lab owner/admin can reject submissions");
    }

    const updated = await query(
      `
        UPDATE case_submission_queue
        SET status = 'rejected', reviewed_by_user_id = $1, reviewed_at = NOW(), review_notes = $3
        WHERE id = $2
        RETURNING *
      `,
      [req.user.id, submissionId, req.body.reviewNotes || null]
    );

    await query(
      `
        INSERT INTO case_events
        (case_id, event_type, actor_user_id, actor_organization_id, actor_initials, metadata_json)
        VALUES ($1,'provider_submission_rejected',$2,$3,$4,$5)
      `,
      [
        submission.case_id,
        req.user.id,
        submission.lab_organization_id,
        req.user.initials,
        JSON.stringify({
          submissionId,
          submissionType: submission.submission_type,
        }),
      ]
    );

    await logAudit({
      userId: req.user.id,
      organizationId: submission.lab_organization_id,
      action: "provider_submission_rejected",
      entityType: "case_submission_queue",
      entityId: submissionId,
      metadata: { caseId: submission.case_id, submissionType: submission.submission_type },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({ submission: updated.rows[0] });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
