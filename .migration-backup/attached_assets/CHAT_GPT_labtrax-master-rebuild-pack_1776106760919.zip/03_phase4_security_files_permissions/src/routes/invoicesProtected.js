const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");
const { forbidden, notFound } = require("../utils/errors");
const { loadMembership } = require("../middleware/access");
const { logAudit, getRequestIp } = require("../utils/audit");

const router = express.Router();

router.post("/:invoiceId/send-secure-link", requireAuth, async (req, res, next) => {
  try {
    const invoiceId = Number(req.params.invoiceId);

    const invoiceResult = await query(
      `
        SELECT *
        FROM invoices
        WHERE id = $1
      `,
      [invoiceId]
    );

    const invoice = invoiceResult.rows[0];
    if (!invoice) {
      throw notFound("Invoice not found");
    }

    const membership = await loadMembership(req.user.id, invoice.lab_organization_id);
    if (!membership || !["owner", "admin", "billing"].includes(membership.role)) {
      throw forbidden("Only lab owner/admin/billing can send invoice links");
    }

    const secureLink = `https://portal.example.local/invoices/${invoice.id}/pay`;
    await logAudit({
      userId: req.user.id,
      organizationId: invoice.lab_organization_id,
      action: "invoice_secure_link_created",
      entityType: "invoice",
      entityId: invoice.id,
      metadata: { providerOrganizationId: invoice.provider_organization_id },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    res.json({
      invoiceId: invoice.id,
      secureLink,
      note: "Send secure portal links instead of PHI-rich invoice data through plain SMS or email.",
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
