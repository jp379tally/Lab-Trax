const { query } = require("../db");

async function logAudit({
  userId = null,
  organizationId = null,
  action,
  entityType = null,
  entityId = null,
  metadata = {},
  ipAddress = null,
  userAgent = null,
}) {
  await query(
    `
      INSERT INTO audit_logs
      (user_id, organization_id, action, entity_type, entity_id, metadata_json, ip_address, user_agent)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `,
    [
      userId,
      organizationId,
      action,
      entityType,
      entityId ? String(entityId) : null,
      JSON.stringify(metadata || {}),
      ipAddress,
      userAgent,
    ]
  );
}

function getRequestIp(req) {
  return req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket?.remoteAddress || null;
}

module.exports = {
  logAudit,
  getRequestIp,
};
