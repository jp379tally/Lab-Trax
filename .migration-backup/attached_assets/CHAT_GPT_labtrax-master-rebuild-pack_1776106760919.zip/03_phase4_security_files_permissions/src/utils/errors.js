function makeError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

module.exports = {
  badRequest: (m) => makeError(400, m),
  unauthorized: (m = "Unauthorized") => makeError(401, m),
  forbidden: (m = "Forbidden") => makeError(403, m),
  notFound: (m = "Not found") => makeError(404, m),
};
