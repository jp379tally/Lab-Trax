const crypto = require("crypto");

function sanitizeFileName(name) {
  return String(name || "file")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .slice(0, 180);
}

function buildStorageKey({
  organizationId,
  caseId = null,
  attachmentType = "general",
  originalFileName,
}) {
  const safeName = sanitizeFileName(originalFileName);
  const suffix = crypto.randomBytes(8).toString("hex");
  if (caseId) {
    return `org-${organizationId}/cases/${caseId}/${attachmentType}/${suffix}-${safeName}`;
  }
  return `org-${organizationId}/uploads/${attachmentType}/${suffix}-${safeName}`;
}

module.exports = {
  sanitizeFileName,
  buildStorageKey,
};
