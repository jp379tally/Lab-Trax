const jwt = require("jsonwebtoken");

const secret = process.env.JWT_SECRET;
if (!secret) throw new Error("JWT_SECRET is missing");

function verifyToken(token) {
  return jwt.verify(token, secret);
}

module.exports = {
  verifyToken,
};
