const { query } = require("../db");
const { forbidden, notFound } = require("../utils/errors");

async function loadMembership(userId, organizationId) {
  const result = await query(
    `
      SELECT *
      FROM organization_memberships
      WHERE user_id = $1
        AND organization_id = $2
        AND status = 'active'
    `,
    [userId, organizationId]
  );
  return result.rows[0] || null;
}

async function requireOrgMembership(req, _res, next) {
  try {
    const organizationId = Number(
      req.params.organizationId || req.body.organizationId || req.query.organizationId
    );
    if (!organizationId) {
      throw forbidden("organizationId is required");
    }

    const membership = await loadMembership(req.user.id, organizationId);
    if (!membership) {
      throw forbidden("No active organization membership");
    }

    req.organizationMembership = membership;
    next();
  } catch (error) {
    next(error);
  }
}

function requireOrgRole(roles = []) {
  return async (req, _res, next) => {
    try {
      const organizationId = Number(
        req.params.organizationId || req.body.organizationId || req.query.organizationId
      );
      if (!organizationId) {
        throw forbidden("organizationId is required");
      }

      const membership = await loadMembership(req.user.id, organizationId);
      if (!membership) {
        throw forbidden("No active organization membership");
      }
      if (roles.length && !roles.includes(membership.role)) {
        throw forbidden("Insufficient organization role");
      }

      req.organizationMembership = membership;
      next();
    } catch (error) {
      next(error);
    }
  };
}

async function loadCase(caseId) {
  const result = await query(
    `
      SELECT *
      FROM cases
      WHERE id = $1
    `,
    [caseId]
  );
  return result.rows[0] || null;
}

async function requireCaseAccess(req, _res, next) {
  try {
    const caseId = Number(req.params.caseId || req.body.caseId || req.query.caseId);
    if (!caseId) {
      throw forbidden("caseId is required");
    }

    const caseRow = await loadCase(caseId);
    if (!caseRow) {
      throw notFound("Case not found");
    }

    const labMembership = await loadMembership(req.user.id, caseRow.lab_organization_id);
    const providerMembership = await loadMembership(req.user.id, caseRow.provider_organization_id);

    if (!labMembership && !providerMembership) {
      throw forbidden("No access to this case");
    }

    req.caseRecord = caseRow;
    req.caseAccess = {
      side: labMembership ? "lab" : "provider",
      membership: labMembership || providerMembership,
    };
    next();
  } catch (error) {
    next(error);
  }
}

function requireCaseRole({ labRoles = [], providerRoles = [] }) {
  return async (req, _res, next) => {
    try {
      const caseRow = req.caseRecord;
      if (!caseRow) {
        throw forbidden("Case not loaded");
      }

      const labMembership = await loadMembership(req.user.id, caseRow.lab_organization_id);
      const providerMembership = await loadMembership(req.user.id, caseRow.provider_organization_id);

      if (labMembership) {
        if (labRoles.length && !labRoles.includes(labMembership.role)) {
          throw forbidden("Insufficient lab role for this action");
        }
        req.caseAccess = { side: "lab", membership: labMembership };
        return next();
      }

      if (providerMembership) {
        if (providerRoles.length && !providerRoles.includes(providerMembership.role)) {
          throw forbidden("Insufficient provider role for this action");
        }
        req.caseAccess = { side: "provider", membership: providerMembership };
        return next();
      }

      throw forbidden("No access to this case");
    } catch (error) {
      next(error);
    }
  };
}

async function requireConnectedOrganizations(req, _res, next) {
  try {
    const caseRow = req.caseRecord;
    const result = await query(
      `
        SELECT id
        FROM organization_connections
        WHERE lab_organization_id = $1
          AND provider_organization_id = $2
          AND status = 'active'
      `,
      [caseRow.lab_organization_id, caseRow.provider_organization_id]
    );

    if (result.rowCount === 0) {
      throw forbidden("Lab and provider organizations are not actively connected");
    }

    next();
  } catch (error) {
    next(error);
  }
}

module.exports = {
  loadMembership,
  requireOrgMembership,
  requireOrgRole,
  requireCaseAccess,
  requireCaseRole,
  requireConnectedOrganizations,
};
