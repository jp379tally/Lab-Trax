const { query } = require("../db");
const { verifyToken } = require("../utils/jwt");
const { unauthorized } = require("../utils/errors");

async function requireAuth(req, _res, next) {
  try {
    const header = req.headers.authorization || "";
    const [scheme, token] = header.split(" ");

    if (scheme !== "Bearer" || !token) {
      throw unauthorized("Missing bearer token");
    }

    const payload = verifyToken(token);
    const result = await query(
      `
        SELECT id, email, first_name, last_name, initials, is_active
        FROM users
        WHERE id = $1
      `,
      [payload.sub]
    );

    const user = result.rows[0];
    if (!user || !user.is_active) {
      throw unauthorized("User not active");
    }

    req.user = user;
    next();
  } catch (_error) {
    next(unauthorized("Invalid or expired token"));
  }
}

module.exports = {
  requireAuth,
};
