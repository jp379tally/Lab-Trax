# LabTrax Phase 4 - Security + File System + Permissions

This package is the next backend layer for LabTrax. It adds:

- permission middleware for organization, cases, invoices, submissions
- audit logging helpers
- secure file metadata model
- signed-upload / signed-download placeholder service
- attachment access rules
- organization connection checks
- provider submission approval permission checks
- example protected routes

## Important
This is a strong backend starter, not a final HIPAA certification package.
You still need:
- MFA
- vendor BAAs
- production secrets management
- real cloud storage credentials
- breach policies / admin safeguards
- production monitoring / alerting

## Setup
1. Upload into Replit
2. `npm install`
3. Copy `.env.example` to `.env`
4. Run SQL in `sql/003_phase4_security.sql`
5. `npm run dev`

## Main endpoints
- `GET /api/health`
- `POST /api/files/upload-url`
- `GET /api/files/:attachmentId/download-url`
- `POST /api/files/:attachmentId/mark-upload-complete`
- `POST /api/cases/:caseId/attachments`
- `GET /api/cases/:caseId/attachments`
- `POST /api/cases/:caseId/status-changes`
- `POST /api/cases/:caseId/location-changes`
- `POST /api/invoices/:invoiceId/send-secure-link`
- `POST /api/submissions/:submissionId/approve`
- `POST /api/submissions/:submissionId/reject`

## Recommended merge order
1. Add SQL tables
2. Add storage service env vars
3. Wire auth middleware from Phase 2
4. Merge case/invoice routes from Phase 3
5. Point frontend upload flow to:
   - create upload URL
   - upload file to storage
   - mark upload complete
   - attach file to case
