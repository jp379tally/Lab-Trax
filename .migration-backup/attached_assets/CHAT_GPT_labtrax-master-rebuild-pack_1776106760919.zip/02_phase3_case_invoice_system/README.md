
# LabTrax Phase 3 - Case + Invoice System

Includes:
- Cases
- Case restorations
- Case timeline (events)
- Notes + attachments metadata
- Provider submission approval queue
- Invoice + line items + payments

Plug into Phase 2 backend.

Run SQL in /sql folder first.
