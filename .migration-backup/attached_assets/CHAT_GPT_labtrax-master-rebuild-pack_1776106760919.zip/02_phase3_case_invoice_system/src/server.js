
const express = require('express');
const app = express();
app.use(express.json());

app.use('/api/cases', require('./routes/cases'));
app.use('/api/invoices', require('./routes/invoices'));
app.use('/api/submissions', require('./routes/submissions'));

app.get('/api/health', (req,res)=>res.send('OK'));

app.listen(3000, ()=>console.log('Phase 3 running'));
