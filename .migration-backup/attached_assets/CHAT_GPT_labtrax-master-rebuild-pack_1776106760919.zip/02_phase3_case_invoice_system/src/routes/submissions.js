
const router = require('express').Router();

router.post('/:caseId', async (req,res)=>{
  res.json({message:'submission queued'});
});

router.post('/:id/approve', async (req,res)=>{
  res.json({message:'approved'});
});

module.exports = router;
