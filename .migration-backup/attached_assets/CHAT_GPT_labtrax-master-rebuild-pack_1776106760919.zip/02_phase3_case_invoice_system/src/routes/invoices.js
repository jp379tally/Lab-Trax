
const router = require('express').Router();

router.post('/generate/:caseId', async (req,res)=>{
  res.json({message:'invoice generated'});
});

router.post('/:id/payments', async (req,res)=>{
  res.json({message:'payment recorded'});
});

module.exports = router;
