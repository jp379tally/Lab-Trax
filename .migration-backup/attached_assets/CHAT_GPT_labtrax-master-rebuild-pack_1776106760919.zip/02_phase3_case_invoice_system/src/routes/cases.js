
const router = require('express').Router();

router.post('/', async (req,res)=>{
  res.json({message:'create case'});
});

router.get('/:id/events', async (req,res)=>{
  res.json({events:[]});
});

router.post('/:id/restorations', async (req,res)=>{
  res.json({message:'add restoration'});
});

module.exports = router;
