
CREATE TABLE cases (
  id SERIAL PRIMARY KEY,
  lab_organization_id INT,
  provider_organization_id INT,
  patient_name TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE case_restorations (
  id SERIAL PRIMARY KEY,
  case_id INT,
  type TEXT,
  quantity INT,
  unit_price NUMERIC
);

CREATE TABLE case_events (
  id SERIAL PRIMARY KEY,
  case_id INT,
  event_type TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE invoices (
  id SERIAL PRIMARY KEY,
  case_id INT,
  total NUMERIC,
  status TEXT
);

CREATE TABLE invoice_line_items (
  id SERIAL PRIMARY KEY,
  invoice_id INT,
  description TEXT,
  quantity INT,
  price NUMERIC
);

CREATE TABLE payments (
  id SERIAL PRIMARY KEY,
  invoice_id INT,
  amount NUMERIC,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE case_submission_queue (
  id SERIAL PRIMARY KEY,
  case_id INT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
