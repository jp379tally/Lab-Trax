# LabTrax Phase 5 - Frontend Wiring + Portal Guard Logic

This package is the frontend glue layer for LabTrax.

It includes:
- centralized API client
- auth/session context
- membership + portal routing
- UI role guard components
- signed file upload helper
- starter screens for:
  - login
  - choose/create/join organization
  - lab portal
  - provider portal
- simple hooks for cases and invoices

## What to do
1. Drag this into your Expo / React frontend project in Replit
2. Set `EXPO_PUBLIC_API_URL` or replace `API_URL` in `src/api/client.ts`
3. Wrap your app in `AuthProvider`
4. Route your main app through `PortalRouter`
5. Replace starter screens with your existing LabTrax UI while keeping the data flow

## Notes
- This is written to be easy to merge into your current app.
- It is intentionally framework-light and should work in Expo React Native with minimal changes.
- Storage uses the Phase 4 signed URL backend pattern.
