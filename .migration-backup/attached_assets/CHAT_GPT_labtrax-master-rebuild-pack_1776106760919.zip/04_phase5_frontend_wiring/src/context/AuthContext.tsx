import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { api, setToken } from "../api/client";

type Membership = {
  id: number;
  organization_id: number;
  role: "owner" | "admin" | "user" | "billing" | "read_only";
  status: string;
  organization_type: "lab" | "provider";
  organization_name: string;
  display_name?: string | null;
};

type User = {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  initials: string;
};

type AuthContextValue = {
  user: User | null;
  memberships: Membership[];
  activeMembership: Membership | null;
  loading: boolean;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (payload: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    initials: string;
  }) => Promise<void>;
  loadUser: () => Promise<void>;
  logout: () => void;
  setActiveOrganization: (organizationId: number) => void;
};

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [memberships, setMemberships] = useState<Membership[]>([]);
  const [activeMembership, setActiveMembership] = useState<Membership | null>(null);
  const [token, setTokenState] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function loadUser() {
    setLoading(true);
    try {
      const result = await api<{ user: User; memberships: Membership[] }>("/api/auth/me");
      setUser(result.user);
      setMemberships(result.memberships);
      setActiveMembership((current) => {
        if (current) {
          return result.memberships.find((m) => m.organization_id === current.organization_id) || result.memberships[0] || null;
        }
        return result.memberships[0] || null;
      });
    } finally {
      setLoading(false);
    }
  }

  async function login(email: string, password: string) {
    setLoading(true);
    try {
      const result = await api<{ token: string }>("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });
      setToken(result.token);
      setTokenState(result.token);
      await loadUser();
    } finally {
      setLoading(false);
    }
  }

  async function register(payload: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    initials: string;
  }) {
    setLoading(true);
    try {
      const result = await api<{ token: string }>("/api/auth/register", {
        method: "POST",
        body: JSON.stringify(payload),
      });
      setToken(result.token);
      setTokenState(result.token);
      await loadUser();
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    setToken(null);
    setTokenState(null);
    setUser(null);
    setMemberships([]);
    setActiveMembership(null);
  }

  function setActiveOrganization(organizationId: number) {
    const found = memberships.find((m) => m.organization_id === organizationId) || null;
    setActiveMembership(found);
  }

  const value = useMemo(() => ({
    user,
    memberships,
    activeMembership,
    loading,
    token,
    login,
    register,
    loadUser,
    logout,
    setActiveOrganization,
  }), [user, memberships, activeMembership, loading, token]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used inside AuthProvider");
  }
  return ctx;
}
