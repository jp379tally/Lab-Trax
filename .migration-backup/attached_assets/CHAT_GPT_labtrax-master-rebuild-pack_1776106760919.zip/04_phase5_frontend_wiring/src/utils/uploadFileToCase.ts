import { api } from "../api/client";

export async function uploadFileToCase(params: {
  organizationId: number;
  caseId: number;
  file: File | Blob;
  fileName: string;
  contentType: string;
  visibility?: "internal_lab_only" | "shared_with_provider";
  attachmentType?: string;
}) {
  const createUpload = await api<{
    attachment: { id: number };
    upload: { uploadUrl: string };
  }>("/api/files/upload-url", {
    method: "POST",
    body: JSON.stringify({
      organizationId: params.organizationId,
      caseId: params.caseId,
      originalFileName: params.fileName,
      contentType: params.contentType,
      visibility: params.visibility || "shared_with_provider",
      attachmentType: params.attachmentType || "general",
    }),
  });

  const uploadResponse = await fetch(createUpload.upload.uploadUrl, {
    method: "PUT",
    headers: {
      "Content-Type": params.contentType,
    },
    body: params.file,
  });

  if (!uploadResponse.ok) {
    throw new Error("Storage upload failed");
  }

  await api(`/api/files/${createUpload.attachment.id}/mark-upload-complete`, {
    method: "POST",
  });

  await api(`/api/cases/${params.caseId}/attachments`, {
    method: "POST",
    body: JSON.stringify({
      attachmentId: createUpload.attachment.id,
    }),
  });

  return createUpload.attachment.id;
}
