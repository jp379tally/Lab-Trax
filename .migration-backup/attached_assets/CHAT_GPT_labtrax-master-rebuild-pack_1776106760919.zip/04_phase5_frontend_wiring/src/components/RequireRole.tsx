import React from "react";
import { useAuth } from "../context/AuthContext";

type Props = {
  allow: Array<"owner" | "admin" | "user" | "billing" | "read_only">;
  children: React.ReactNode;
  fallback?: React.ReactNode;
};

export default function RequireRole({ allow, children, fallback = null }: Props) {
  const { activeMembership } = useAuth();

  if (!activeMembership) return <>{fallback}</>;
  if (!allow.includes(activeMembership.role)) return <>{fallback}</>;

  return <>{children}</>;
}
