import React from "react";
import { useAuth } from "../context/AuthContext";

export default function PortalHeader() {
  const { user, activeMembership, memberships, setActiveOrganization, logout } = useAuth();
  return null;
}
