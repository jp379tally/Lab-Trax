import React from "react";
import { AuthProvider } from "./context/AuthContext";
import PortalRouter from "./navigation/PortalRouter";

export default function App() {
  return (
    <AuthProvider>
      <PortalRouter />
    </AuthProvider>
  );
}
