import { api } from "../api/client";

export function useInvoices() {
  async function recordPayment(invoiceId: number, payload: {
    amount: number;
    paymentMethod: string;
    referenceNumber?: string;
  }) {
    return api(`/api/invoices/${invoiceId}/payments`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async function sendSecureLink(invoiceId: number) {
    return api(`/api/invoices/${invoiceId}/send-secure-link`, {
      method: "POST",
    });
  }

  return {
    recordPayment,
    sendSecureLink,
  };
}
