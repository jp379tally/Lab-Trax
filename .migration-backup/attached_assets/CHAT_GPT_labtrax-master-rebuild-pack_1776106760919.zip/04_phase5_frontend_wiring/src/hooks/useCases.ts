import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";

export function useCases() {
  const { activeMembership } = useAuth();

  async function createCase(payload: {
    patientFirstName: string;
    patientLastName: string;
    providerOrganizationId: number;
  }) {
    if (!activeMembership) throw new Error("No active membership");
    return api("/api/cases", {
      method: "POST",
      body: JSON.stringify({
        labOrganizationId:
          activeMembership.organization_type === "lab"
            ? activeMembership.organization_id
            : undefined,
        providerOrganizationId:
          activeMembership.organization_type === "provider"
            ? activeMembership.organization_id
            : payload.providerOrganizationId,
        ...payload,
      }),
    });
  }

  async function getCaseEvents(caseId: number) {
    return api(`/api/cases/${caseId}/events`);
  }

  async function addRestoration(caseId: number, payload: {
    toothNumber: string;
    restorationType: string;
    material?: string;
    quantity?: number;
    unitPrice?: number;
  }) {
    return api(`/api/cases/${caseId}/restorations`, {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async function generateInvoice(caseId: number) {
    return api(`/api/cases/${caseId}/generate-invoice`, {
      method: "POST",
    });
  }

  return {
    createCase,
    getCaseEvents,
    addRestoration,
    generateInvoice,
  };
}
