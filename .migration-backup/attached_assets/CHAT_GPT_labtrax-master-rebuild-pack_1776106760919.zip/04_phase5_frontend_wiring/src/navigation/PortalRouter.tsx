import React from "react";
import { useAuth } from "../context/AuthContext";
import LoginScreen from "../screens/auth/LoginScreen";
import ChooseOrganizationScreen from "../screens/common/ChooseOrganizationScreen";
import LabPortalHome from "../screens/lab/LabPortalHome";
import ProviderPortalHome from "../screens/provider/ProviderPortalHome";

export default function PortalRouter() {
  const { user, loading, activeMembership } = useAuth();

  if (loading) {
    return null;
  }

  if (!user) {
    return <LoginScreen />;
  }

  if (!activeMembership) {
    return <ChooseOrganizationScreen />;
  }

  if (activeMembership.organization_type === "lab") {
    return <LabPortalHome />;
  }

  if (activeMembership.organization_type === "provider") {
    return <ProviderPortalHome />;
  }

  return <ChooseOrganizationScreen />;
}
