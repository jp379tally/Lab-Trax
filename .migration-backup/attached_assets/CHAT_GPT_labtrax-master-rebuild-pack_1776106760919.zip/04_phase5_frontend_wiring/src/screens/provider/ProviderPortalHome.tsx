import React from "react";

export default function ProviderPortalHome() {
  return null;
}
