import React from "react";
import { useAuth } from "../../context/AuthContext";
import { api } from "../../api/client";

export default function ChooseOrganizationScreen() {
  const { memberships, setActiveOrganization } = useAuth();

  async function createOrganization(type: "lab" | "provider") {
    await api("/api/organizations", {
      method: "POST",
      body: JSON.stringify({
        type,
        name: type === "lab" ? "New Lab" : "New Provider Office",
      }),
    });
  }

  async function requestToJoin(organizationId: number) {
    await api(`/api/organizations/${organizationId}/join-requests`, {
      method: "POST",
      body: JSON.stringify({
        requestedRole: "user",
      }),
    });
  }

  return null;
}
