import React from "react";
import RequireRole from "../../components/RequireRole";

export default function LabPortalHome() {
  return null;
}

// Example usage:
// <RequireRole allow={["owner", "admin", "billing"]}>
//   <FinancialDashboard />
// </RequireRole>
