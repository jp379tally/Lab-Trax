#!/bin/bash
set -euo pipefail

echo "[1/3] Installing dependencies if needed..."
npm install

echo "[2/3] Building Expo static web bundle..."
npm run expo:static:build

if [ ! -f "static-build/index.html" ]; then
  echo "ERROR: static-build/index.html was not generated. Expo web export failed."
  exit 1
fi

echo "[3/3] Building Express server bundle..."
npm run server:build

echo "Deployment build complete. static-build and server_dist are ready."
