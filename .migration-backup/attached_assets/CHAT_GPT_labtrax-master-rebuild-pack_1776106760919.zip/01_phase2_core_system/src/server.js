require("dotenv").config();
const express = require("express");
const cors = require("cors");

const authRoutes = require("./routes/auth");
const organizationRoutes = require("./routes/organizations");
const membershipRoutes = require("./routes/memberships");
const inviteRoutes = require("./routes/invites");
const joinRequestRoutes = require("./routes/joinRequests");

const app = express();

app.use(cors({
  origin: process.env.CORS_ORIGIN === "*" ? true : process.env.CORS_ORIGIN,
  credentials: true,
}));
app.use(express.json({ limit: "5mb" }));

app.get("/api/health", async (_req, res) => {
  return res.json({ ok: true, service: "labtrax-phase2-core" });
});

app.use("/api/auth", authRoutes);
app.use("/api/organizations", organizationRoutes);
app.use("/api/memberships", membershipRoutes);
app.use("/api/invites", inviteRoutes);
app.use("/api/join-requests", joinRequestRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  const status = err.status || 500;
  const message = err.message || "Internal server error";
  return res.status(status).json({ error: message });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`LabTrax Phase 2 core server running on ${port}`);
});
