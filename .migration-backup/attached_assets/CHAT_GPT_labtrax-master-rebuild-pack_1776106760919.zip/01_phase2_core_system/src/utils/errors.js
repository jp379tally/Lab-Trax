function badRequest(message) {
  const err = new Error(message);
  err.status = 400;
  return err;
}

function unauthorized(message = "Unauthorized") {
  const err = new Error(message);
  err.status = 401;
  return err;
}

function forbidden(message = "Forbidden") {
  const err = new Error(message);
  err.status = 403;
  return err;
}

function notFound(message = "Not found") {
  const err = new Error(message);
  err.status = 404;
  return err;
}

module.exports = {
  badRequest,
  unauthorized,
  forbidden,
  notFound,
};
