const { query } = require("../db");

async function writeAuditLog({
  userId = null,
  organizationId = null,
  action,
  entityType = null,
  entityId = null,
  metadata = {},
  ipAddress = null,
  userAgent = null,
}) {
  await query(
    `
      INSERT INTO audit_logs
      (user_id, organization_id, action, entity_type, entity_id, metadata_json, ip_address, user_agent)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `,
    [
      userId,
      organizationId,
      action,
      entityType,
      entityId,
      JSON.stringify(metadata || {}),
      ipAddress,
      userAgent,
    ]
  );
}

module.exports = {
  writeAuditLog,
};
