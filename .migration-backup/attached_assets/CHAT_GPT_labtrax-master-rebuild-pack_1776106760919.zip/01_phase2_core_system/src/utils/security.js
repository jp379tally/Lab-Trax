const crypto = require("crypto");

function generateToken(size = 32) {
  return crypto.randomBytes(size).toString("hex");
}

function getRequestIp(req) {
  return req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket?.remoteAddress || null;
}

module.exports = {
  generateToken,
  getRequestIp,
};
