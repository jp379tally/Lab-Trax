const express = require("express");
const { query, withTransaction } = require("../db");
const { badRequest, notFound } = require("../utils/errors");
const { requireAuth } = require("../middleware/auth");
const { writeAuditLog } = require("../utils/audit");
const { getRequestIp } = require("../utils/security");

const router = express.Router();

router.post("/:token/accept", requireAuth, async (req, res, next) => {
  try {
    const token = req.params.token;
    const inviteResult = await query(
      `
        SELECT *
        FROM organization_invites
        WHERE token = $1
      `,
      [token]
    );

    const invite = inviteResult.rows[0];
    if (!invite) {
      throw notFound("Invite not found");
    }
    if (invite.status !== "pending") {
      throw badRequest("Invite is not pending");
    }
    if (new Date(invite.expires_at) < new Date()) {
      throw badRequest("Invite has expired");
    }
    if (invite.email.toLowerCase() !== req.user.email.toLowerCase()) {
      throw badRequest("Invite email does not match current user");
    }

    const membership = await withTransaction(async (client) => {
      const existing = await client.query(
        `
          SELECT id
          FROM organization_memberships
          WHERE organization_id = $1 AND user_id = $2
        `,
        [invite.organization_id, req.user.id]
      );

      let row;
      if (existing.rowCount > 0) {
        const updated = await client.query(
          `
            UPDATE organization_memberships
            SET role = $1, status = 'active', invited_by_user_id = $2, approved_by_user_id = $2, joined_at = NOW(), updated_at = NOW()
            WHERE organization_id = $3 AND user_id = $4
            RETURNING *
          `,
          [invite.role_to_assign, invite.invited_by_user_id, invite.organization_id, req.user.id]
        );
        row = updated.rows[0];
      } else {
        const inserted = await client.query(
          `
            INSERT INTO organization_memberships
            (organization_id, user_id, role, status, invited_by_user_id, approved_by_user_id, joined_at)
            VALUES ($1,$2,$3,'active',$4,$4,NOW())
            RETURNING *
          `,
          [invite.organization_id, req.user.id, invite.role_to_assign, invite.invited_by_user_id]
        );
        row = inserted.rows[0];
      }

      await client.query(
        `
          UPDATE organization_invites
          SET status = 'accepted', accepted_by_user_id = $1, accepted_at = NOW(), updated_at = NOW()
          WHERE id = $2
        `,
        [req.user.id, invite.id]
      );

      return row;
    });

    await writeAuditLog({
      userId: req.user.id,
      organizationId: invite.organization_id,
      action: "organization_invite_accepted",
      entityType: "organization_invite",
      entityId: invite.id,
      metadata: {
        roleAssigned: invite.role_to_assign,
      },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ membership });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
