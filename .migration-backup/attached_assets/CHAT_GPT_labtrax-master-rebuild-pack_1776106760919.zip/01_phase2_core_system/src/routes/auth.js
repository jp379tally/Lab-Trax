const express = require("express");
const bcrypt = require("bcrypt");
const { query, withTransaction } = require("../db");
const { signToken } = require("../utils/jwt");
const { badRequest, unauthorized } = require("../utils/errors");
const { writeAuditLog } = require("../utils/audit");
const { getRequestIp } = require("../utils/security");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.post("/register", async (req, res, next) => {
  try {
    const {
      email,
      password,
      firstName,
      lastName,
      initials,
    } = req.body;

    if (!email || !password || !firstName || !lastName || !initials) {
      throw badRequest("email, password, firstName, lastName, and initials are required");
    }

    const existing = await query(
      `SELECT id FROM users WHERE lower(email) = lower($1)`,
      [email]
    );

    if (existing.rowCount > 0) {
      throw badRequest("Email already in use");
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const user = await withTransaction(async (client) => {
      const result = await client.query(
        `
          INSERT INTO users
          (email, password_hash, first_name, last_name, initials, is_active)
          VALUES ($1,$2,$3,$4,$5,true)
          RETURNING id, email, first_name, last_name, initials, is_active, created_at
        `,
        [email.toLowerCase(), passwordHash, firstName, lastName, initials.toUpperCase()]
      );
      return result.rows[0];
    });

    const token = signToken(user);

    await writeAuditLog({
      userId: user.id,
      action: "auth_register",
      entityType: "user",
      entityId: user.id,
      metadata: { email: user.email },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.status(201).json({
      token,
      user,
    });
  } catch (error) {
    next(error);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      throw badRequest("email and password are required");
    }

    const result = await query(
      `
        SELECT id, email, password_hash, first_name, last_name, initials, is_active, created_at
        FROM users
        WHERE lower(email) = lower($1)
      `,
      [email]
    );

    const user = result.rows[0];
    if (!user || !user.is_active) {
      throw unauthorized("Invalid login");
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      await writeAuditLog({
        userId: user.id,
        action: "auth_login_failed",
        entityType: "user",
        entityId: user.id,
        metadata: { email },
        ipAddress: getRequestIp(req),
        userAgent: req.headers["user-agent"] || null,
      });
      throw unauthorized("Invalid login");
    }

    await query(
      `UPDATE users SET last_login_at = NOW() WHERE id = $1`,
      [user.id]
    );

    const token = signToken(user);

    await writeAuditLog({
      userId: user.id,
      action: "auth_login_success",
      entityType: "user",
      entityId: user.id,
      metadata: { email },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        initials: user.initials,
        is_active: user.is_active,
        created_at: user.created_at,
      },
    });
  } catch (error) {
    next(error);
  }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const memberships = await query(
      `
        SELECT
          om.id,
          om.organization_id,
          om.role,
          om.status,
          om.joined_at,
          o.type AS organization_type,
          o.name AS organization_name,
          o.display_name
        FROM organization_memberships om
        INNER JOIN organizations o ON o.id = om.organization_id
        WHERE om.user_id = $1
        ORDER BY om.created_at ASC
      `,
      [req.user.id]
    );

    return res.json({
      user: req.user,
      memberships: memberships.rows,
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
