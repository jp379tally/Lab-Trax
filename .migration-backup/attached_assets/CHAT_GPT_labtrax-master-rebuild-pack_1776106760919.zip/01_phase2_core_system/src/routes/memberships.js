const express = require("express");
const { query } = require("../db");
const { badRequest, forbidden, notFound } = require("../utils/errors");
const { requireAuth } = require("../middleware/auth");
const { loadMembership } = require("../middleware/organizationAccess");
const { writeAuditLog } = require("../utils/audit");
const { getRequestIp } = require("../utils/security");

const router = express.Router();

router.patch("/:membershipId", requireAuth, async (req, res, next) => {
  try {
    const membershipId = Number(req.params.membershipId);
    const targetResult = await query(
      `
        SELECT *
        FROM organization_memberships
        WHERE id = $1
      `,
      [membershipId]
    );

    const target = targetResult.rows[0];
    if (!target) {
      throw notFound("Membership not found");
    }

    const actorMembership = await loadMembership(req.user.id, target.organization_id);
    if (!actorMembership || !["owner", "admin"].includes(actorMembership.role)) {
      throw forbidden("Only owner/admin can update memberships");
    }

    const { role, status } = req.body;
    if (role !== undefined && !["owner", "admin", "user", "billing", "read_only"].includes(role)) {
      throw badRequest("Invalid role");
    }
    if (status !== undefined && !["active", "pending", "invited", "suspended"].includes(status)) {
      throw badRequest("Invalid status");
    }
    if (target.user_id === req.user.id && role && role !== actorMembership.role) {
      throw badRequest("Self-role changes are not allowed through this endpoint");
    }

    const fields = [
      ["role", role],
      ["status", status],
    ].filter(([, value]) => value !== undefined);

    if (!fields.length) {
      throw badRequest("No update fields provided");
    }

    const setClause = fields.map(([column], idx) => `${column} = $${idx + 1}`).join(", ");
    const values = fields.map(([, value]) => value);
    values.push(membershipId);

    const result = await query(
      `
        UPDATE organization_memberships
        SET ${setClause}, updated_at = NOW()
        WHERE id = $${values.length}
        RETURNING *
      `,
      values
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId: target.organization_id,
      action: "membership_updated",
      entityType: "organization_membership",
      entityId: membershipId,
      metadata: {
        updatedFields: fields.map(([column]) => column),
      },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ membership: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.delete("/:membershipId", requireAuth, async (req, res, next) => {
  try {
    const membershipId = Number(req.params.membershipId);
    const targetResult = await query(
      `
        SELECT *
        FROM organization_memberships
        WHERE id = $1
      `,
      [membershipId]
    );

    const target = targetResult.rows[0];
    if (!target) {
      throw notFound("Membership not found");
    }

    const actorMembership = await loadMembership(req.user.id, target.organization_id);
    if (!actorMembership || !["owner", "admin"].includes(actorMembership.role)) {
      throw forbidden("Only owner/admin can remove memberships");
    }
    if (target.role === "owner") {
      throw badRequest("Owner membership cannot be removed through this endpoint");
    }

    await query(
      `DELETE FROM organization_memberships WHERE id = $1`,
      [membershipId]
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId: target.organization_id,
      action: "membership_deleted",
      entityType: "organization_membership",
      entityId: membershipId,
      metadata: {
        removedUserId: target.user_id,
        removedRole: target.role,
      },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
