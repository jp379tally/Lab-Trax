const express = require("express");
const { query, withTransaction } = require("../db");
const { badRequest, forbidden, notFound } = require("../utils/errors");
const { requireAuth } = require("../middleware/auth");
const { requireOrgRole } = require("../middleware/organizationAccess");
const { writeAuditLog } = require("../utils/audit");
const { getRequestIp } = require("../utils/security");

const router = express.Router();

router.post("/", requireAuth, async (req, res, next) => {
  try {
    const {
      type,
      name,
      displayName = null,
      billingEmail = null,
      phone = null,
      addressLine1 = null,
      addressLine2 = null,
      city = null,
      state = null,
      zip = null,
    } = req.body;

    if (!["lab", "provider"].includes(type)) {
      throw badRequest("type must be lab or provider");
    }
    if (!name) {
      throw badRequest("name is required");
    }

    const org = await withTransaction(async (client) => {
      const orgResult = await client.query(
        `
          INSERT INTO organizations
          (type, name, display_name, billing_email, phone, address_line_1, address_line_2, city, state, zip, is_active, created_by_user_id)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true,$11)
          RETURNING *
        `,
        [type, name, displayName, billingEmail, phone, addressLine1, addressLine2, city, state, zip, req.user.id]
      );

      const createdOrg = orgResult.rows[0];

      await client.query(
        `
          INSERT INTO organization_memberships
          (organization_id, user_id, role, status, approved_by_user_id, joined_at)
          VALUES ($1,$2,'owner','active',$2,NOW())
        `,
        [createdOrg.id, req.user.id]
      );

      return createdOrg;
    });

    await writeAuditLog({
      userId: req.user.id,
      organizationId: org.id,
      action: "organization_created",
      entityType: "organization",
      entityId: org.id,
      metadata: { type: org.type, name: org.name },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.status(201).json({ organization: org });
  } catch (error) {
    next(error);
  }
});

router.get("/:id", requireAuth, async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const membership = await query(
      `
        SELECT om.id
        FROM organization_memberships om
        WHERE om.organization_id = $1
          AND om.user_id = $2
          AND om.status = 'active'
      `,
      [organizationId, req.user.id]
    );

    if (membership.rowCount === 0) {
      throw forbidden("No access to this organization");
    }

    const orgResult = await query(
      `SELECT * FROM organizations WHERE id = $1`,
      [organizationId]
    );

    const org = orgResult.rows[0];
    if (!org) {
      throw notFound("Organization not found");
    }

    return res.json({ organization: org });
  } catch (error) {
    next(error);
  }
});

router.patch("/:id", requireAuth, requireOrgRole(["owner", "admin"]), async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const fields = [
      ["display_name", req.body.displayName],
      ["billing_email", req.body.billingEmail],
      ["phone", req.body.phone],
      ["address_line_1", req.body.addressLine1],
      ["address_line_2", req.body.addressLine2],
      ["city", req.body.city],
      ["state", req.body.state],
      ["zip", req.body.zip],
      ["name", req.body.name],
    ].filter(([, value]) => value !== undefined);

    if (!fields.length) {
      throw badRequest("No update fields provided");
    }

    const setClause = fields.map(([column], idx) => `${column} = $${idx + 1}`).join(", ");
    const values = fields.map(([, value]) => value);
    values.push(organizationId);

    const result = await query(
      `
        UPDATE organizations
        SET ${setClause}, updated_at = NOW()
        WHERE id = $${values.length}
        RETURNING *
      `,
      values
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId,
      action: "organization_updated",
      entityType: "organization",
      entityId: organizationId,
      metadata: { updatedFields: fields.map(([column]) => column) },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ organization: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.get("/:id/members", requireAuth, requireOrgRole(["owner", "admin"]), async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const result = await query(
      `
        SELECT
          om.id,
          om.role,
          om.status,
          om.joined_at,
          u.id AS user_id,
          u.email,
          u.first_name,
          u.last_name,
          u.initials,
          u.is_active
        FROM organization_memberships om
        INNER JOIN users u ON u.id = om.user_id
        WHERE om.organization_id = $1
        ORDER BY om.created_at ASC
      `,
      [organizationId]
    );

    return res.json({ members: result.rows });
  } catch (error) {
    next(error);
  }
});

router.post("/:id/join-requests", requireAuth, async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const requestedRole = req.body.requestedRole || "user";
    const message = req.body.message || null;

    if (!["user", "admin", "billing", "read_only"].includes(requestedRole)) {
      throw badRequest("Invalid requestedRole");
    }

    const orgExists = await query(`SELECT id FROM organizations WHERE id = $1 AND is_active = true`, [organizationId]);
    if (orgExists.rowCount === 0) {
      throw notFound("Organization not found");
    }

    const existingMembership = await query(
      `
        SELECT id
        FROM organization_memberships
        WHERE organization_id = $1 AND user_id = $2 AND status IN ('active', 'pending', 'invited')
      `,
      [organizationId, req.user.id]
    );

    if (existingMembership.rowCount > 0) {
      throw badRequest("User already has a related membership state for this organization");
    }

    const existingRequest = await query(
      `
        SELECT id
        FROM organization_join_requests
        WHERE organization_id = $1 AND requested_by_user_id = $2 AND status = 'pending'
      `,
      [organizationId, req.user.id]
    );

    if (existingRequest.rowCount > 0) {
      throw badRequest("A join request is already pending");
    }

    const result = await query(
      `
        INSERT INTO organization_join_requests
        (organization_id, requested_by_user_id, requested_role, message, status)
        VALUES ($1,$2,$3,$4,'pending')
        RETURNING *
      `,
      [organizationId, req.user.id, requestedRole, message]
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId,
      action: "join_request_created",
      entityType: "organization_join_request",
      entityId: result.rows[0].id,
      metadata: { requestedRole },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.status(201).json({ joinRequest: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.get("/:id/join-requests", requireAuth, requireOrgRole(["owner", "admin"]), async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const result = await query(
      `
        SELECT
          ojr.*,
          u.email,
          u.first_name,
          u.last_name,
          u.initials
        FROM organization_join_requests ojr
        INNER JOIN users u ON u.id = ojr.requested_by_user_id
        WHERE ojr.organization_id = $1
        ORDER BY ojr.created_at DESC
      `,
      [organizationId]
    );

    return res.json({ joinRequests: result.rows });
  } catch (error) {
    next(error);
  }
});

router.post("/:id/invites", requireAuth, requireOrgRole(["owner", "admin"]), async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const { email, phone = null, roleToAssign = "user" } = req.body;
    const { generateToken } = require("../utils/security");

    if (!email) {
      throw badRequest("email is required");
    }

    if (!["admin", "user", "billing", "read_only"].includes(roleToAssign)) {
      throw badRequest("Invalid roleToAssign");
    }

    const token = generateToken(24);
    const expiresHours = Number(process.env.INVITE_EXPIRES_HOURS || 168);

    const result = await query(
      `
        INSERT INTO organization_invites
        (organization_id, email, phone, role_to_assign, token, status, invited_by_user_id, expires_at)
        VALUES ($1,$2,$3,$4,$5,'pending',$6,NOW() + ($7 || ' hours')::interval)
        RETURNING *
      `,
      [organizationId, email.toLowerCase(), phone, roleToAssign, token, req.user.id, String(expiresHours)]
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId,
      action: "organization_invite_created",
      entityType: "organization_invite",
      entityId: result.rows[0].id,
      metadata: { email: email.toLowerCase(), roleToAssign },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.status(201).json({ invite: result.rows[0] });
  } catch (error) {
    next(error);
  }
});

router.get("/:id/invites", requireAuth, requireOrgRole(["owner", "admin"]), async (req, res, next) => {
  try {
    const organizationId = Number(req.params.id);
    const result = await query(
      `
        SELECT *
        FROM organization_invites
        WHERE organization_id = $1
        ORDER BY created_at DESC
      `,
      [organizationId]
    );

    return res.json({ invites: result.rows });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
