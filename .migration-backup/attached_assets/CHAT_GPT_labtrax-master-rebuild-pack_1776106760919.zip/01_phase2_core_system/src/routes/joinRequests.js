const express = require("express");
const { query, withTransaction } = require("../db");
const { badRequest, forbidden, notFound } = require("../utils/errors");
const { requireAuth } = require("../middleware/auth");
const { loadMembership } = require("../middleware/organizationAccess");
const { writeAuditLog } = require("../utils/audit");
const { getRequestIp } = require("../utils/security");

const router = express.Router();

router.post("/:requestId/approve", requireAuth, async (req, res, next) => {
  try {
    const requestId = Number(req.params.requestId);
    const requestResult = await query(
      `
        SELECT *
        FROM organization_join_requests
        WHERE id = $1
      `,
      [requestId]
    );

    const joinRequest = requestResult.rows[0];
    if (!joinRequest) {
      throw notFound("Join request not found");
    }
    if (joinRequest.status !== "pending") {
      throw badRequest("Join request is not pending");
    }

    const approverMembership = await loadMembership(req.user.id, joinRequest.organization_id);
    if (!approverMembership || !["owner", "admin"].includes(approverMembership.role)) {
      throw forbidden("Only owner/admin can approve join requests");
    }

    const result = await withTransaction(async (client) => {
      const existingMembership = await client.query(
        `
          SELECT id
          FROM organization_memberships
          WHERE organization_id = $1 AND user_id = $2
        `,
        [joinRequest.organization_id, joinRequest.requested_by_user_id]
      );

      let membership;
      if (existingMembership.rowCount > 0) {
        const updated = await client.query(
          `
            UPDATE organization_memberships
            SET role = $1, status = 'active', approved_by_user_id = $2, joined_at = NOW(), updated_at = NOW()
            WHERE organization_id = $3 AND user_id = $4
            RETURNING *
          `,
          [joinRequest.requested_role, req.user.id, joinRequest.organization_id, joinRequest.requested_by_user_id]
        );
        membership = updated.rows[0];
      } else {
        const inserted = await client.query(
          `
            INSERT INTO organization_memberships
            (organization_id, user_id, role, status, approved_by_user_id, joined_at)
            VALUES ($1,$2,$3,'active',$4,NOW())
            RETURNING *
          `,
          [joinRequest.organization_id, joinRequest.requested_by_user_id, joinRequest.requested_role, req.user.id]
        );
        membership = inserted.rows[0];
      }

      await client.query(
        `
          UPDATE organization_join_requests
          SET status = 'approved', reviewed_by_user_id = $1, reviewed_at = NOW()
          WHERE id = $2
        `,
        [req.user.id, requestId]
      );

      return membership;
    });

    await writeAuditLog({
      userId: req.user.id,
      organizationId: joinRequest.organization_id,
      action: "join_request_approved",
      entityType: "organization_join_request",
      entityId: requestId,
      metadata: {
        requestedByUserId: joinRequest.requested_by_user_id,
        assignedRole: joinRequest.requested_role,
      },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ membership: result });
  } catch (error) {
    next(error);
  }
});

router.post("/:requestId/reject", requireAuth, async (req, res, next) => {
  try {
    const requestId = Number(req.params.requestId);
    const requestResult = await query(
      `SELECT * FROM organization_join_requests WHERE id = $1`,
      [requestId]
    );

    const joinRequest = requestResult.rows[0];
    if (!joinRequest) {
      throw notFound("Join request not found");
    }
    if (joinRequest.status !== "pending") {
      throw badRequest("Join request is not pending");
    }

    const approverMembership = await loadMembership(req.user.id, joinRequest.organization_id);
    if (!approverMembership || !["owner", "admin"].includes(approverMembership.role)) {
      throw forbidden("Only owner/admin can reject join requests");
    }

    await query(
      `
        UPDATE organization_join_requests
        SET status = 'rejected', reviewed_by_user_id = $1, reviewed_at = NOW()
        WHERE id = $2
      `,
      [req.user.id, requestId]
    );

    await writeAuditLog({
      userId: req.user.id,
      organizationId: joinRequest.organization_id,
      action: "join_request_rejected",
      entityType: "organization_join_request",
      entityId: requestId,
      metadata: {
        requestedByUserId: joinRequest.requested_by_user_id,
        requestedRole: joinRequest.requested_role,
      },
      ipAddress: getRequestIp(req),
      userAgent: req.headers["user-agent"] || null,
    });

    return res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
