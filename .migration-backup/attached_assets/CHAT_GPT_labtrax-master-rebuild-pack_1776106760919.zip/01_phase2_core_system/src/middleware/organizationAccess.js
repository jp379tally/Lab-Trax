const { query } = require("../db");
const { forbidden } = require("../utils/errors");

async function loadMembership(userId, organizationId) {
  const result = await query(
    `
      SELECT
        om.id,
        om.organization_id,
        om.user_id,
        om.role,
        om.status,
        o.type AS organization_type,
        o.name AS organization_name
      FROM organization_memberships om
      INNER JOIN organizations o ON o.id = om.organization_id
      WHERE om.user_id = $1
        AND om.organization_id = $2
        AND om.status = 'active'
    `,
    [userId, organizationId]
  );
  return result.rows[0] || null;
}

function requireOrgRole(roles = []) {
  return async function(req, _res, next) {
    try {
      const organizationId = Number(
        req.params.id ||
        req.params.organizationId ||
        req.body.organizationId ||
        req.query.organizationId
      );

      if (!organizationId) {
        throw forbidden("Organization ID is required");
      }

      const membership = await loadMembership(req.user.id, organizationId);
      if (!membership) {
        throw forbidden("No active membership for this organization");
      }

      if (roles.length && !roles.includes(membership.role)) {
        throw forbidden("You do not have permission for this action");
      }

      req.organizationMembership = membership;
      next();
    } catch (error) {
      next(error);
    }
  };
}

module.exports = {
  loadMembership,
  requireOrgRole,
};
