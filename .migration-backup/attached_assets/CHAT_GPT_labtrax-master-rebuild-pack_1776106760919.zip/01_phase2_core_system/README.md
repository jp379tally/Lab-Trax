# LabTrax Phase 2 Core System

This folder is a drag-and-drop backend starter for Replit focused on the core system:

- secure auth with bcrypt + JWT
- organizations (lab/provider)
- memberships with roles
- join requests
- invites
- role-based permission middleware
- current user bootstrap endpoint
- audit logging

## Quick start

1. Upload this folder into a Node.js Replit
2. Run:
   ```bash
   npm install
   ```
3. Create `.env` from `.env.example`
4. Run the SQL in `sql/001_phase2_core.sql`
5. Start:
   ```bash
   npm run dev
   ```

## Main endpoints

### Health
- `GET /api/health`

### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`

### Organizations
- `POST /api/organizations`
- `GET /api/organizations/:id`
- `PATCH /api/organizations/:id`
- `GET /api/organizations/:id/members`

### Join requests
- `POST /api/organizations/:id/join-requests`
- `GET /api/organizations/:id/join-requests`
- `POST /api/join-requests/:requestId/approve`
- `POST /api/join-requests/:requestId/reject`

### Invites
- `POST /api/organizations/:id/invites`
- `GET /api/organizations/:id/invites`
- `POST /api/invites/:token/accept`

### Memberships
- `PATCH /api/memberships/:membershipId`
- `DELETE /api/memberships/:membershipId`

## Roles

Supported roles:
- `owner`
- `admin`
- `user`
- `billing`
- `read_only`

## Org types
- `lab`
- `provider`

## Notes

- This is a strong starter, not a finished production system.
- You still need to add MFA, session revocation UI, attachment storage, invoice engine, and case engine wiring.
- For HIPAA readiness, keep PHI out of logs and do not email or text PHI directly.
