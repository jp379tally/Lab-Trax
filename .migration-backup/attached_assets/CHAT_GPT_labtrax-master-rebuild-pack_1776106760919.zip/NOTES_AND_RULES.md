# LabTrax Rebuild Notes

## Core product shell
- Two portals: lab and provider
- Users and admins in each portal
- Only lab owner/admin/billing should access financials and invoice editing
- Standard users can create/update cases, add notes, attach files, and move/locate cases
- Provider submissions should require lab admin approval before becoming official case data
- Timeline must be timestamped and attributed to user initials
- App should support scanner import management for platforms like iTero, 3Shape, and SHINING
- App should be designed toward HIPAA-ready technical safeguards

## HIPAA direction reminders
- Use hashed passwords only
- Enforce permissions server-side
- Keep PHI out of plain SMS/email when possible; send secure portal links instead
- Use private storage + signed URLs
- Maintain audit logs
- Use vendor BAAs in production

## Replit deployment reminder
The web deployment failure was tied to Expo web assets not being built into the deployment snapshot. The deployment fix folder addresses that.
