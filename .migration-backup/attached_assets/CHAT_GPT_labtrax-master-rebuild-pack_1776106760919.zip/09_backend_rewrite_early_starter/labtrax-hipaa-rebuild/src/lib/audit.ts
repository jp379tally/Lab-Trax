import type { Request } from 'express';
import { db } from '../db/client.js';
import { auditLogs } from '../db/schema.js';

type AuditInput = {
  req?: Request;
  userId?: string | null;
  organizationId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  beforeJson?: unknown;
  afterJson?: unknown;
  metadataJson?: unknown;
};

export async function writeAuditLog(input: AuditInput) {
  await db.insert(auditLogs).values({
    userId: input.userId ?? input.req?.auth?.userId ?? null,
    organizationId: input.organizationId ?? null,
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId ?? null,
    ipAddress: input.req?.ip ?? null,
    userAgent: input.req?.get('user-agent') ?? null,
    beforeJson: input.beforeJson ?? null,
    afterJson: input.afterJson ?? null,
    metadataJson: input.metadataJson ?? {}
  });
}
