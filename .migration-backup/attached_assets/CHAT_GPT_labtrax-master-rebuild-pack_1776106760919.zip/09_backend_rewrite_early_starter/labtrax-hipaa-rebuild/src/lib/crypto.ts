import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { env } from '../config/env.js';

export async function hashPassword(password: string) {
  return bcrypt.hash(password, env.BCRYPT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export function randomToken(size = 32) {
  return crypto.randomBytes(size).toString('hex');
}

export function sha256(input: string) {
  return crypto.createHash('sha256').update(input).digest('hex');
}
