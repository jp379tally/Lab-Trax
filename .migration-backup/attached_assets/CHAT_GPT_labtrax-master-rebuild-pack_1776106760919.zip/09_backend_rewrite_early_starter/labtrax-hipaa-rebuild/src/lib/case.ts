export function calculateLineTotal(quantity: number, unitPrice: string | number) {
  const unit = typeof unitPrice === 'string' ? Number(unitPrice) : unitPrice;
  return (quantity * unit).toFixed(2);
}

export function sumMoney(values: Array<string | number>) {
  const total = values.reduce((sum, value) => sum + Number(value), 0);
  return total.toFixed(2);
}
