import { Router } from 'express';
import { and, desc, eq, inArray, or } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '../db/client.js';
import {
  caseAttachments,
  caseEvents,
  caseLocations,
  caseNotes,
  caseRestorations,
  caseSubmissionQueue,
  cases,
  organizationConnections,
  organizationMemberships
} from '../db/schema.js';
import { writeAuditLog } from '../lib/audit.js';
import { HttpError, ok } from '../lib/http.js';
import { ADMIN_ROLES, requireAnyRole, requireMembership } from '../lib/rbac.js';
import { asyncHandler } from '../middleware/async-handler.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

async function assertCaseAccess(userId: string, caseId: string) {
  const found = await db.query.cases.findFirst({ where: eq(cases.id, caseId) });
  if (!found) throw new HttpError(404, 'Case not found.');
  const labMembership = await requireMembership(userId, found.labOrganizationId).catch(() => null);
  const providerMembership = await requireMembership(userId, found.providerOrganizationId).catch(() => null);
  if (!labMembership && !providerMembership) throw new HttpError(403, 'You do not have access to this case.');
  return found;
}

const createCaseSchema = z.object({
  caseNumber: z.string().min(1),
  labOrganizationId: z.string().uuid(),
  providerOrganizationId: z.string().uuid(),
  patientFirstName: z.string().min(1),
  patientLastName: z.string().min(1),
  externalPatientId: z.string().optional(),
  doctorName: z.string().min(1),
  priority: z.enum(['normal', 'rush']).default('normal'),
  dueDate: z.string().datetime().optional(),
  restorations: z.array(z.object({
    toothNumber: z.string().min(1),
    restorationType: z.string().min(1),
    material: z.string().optional(),
    shade: z.string().optional(),
    notes: z.string().optional(),
    quantity: z.coerce.number().int().positive().default(1),
    unitPrice: z.coerce.number().min(0).default(0)
  })).min(1)
});

router.post('/', asyncHandler(async (req, res) => {
  const input = createCaseSchema.parse(req.body);
  await requireMembership(req.auth!.userId, input.labOrganizationId);

  const connection = await db.query.organizationConnections.findFirst({
    where: and(
      eq(organizationConnections.labOrganizationId, input.labOrganizationId),
      eq(organizationConnections.providerOrganizationId, input.providerOrganizationId),
      eq(organizationConnections.status, 'active')
    )
  });
  if (!connection) throw new HttpError(400, 'The provider office is not connected to this lab.');

  const [createdCase] = await db.insert(cases).values({
    caseNumber: input.caseNumber,
    labOrganizationId: input.labOrganizationId,
    providerOrganizationId: input.providerOrganizationId,
    patientFirstName: input.patientFirstName,
    patientLastName: input.patientLastName,
    externalPatientId: input.externalPatientId ?? null,
    doctorName: input.doctorName,
    priority: input.priority,
    dueDate: input.dueDate ? new Date(input.dueDate) : null,
    createdByUserId: req.auth!.userId
  }).returning();

  await db.insert(caseRestorations).values(input.restorations.map(restoration => ({
    caseId: createdCase.id,
    toothNumber: restoration.toothNumber,
    restorationType: restoration.restorationType,
    material: restoration.material ?? null,
    shade: restoration.shade ?? null,
    notes: restoration.notes ?? null,
    quantity: restoration.quantity,
    unitPrice: restoration.unitPrice.toFixed(2)
  })));

  await db.insert(caseEvents).values({
    caseId: createdCase.id,
    eventType: 'case_created',
    actorUserId: req.auth!.userId,
    actorOrganizationId: input.labOrganizationId,
    actorInitials: req.user!.initials,
    metadataJson: {
      patientFirstName: input.patientFirstName,
      patientLastName: input.patientLastName,
      restorations: input.restorations.length
    }
  });

  await writeAuditLog({ req, organizationId: input.labOrganizationId, action: 'case_created', entityType: 'case', entityId: createdCase.id, afterJson: createdCase });
  return ok(res, createdCase, 201);
}));

router.get('/', asyncHandler(async (req, res) => {
  const membershipOrgIds = req.query.organizationId
    ? [z.string().uuid().parse(req.query.organizationId)]
    : (await db.query.organizationMemberships.findMany({ where: eq(organizationMemberships.userId, req.auth!.userId) })).map(m => m.organizationId);

  const rows = membershipOrgIds.length
    ? await db.query.cases.findMany({
        where: or(
          inArray(cases.labOrganizationId, membershipOrgIds),
          inArray(cases.providerOrganizationId, membershipOrgIds)
        ),
        orderBy: [desc(cases.createdAt)]
      })
    : [];

  return ok(res, rows);
}));

router.get('/:caseId', asyncHandler(async (req, res) => {
  const found = await assertCaseAccess(req.auth!.userId, req.params.caseId);
  const [restorations, notes, attachments, events] = await Promise.all([
    db.query.caseRestorations.findMany({ where: eq(caseRestorations.caseId, found.id) }),
    db.query.caseNotes.findMany({ where: eq(caseNotes.caseId, found.id), orderBy: [desc(caseNotes.createdAt)] }),
    db.query.caseAttachments.findMany({ where: eq(caseAttachments.caseId, found.id), orderBy: [desc(caseAttachments.createdAt)] }),
    db.query.caseEvents.findMany({ where: eq(caseEvents.caseId, found.id), orderBy: [desc(caseEvents.occurredAt)] })
  ]);

  await writeAuditLog({ req, organizationId: found.labOrganizationId, action: 'case_viewed', entityType: 'case', entityId: found.id });
  return ok(res, { ...found, restorations, notes, attachments, events });
}));

router.post('/:caseId/notes', asyncHandler(async (req, res) => {
  const found = await assertCaseAccess(req.auth!.userId, req.params.caseId);
  const input = z.object({ noteText: z.string().min(1), visibility: z.enum(['internal_lab_only', 'shared_with_provider']).default('shared_with_provider') }).parse(req.body);

  const authorOrgId = (await requireMembership(req.auth!.userId, found.labOrganizationId).catch(() => null))?.organizationId ?? found.providerOrganizationId;
  const [note] = await db.insert(caseNotes).values({
    caseId: found.id,
    authorUserId: req.auth!.userId,
    authorOrganizationId: authorOrgId,
    noteText: input.noteText,
    visibility: input.visibility
  }).returning();

  await db.insert(caseEvents).values({
    caseId: found.id,
    eventType: 'note_added',
    actorUserId: req.auth!.userId,
    actorOrganizationId: authorOrgId,
    actorInitials: req.user!.initials,
    metadataJson: { visibility: input.visibility, noteId: note.id }
  });

  return ok(res, note, 201);
}));

router.post('/:caseId/location-changes', asyncHandler(async (req, res) => {
  const found = await assertCaseAccess(req.auth!.userId, req.params.caseId);
  await requireMembership(req.auth!.userId, found.labOrganizationId);
  const input = z.object({ locationCode: z.string().min(1), locationName: z.string().min(1), notes: z.string().optional() }).parse(req.body);

  const [location] = await db.insert(caseLocations).values({
    caseId: found.id,
    locationCode: input.locationCode,
    locationName: input.locationName,
    movedByUserId: req.auth!.userId,
    notes: input.notes ?? null
  }).returning();

  await db.insert(caseEvents).values({
    caseId: found.id,
    eventType: 'location_changed',
    actorUserId: req.auth!.userId,
    actorOrganizationId: found.labOrganizationId,
    actorInitials: req.user!.initials,
    metadataJson: { locationCode: input.locationCode, locationName: input.locationName }
  });

  return ok(res, location, 201);
}));

router.post('/:caseId/submissions', asyncHandler(async (req, res) => {
  const found = await assertCaseAccess(req.auth!.userId, req.params.caseId);
  await requireMembership(req.auth!.userId, found.providerOrganizationId);
  const input = z.object({ submissionType: z.enum(['note', 'photo', 'video', 'document']), payloadJson: z.record(z.any()) }).parse(req.body);

  const [submission] = await db.insert(caseSubmissionQueue).values({
    caseId: found.id,
    submittedByUserId: req.auth!.userId,
    submittedByOrganizationId: found.providerOrganizationId,
    submissionType: input.submissionType,
    payloadJson: input.payloadJson
  }).returning();

  await db.insert(caseEvents).values({
    caseId: found.id,
    eventType: 'provider_submission_received',
    actorUserId: req.auth!.userId,
    actorOrganizationId: found.providerOrganizationId,
    actorInitials: req.user!.initials,
    metadataJson: { submissionId: submission.id, submissionType: submission.submissionType }
  });

  return ok(res, submission, 201);
}));

router.get('/:caseId/submissions', asyncHandler(async (req, res) => {
  const found = await assertCaseAccess(req.auth!.userId, req.params.caseId);
  await requireAnyRole(req.auth!.userId, found.labOrganizationId, ADMIN_ROLES);
  const submissions = await db.query.caseSubmissionQueue.findMany({ where: eq(caseSubmissionQueue.caseId, found.id), orderBy: [desc(caseSubmissionQueue.createdAt)] });
  return ok(res, submissions);
}));

router.post('/submissions/:submissionId/approve', asyncHandler(async (req, res) => {
  const submission = await db.query.caseSubmissionQueue.findFirst({ where: eq(caseSubmissionQueue.id, req.params.submissionId) });
  if (!submission) throw new HttpError(404, 'Submission not found.');
  const found = await assertCaseAccess(req.auth!.userId, submission.caseId);
  await requireAnyRole(req.auth!.userId, found.labOrganizationId, ADMIN_ROLES);

  const [approved] = await db.update(caseSubmissionQueue)
    .set({ status: 'approved', reviewedByUserId: req.auth!.userId, reviewedAt: new Date() })
    .where(eq(caseSubmissionQueue.id, submission.id))
    .returning();

  if (submission.submissionType === 'note' && typeof submission.payloadJson?.noteText === 'string') {
    await db.insert(caseNotes).values({
      caseId: submission.caseId,
      authorUserId: submission.submittedByUserId,
      authorOrganizationId: submission.submittedByOrganizationId,
      noteText: submission.payloadJson.noteText,
      visibility: 'shared_with_provider'
    });
  }

  await db.insert(caseEvents).values({
    caseId: submission.caseId,
    eventType: 'provider_submission_approved',
    actorUserId: req.auth!.userId,
    actorOrganizationId: found.labOrganizationId,
    actorInitials: req.user!.initials,
    metadataJson: { submissionId: submission.id, submissionType: submission.submissionType }
  });

  return ok(res, approved);
}));

router.post('/submissions/:submissionId/reject', asyncHandler(async (req, res) => {
  const submission = await db.query.caseSubmissionQueue.findFirst({ where: eq(caseSubmissionQueue.id, req.params.submissionId) });
  if (!submission) throw new HttpError(404, 'Submission not found.');
  const found = await assertCaseAccess(req.auth!.userId, submission.caseId);
  await requireAnyRole(req.auth!.userId, found.labOrganizationId, ADMIN_ROLES);
  const input = z.object({ reviewNotes: z.string().max(1000).optional() }).parse(req.body ?? {});

  const [rejected] = await db.update(caseSubmissionQueue)
    .set({ status: 'rejected', reviewedByUserId: req.auth!.userId, reviewedAt: new Date(), reviewNotes: input.reviewNotes ?? null })
    .where(eq(caseSubmissionQueue.id, submission.id))
    .returning();

  await db.insert(caseEvents).values({
    caseId: submission.caseId,
    eventType: 'provider_submission_rejected',
    actorUserId: req.auth!.userId,
    actorOrganizationId: found.labOrganizationId,
    actorInitials: req.user!.initials,
    metadataJson: { submissionId: submission.id }
  });

  return ok(res, rejected);
}));

export default router;
