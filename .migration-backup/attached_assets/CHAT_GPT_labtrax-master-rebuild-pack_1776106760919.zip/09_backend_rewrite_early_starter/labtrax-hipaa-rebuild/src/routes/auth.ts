import crypto from 'node:crypto';
import { Router } from 'express';
import { and, eq, gt, inArray, isNull } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '../db/client.js';
import { organizationMemberships, organizations, userSessions, users } from '../db/schema.js';
import { signAccessToken, signRefreshToken, verifyRefreshToken, makeSessionHash } from '../lib/auth.js';
import { hashPassword, verifyPassword } from '../lib/crypto.js';
import { HttpError, ok } from '../lib/http.js';
import { asyncHandler } from '../middleware/async-handler.js';
import { requireAuth } from '../middleware/auth.js';
import { writeAuditLog } from '../lib/audit.js';

const router = Router();

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(12),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  initials: z.string().min(1).max(10)
});

router.post('/register', asyncHandler(async (req, res) => {
  const input = registerSchema.parse(req.body);
  const existing = await db.query.users.findFirst({ where: eq(users.email, input.email.toLowerCase()) });
  if (existing) throw new HttpError(409, 'An account already exists for that email.');

  const [user] = await db.insert(users).values({
    email: input.email.toLowerCase(),
    passwordHash: await hashPassword(input.password),
    firstName: input.firstName,
    lastName: input.lastName,
    initials: input.initials.toUpperCase()
  }).returning();

  await writeAuditLog({ req, userId: user.id, action: 'user_registered', entityType: 'user', entityId: user.id, afterJson: { email: user.email } });
  return ok(res, { userId: user.id }, 201);
}));

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  deviceName: z.string().max(180).optional()
});

router.post('/login', asyncHandler(async (req, res) => {
  const input = loginSchema.parse(req.body);
  const user = await db.query.users.findFirst({ where: eq(users.email, input.email.toLowerCase()) });
  if (!user) throw new HttpError(401, 'Invalid email or password.');

  const valid = await verifyPassword(input.password, user.passwordHash);
  if (!valid) {
    await writeAuditLog({ req, userId: user.id, action: 'login_failed', entityType: 'user', entityId: user.id });
    throw new HttpError(401, 'Invalid email or password.');
  }

  const rawRefreshToken = signRefreshToken(user.id, crypto.randomUUID());
  const decoded = verifyRefreshToken(rawRefreshToken);
  const [session] = await db.insert(userSessions).values({
    id: decoded.sid,
    userId: user.id,
    tokenHash: makeSessionHash(rawRefreshToken),
    deviceName: input.deviceName ?? null,
    ipAddress: req.ip,
    userAgent: req.get('user-agent') ?? null,
    expiresAt: new Date((decoded.exp ?? 0) * 1000)
  }).returning();

  const accessToken = signAccessToken(user.id, session.id);
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
  await writeAuditLog({ req, userId: user.id, action: 'login_succeeded', entityType: 'session', entityId: session.id });

  return ok(res, {
    accessToken,
    refreshToken: rawRefreshToken,
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      initials: user.initials
    }
  });
}));

const refreshSchema = z.object({ refreshToken: z.string().min(1) });
router.post('/refresh', asyncHandler(async (req, res) => {
  const { refreshToken } = refreshSchema.parse(req.body);
  const payload = verifyRefreshToken(refreshToken);
  const session = await db.query.userSessions.findFirst({
    where: and(
      eq(userSessions.id, payload.sid),
      eq(userSessions.userId, payload.sub),
      eq(userSessions.tokenHash, makeSessionHash(refreshToken)),
      isNull(userSessions.revokedAt),
      gt(userSessions.expiresAt, new Date())
    )
  });

  if (!session) throw new HttpError(401, 'Refresh token is invalid or expired.');
  const accessToken = signAccessToken(payload.sub, payload.sid);
  return ok(res, { accessToken });
}));

router.post('/logout', requireAuth, asyncHandler(async (req, res) => {
  await db.update(userSessions).set({ revokedAt: new Date() }).where(eq(userSessions.id, req.auth!.sessionId));
  await writeAuditLog({ req, action: 'logout', entityType: 'session', entityId: req.auth!.sessionId });
  return ok(res, { loggedOut: true });
}));

router.get('/me', requireAuth, asyncHandler(async (req, res) => {
  const memberships = await db.query.organizationMemberships.findMany({
    where: eq(organizationMemberships.userId, req.auth!.userId)
  });
  const orgIds = memberships.map(m => m.organizationId);
  const orgs = orgIds.length ? await db.select().from(organizations).where(inArray(organizations.id, orgIds)) : [];

  return ok(res, {
    user: req.user,
    memberships: memberships.map(m => ({
      id: m.id,
      role: m.role,
      status: m.status,
      organization: orgs.find(org => org.id === m.organizationId) ?? null
    }))
  });
}));

export default router;
