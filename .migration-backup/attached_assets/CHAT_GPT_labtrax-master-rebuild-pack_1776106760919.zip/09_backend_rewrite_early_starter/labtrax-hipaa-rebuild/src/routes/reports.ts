import { Router } from 'express';
import { and, eq, gte, lte, sum } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '../db/client.js';
import { invoices } from '../db/schema.js';
import { HttpError, ok } from '../lib/http.js';
import { BILLING_ROLES, requireAnyRole } from '../lib/rbac.js';
import { asyncHandler } from '../middleware/async-handler.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

router.get('/sales', asyncHandler(async (req, res) => {
  const query = z.object({
    organizationId: z.string().uuid(),
    dateFrom: z.string().datetime().optional(),
    dateTo: z.string().datetime().optional()
  }).parse(req.query);

  await requireAnyRole(req.auth!.userId, query.organizationId, BILLING_ROLES);

  const rows = await db.query.invoices.findMany({
    where: and(
      eq(invoices.labOrganizationId, query.organizationId),
      query.dateFrom ? gte(invoices.createdAt, new Date(query.dateFrom)) : undefined,
      query.dateTo ? lte(invoices.createdAt, new Date(query.dateTo)) : undefined
    )
  });

  const totalSales = rows.reduce((acc, row) => acc + Number(row.total), 0).toFixed(2);
  const openBalance = rows.reduce((acc, row) => acc + Number(row.balanceDue), 0).toFixed(2);

  return ok(res, {
    totalSales,
    openBalance,
    invoices: rows.length,
    paidInvoices: rows.filter(row => row.status === 'paid').length,
    openInvoices: rows.filter(row => row.status !== 'paid' && row.status !== 'void').length
  });
}));

router.get('/provider-balance/:providerOrganizationId', asyncHandler(async (req, res) => {
  const query = z.object({ organizationId: z.string().uuid() }).parse(req.query);
  await requireAnyRole(req.auth!.userId, query.organizationId, BILLING_ROLES);

  const rows = await db.query.invoices.findMany({
    where: and(
      eq(invoices.labOrganizationId, query.organizationId),
      eq(invoices.providerOrganizationId, req.params.providerOrganizationId)
    )
  });

  return ok(res, {
    providerOrganizationId: req.params.providerOrganizationId,
    balance: rows.reduce((acc, row) => acc + Number(row.balanceDue), 0).toFixed(2),
    invoices: rows.length
  });
}));

router.get('/ar-aging', asyncHandler(async (req, res) => {
  const query = z.object({ organizationId: z.string().uuid() }).parse(req.query);
  await requireAnyRole(req.auth!.userId, query.organizationId, BILLING_ROLES);

  const rows = await db.query.invoices.findMany({ where: eq(invoices.labOrganizationId, query.organizationId) });
  const now = Date.now();
  const buckets = { current: 0, days30: 0, days60: 0, days90Plus: 0 };

  for (const row of rows) {
    if (Number(row.balanceDue) <= 0) continue;
    const dueAt = row.dueAt?.getTime() ?? row.createdAt.getTime();
    const ageDays = Math.floor((now - dueAt) / (1000 * 60 * 60 * 24));
    if (ageDays <= 30) buckets.current += Number(row.balanceDue);
    else if (ageDays <= 60) buckets.days30 += Number(row.balanceDue);
    else if (ageDays <= 90) buckets.days60 += Number(row.balanceDue);
    else buckets.days90Plus += Number(row.balanceDue);
  }

  return ok(res, Object.fromEntries(Object.entries(buckets).map(([key, value]) => [key, value.toFixed(2)])));
}));

export default router;
