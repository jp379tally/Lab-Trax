import { Router } from 'express';
import { and, eq, inArray } from 'drizzle-orm';
import { z } from 'zod';
import { db } from '../db/client.js';
import {
  organizationConnections,
  organizationInvites,
  organizationJoinRequests,
  organizationMemberships,
  organizations,
  users
} from '../db/schema.js';
import { generateInviteToken } from '../lib/auth.js';
import { writeAuditLog } from '../lib/audit.js';
import { HttpError, ok } from '../lib/http.js';
import { ADMIN_ROLES, requireAnyRole, requireMembership } from '../lib/rbac.js';
import { asyncHandler } from '../middleware/async-handler.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);

const createOrgSchema = z.object({
  type: z.enum(['lab', 'provider']),
  name: z.string().min(1),
  displayName: z.string().optional(),
  billingEmail: z.string().email().optional(),
  phone: z.string().optional(),
  addressLine1: z.string().optional(),
  addressLine2: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zip: z.string().optional()
});

router.post('/', asyncHandler(async (req, res) => {
  const input = createOrgSchema.parse(req.body);

  const [organization] = await db.insert(organizations).values({
    ...input,
    createdByUserId: req.auth!.userId
  }).returning();

  await db.insert(organizationMemberships).values({
    organizationId: organization.id,
    userId: req.auth!.userId,
    role: 'owner',
    status: 'active',
    approvedByUserId: req.auth!.userId,
    joinedAt: new Date()
  });

  await writeAuditLog({
    req,
    organizationId: organization.id,
    action: 'organization_created',
    entityType: 'organization',
    entityId: organization.id,
    afterJson: organization
  });

  return ok(res, organization, 201);
}));

router.get('/:organizationId', asyncHandler(async (req, res) => {
  await requireMembership(req.auth!.userId, req.params.organizationId);
  const organization = await db.query.organizations.findFirst({ where: eq(organizations.id, req.params.organizationId) });
  if (!organization) throw new HttpError(404, 'Organization not found.');
  return ok(res, organization);
}));

router.patch('/:organizationId', asyncHandler(async (req, res) => {
  const organizationId = req.params.organizationId;
  await requireAnyRole(req.auth!.userId, organizationId, ADMIN_ROLES);
  const input = createOrgSchema.partial().parse(req.body);

  const existing = await db.query.organizations.findFirst({ where: eq(organizations.id, organizationId) });
  if (!existing) throw new HttpError(404, 'Organization not found.');

  const [updated] = await db.update(organizations).set(input).where(eq(organizations.id, organizationId)).returning();
  await writeAuditLog({ req, organizationId, action: 'organization_updated', entityType: 'organization', entityId: organizationId, beforeJson: existing, afterJson: updated });
  return ok(res, updated);
}));

router.get('/:organizationId/members', asyncHandler(async (req, res) => {
  const organizationId = req.params.organizationId;
  await requireAnyRole(req.auth!.userId, organizationId, ADMIN_ROLES);

  const memberships = await db.query.organizationMemberships.findMany({ where: eq(organizationMemberships.organizationId, organizationId) });
  const userIds = memberships.map(m => m.userId);
  const allUsers = userIds.length ? await db.query.users.findMany({ where: inArray(users.id, userIds) }) : [];

  return ok(res, memberships.map(membership => ({
    ...membership,
    user: allUsers.find(user => user.id === membership.userId) ?? null
  })));
}));

const inviteSchema = z.object({
  email: z.string().email(),
  phone: z.string().optional(),
  roleToAssign: z.enum(['owner', 'admin', 'user', 'billing', 'read_only']),
  expiresInDays: z.coerce.number().int().min(1).max(30).default(7)
});

router.post('/:organizationId/invites', asyncHandler(async (req, res) => {
  const organizationId = req.params.organizationId;
  await requireAnyRole(req.auth!.userId, organizationId, ADMIN_ROLES);
  const input = inviteSchema.parse(req.body);

  const [invite] = await db.insert(organizationInvites).values({
    organizationId,
    email: input.email.toLowerCase(),
    phone: input.phone ?? null,
    roleToAssign: input.roleToAssign,
    token: generateInviteToken(),
    invitedByUserId: req.auth!.userId,
    expiresAt: new Date(Date.now() + input.expiresInDays * 24 * 60 * 60 * 1000)
  }).returning();

  await writeAuditLog({ req, organizationId, action: 'organization_invite_created', entityType: 'organization_invite', entityId: invite.id, afterJson: invite });
  return ok(res, invite, 201);
}));

const joinRequestSchema = z.object({
  requestedRole: z.enum(['admin', 'user', 'billing', 'read_only']).default('user'),
  message: z.string().max(1000).optional()
});

router.post('/:organizationId/join-requests', asyncHandler(async (req, res) => {
  const organizationId = req.params.organizationId;
  const input = joinRequestSchema.parse(req.body);

  const alreadyMember = await db.query.organizationMemberships.findFirst({
    where: and(eq(organizationMemberships.organizationId, organizationId), eq(organizationMemberships.userId, req.auth!.userId))
  });
  if (alreadyMember) throw new HttpError(409, 'You already have a membership record for this organization.');

  const [request] = await db.insert(organizationJoinRequests).values({
    organizationId,
    requestedByUserId: req.auth!.userId,
    requestedRole: input.requestedRole,
    message: input.message ?? null
  }).returning();

  await writeAuditLog({ req, organizationId, action: 'organization_join_requested', entityType: 'organization_join_request', entityId: request.id, afterJson: request });
  return ok(res, request, 201);
}));

router.get('/:organizationId/join-requests', asyncHandler(async (req, res) => {
  const organizationId = req.params.organizationId;
  await requireAnyRole(req.auth!.userId, organizationId, ADMIN_ROLES);
  const requests = await db.query.organizationJoinRequests.findMany({ where: eq(organizationJoinRequests.organizationId, organizationId) });
  return ok(res, requests);
}));

router.post('/join-requests/:joinRequestId/approve', asyncHandler(async (req, res) => {
  const request = await db.query.organizationJoinRequests.findFirst({ where: eq(organizationJoinRequests.id, req.params.joinRequestId) });
  if (!request) throw new HttpError(404, 'Join request not found.');

  await requireAnyRole(req.auth!.userId, request.organizationId, ADMIN_ROLES);

  const [membership] = await db.insert(organizationMemberships).values({
    organizationId: request.organizationId,
    userId: request.requestedByUserId,
    role: request.requestedRole,
    status: 'active',
    approvedByUserId: req.auth!.userId,
    joinedAt: new Date()
  }).onConflictDoUpdate({
    target: [organizationMemberships.organizationId, organizationMemberships.userId],
    set: {
      role: request.requestedRole,
      status: 'active',
      approvedByUserId: req.auth!.userId,
      joinedAt: new Date()
    }
  }).returning();

  const [updatedRequest] = await db.update(organizationJoinRequests)
    .set({ status: 'approved', reviewedByUserId: req.auth!.userId, reviewedAt: new Date() })
    .where(eq(organizationJoinRequests.id, request.id))
    .returning();

  await writeAuditLog({ req, organizationId: request.organizationId, action: 'organization_join_approved', entityType: 'organization_join_request', entityId: request.id, afterJson: updatedRequest });
  return ok(res, { membership, request: updatedRequest });
}));

router.post('/join-requests/:joinRequestId/reject', asyncHandler(async (req, res) => {
  const request = await db.query.organizationJoinRequests.findFirst({ where: eq(organizationJoinRequests.id, req.params.joinRequestId) });
  if (!request) throw new HttpError(404, 'Join request not found.');
  await requireAnyRole(req.auth!.userId, request.organizationId, ADMIN_ROLES);

  const [updated] = await db.update(organizationJoinRequests)
    .set({ status: 'rejected', reviewedByUserId: req.auth!.userId, reviewedAt: new Date() })
    .where(eq(organizationJoinRequests.id, request.id))
    .returning();

  await writeAuditLog({ req, organizationId: request.organizationId, action: 'organization_join_rejected', entityType: 'organization_join_request', entityId: request.id, afterJson: updated });
  return ok(res, updated);
}));

const connectionSchema = z.object({
  labOrganizationId: z.string().uuid(),
  providerOrganizationId: z.string().uuid()
});

router.post('/connections', asyncHandler(async (req, res) => {
  const input = connectionSchema.parse(req.body);
  const isLabMember = await requireMembership(req.auth!.userId, input.labOrganizationId).catch(() => null);
  const isProviderMember = await requireMembership(req.auth!.userId, input.providerOrganizationId).catch(() => null);
  if (!isLabMember && !isProviderMember) throw new HttpError(403, 'You must belong to one side of the connection request.');

  const [connection] = await db.insert(organizationConnections).values({
    labOrganizationId: input.labOrganizationId,
    providerOrganizationId: input.providerOrganizationId,
    requestedByOrgId: isLabMember ? input.labOrganizationId : input.providerOrganizationId,
    requestedByUserId: req.auth!.userId
  }).onConflictDoNothing().returning();

  return ok(res, connection ?? { alreadyExists: true }, connection ? 201 : 200);
}));

router.post('/connections/:connectionId/approve', asyncHandler(async (req, res) => {
  const connection = await db.query.organizationConnections.findFirst({ where: eq(organizationConnections.id, req.params.connectionId) });
  if (!connection) throw new HttpError(404, 'Connection not found.');

  const targetOrgId = connection.requestedByOrgId === connection.labOrganizationId ? connection.providerOrganizationId : connection.labOrganizationId;
  await requireAnyRole(req.auth!.userId, targetOrgId, ADMIN_ROLES);

  const [updated] = await db.update(organizationConnections)
    .set({ status: 'active', approvedByUserId: req.auth!.userId, approvedAt: new Date() })
    .where(eq(organizationConnections.id, connection.id))
    .returning();

  await writeAuditLog({ req, organizationId: targetOrgId, action: 'organization_connection_approved', entityType: 'organization_connection', entityId: connection.id, afterJson: updated });
  return ok(res, updated);
}));

router.patch('/memberships/:membershipId', asyncHandler(async (req, res) => {
  const input = z.object({
    role: z.enum(['owner', 'admin', 'user', 'billing', 'read_only']).optional(),
    status: z.enum(['active', 'pending', 'invited', 'suspended']).optional()
  }).parse(req.body);

  const membership = await db.query.organizationMemberships.findFirst({ where: eq(organizationMemberships.id, req.params.membershipId) });
  if (!membership) throw new HttpError(404, 'Membership not found.');
  await requireAnyRole(req.auth!.userId, membership.organizationId, ADMIN_ROLES);

  const [updated] = await db.update(organizationMemberships).set(input).where(eq(organizationMemberships.id, membership.id)).returning();
  await writeAuditLog({ req, organizationId: membership.organizationId, action: 'membership_updated', entityType: 'organization_membership', entityId: membership.id, beforeJson: membership, afterJson: updated });
  return ok(res, updated);
}));

export default router;
