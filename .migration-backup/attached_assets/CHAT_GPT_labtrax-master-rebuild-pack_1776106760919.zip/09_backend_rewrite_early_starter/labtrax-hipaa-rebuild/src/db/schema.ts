import { relations, sql } from 'drizzle-orm';
import {
  boolean,
  decimal,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
  varchar
} from 'drizzle-orm/pg-core';

const createdAt = () => timestamp('created_at', { withTimezone: true }).defaultNow().notNull();
const updatedAt = () => timestamp('updated_at', { withTimezone: true }).defaultNow().notNull();

export const organizationTypeEnum = pgEnum('organization_type', ['lab', 'provider']);
export const membershipRoleEnum = pgEnum('membership_role', ['owner', 'admin', 'user', 'billing', 'read_only']);
export const membershipStatusEnum = pgEnum('membership_status', ['active', 'pending', 'invited', 'suspended']);
export const joinRequestStatusEnum = pgEnum('join_request_status', ['pending', 'approved', 'rejected', 'cancelled']);
export const inviteStatusEnum = pgEnum('invite_status', ['pending', 'accepted', 'expired', 'revoked']);
export const connectionStatusEnum = pgEnum('connection_status', ['pending', 'active', 'rejected', 'inactive']);
export const caseStatusEnum = pgEnum('case_status', ['received', 'in_design', 'in_milling', 'in_porcelain', 'qc', 'shipped', 'delivered', 'on_hold', 'remake', 'cancelled']);
export const casePriorityEnum = pgEnum('case_priority', ['normal', 'rush']);
export const noteVisibilityEnum = pgEnum('note_visibility', ['internal_lab_only', 'shared_with_provider']);
export const submissionTypeEnum = pgEnum('submission_type', ['note', 'photo', 'video', 'document']);
export const submissionStatusEnum = pgEnum('submission_status', ['pending_review', 'approved', 'rejected']);
export const invoiceStatusEnum = pgEnum('invoice_status', ['draft', 'open', 'partially_paid', 'paid', 'void']);
export const paymentMethodEnum = pgEnum('payment_method', ['card', 'ach', 'check', 'cash', 'other']);

export const users = pgTable('users', {
  id: uuid('id').defaultRandom().primaryKey(),
  email: varchar('email', { length: 320 }).notNull(),
  phone: varchar('phone', { length: 30 }),
  passwordHash: text('password_hash').notNull(),
  firstName: varchar('first_name', { length: 120 }).notNull(),
  lastName: varchar('last_name', { length: 120 }).notNull(),
  initials: varchar('initials', { length: 10 }).notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  mustRotatePassword: boolean('must_rotate_password').default(false).notNull(),
  mfaEnabled: boolean('mfa_enabled').default(false).notNull(),
  lastLoginAt: timestamp('last_login_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  emailUnique: uniqueIndex('users_email_unique').on(sql`lower(${table.email})`)
}));

export const organizations = pgTable('organizations', {
  id: uuid('id').defaultRandom().primaryKey(),
  type: organizationTypeEnum('type').notNull(),
  name: varchar('name', { length: 180 }).notNull(),
  displayName: varchar('display_name', { length: 180 }),
  billingEmail: varchar('billing_email', { length: 320 }),
  phone: varchar('phone', { length: 30 }),
  addressLine1: varchar('address_line_1', { length: 255 }),
  addressLine2: varchar('address_line_2', { length: 255 }),
  city: varchar('city', { length: 120 }),
  state: varchar('state', { length: 50 }),
  zip: varchar('zip', { length: 20 }),
  isActive: boolean('is_active').default(true).notNull(),
  createdByUserId: uuid('created_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
});

export const organizationMemberships = pgTable('organization_memberships', {
  id: uuid('id').defaultRandom().primaryKey(),
  organizationId: uuid('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  role: membershipRoleEnum('role').notNull(),
  status: membershipStatusEnum('status').default('active').notNull(),
  invitedByUserId: uuid('invited_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  approvedByUserId: uuid('approved_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  joinedAt: timestamp('joined_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  uniqueMemberPerOrg: uniqueIndex('memberships_org_user_unique').on(table.organizationId, table.userId),
  orgIdx: index('memberships_org_idx').on(table.organizationId),
  userIdx: index('memberships_user_idx').on(table.userId)
}));

export const organizationJoinRequests = pgTable('organization_join_requests', {
  id: uuid('id').defaultRandom().primaryKey(),
  organizationId: uuid('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  requestedByUserId: uuid('requested_by_user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  requestedRole: membershipRoleEnum('requested_role').notNull(),
  message: text('message'),
  status: joinRequestStatusEnum('status').default('pending').notNull(),
  reviewedByUserId: uuid('reviewed_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  reviewedAt: timestamp('reviewed_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  pendingUnique: uniqueIndex('join_requests_pending_unique').on(table.organizationId, table.requestedByUserId, table.status)
}));

export const organizationInvites = pgTable('organization_invites', {
  id: uuid('id').defaultRandom().primaryKey(),
  organizationId: uuid('organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  email: varchar('email', { length: 320 }).notNull(),
  phone: varchar('phone', { length: 30 }),
  roleToAssign: membershipRoleEnum('role_to_assign').notNull(),
  token: varchar('token', { length: 120 }).notNull(),
  status: inviteStatusEnum('status').default('pending').notNull(),
  invitedByUserId: uuid('invited_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  acceptedByUserId: uuid('accepted_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  acceptedAt: timestamp('accepted_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  tokenUnique: uniqueIndex('organization_invites_token_unique').on(table.token)
}));

export const organizationConnections = pgTable('organization_connections', {
  id: uuid('id').defaultRandom().primaryKey(),
  labOrganizationId: uuid('lab_organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  providerOrganizationId: uuid('provider_organization_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  status: connectionStatusEnum('status').default('pending').notNull(),
  requestedByOrgId: uuid('requested_by_org_id').notNull().references(() => organizations.id, { onDelete: 'cascade' }),
  requestedByUserId: uuid('requested_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  approvedByUserId: uuid('approved_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  approvedAt: timestamp('approved_at', { withTimezone: true }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  uniqueConnection: uniqueIndex('organization_connections_unique').on(table.labOrganizationId, table.providerOrganizationId)
}));

export const cases = pgTable('cases', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseNumber: varchar('case_number', { length: 50 }).notNull(),
  labOrganizationId: uuid('lab_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  providerOrganizationId: uuid('provider_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  patientFirstName: varchar('patient_first_name', { length: 120 }).notNull(),
  patientLastName: varchar('patient_last_name', { length: 120 }).notNull(),
  externalPatientId: varchar('external_patient_id', { length: 120 }),
  doctorName: varchar('doctor_name', { length: 160 }).notNull(),
  status: caseStatusEnum('status').default('received').notNull(),
  priority: casePriorityEnum('priority').default('normal').notNull(),
  dueDate: timestamp('due_date', { withTimezone: true }),
  receivedAt: timestamp('received_at', { withTimezone: true }).defaultNow().notNull(),
  createdByUserId: uuid('created_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  caseNumberUnique: uniqueIndex('cases_case_number_unique').on(table.caseNumber),
  caseLabIdx: index('cases_lab_idx').on(table.labOrganizationId),
  caseProviderIdx: index('cases_provider_idx').on(table.providerOrganizationId)
}));

export const caseRestorations = pgTable('case_restorations', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  toothNumber: varchar('tooth_number', { length: 20 }).notNull(),
  restorationType: varchar('restoration_type', { length: 100 }).notNull(),
  material: varchar('material', { length: 120 }),
  shade: varchar('shade', { length: 60 }),
  notes: text('notes'),
  quantity: integer('quantity').default(1).notNull(),
  unitPrice: decimal('unit_price', { precision: 10, scale: 2 }).default('0.00').notNull(),
  createdAt: createdAt(),
  updatedAt: updatedAt()
});

export const caseEvents = pgTable('case_events', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  eventType: varchar('event_type', { length: 80 }).notNull(),
  actorUserId: uuid('actor_user_id').references(() => users.id, { onDelete: 'set null' }),
  actorOrganizationId: uuid('actor_organization_id').references(() => organizations.id, { onDelete: 'set null' }),
  actorInitials: varchar('actor_initials', { length: 10 }),
  occurredAt: timestamp('occurred_at', { withTimezone: true }).defaultNow().notNull(),
  metadataJson: jsonb('metadata_json').default({}).notNull(),
  createdAt: createdAt()
}, table => ({
  caseEventsIdx: index('case_events_case_idx').on(table.caseId)
}));

export const caseNotes = pgTable('case_notes', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  authorUserId: uuid('author_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  authorOrganizationId: uuid('author_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  noteText: text('note_text').notNull(),
  visibility: noteVisibilityEnum('visibility').default('shared_with_provider').notNull(),
  createdAt: createdAt(),
  updatedAt: updatedAt()
});

export const caseAttachments = pgTable('case_attachments', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  uploadedByUserId: uuid('uploaded_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  uploadedByOrganizationId: uuid('uploaded_by_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  fileName: varchar('file_name', { length: 255 }).notNull(),
  storageKey: varchar('storage_key', { length: 500 }).notNull(),
  fileType: varchar('file_type', { length: 100 }).notNull(),
  visibility: noteVisibilityEnum('visibility').default('shared_with_provider').notNull(),
  createdAt: createdAt()
});

export const caseLocations = pgTable('case_locations', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  locationCode: varchar('location_code', { length: 50 }).notNull(),
  locationName: varchar('location_name', { length: 180 }).notNull(),
  movedByUserId: uuid('moved_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  movedAt: timestamp('moved_at', { withTimezone: true }).defaultNow().notNull(),
  notes: text('notes')
});

export const caseSubmissionQueue = pgTable('case_submission_queue', {
  id: uuid('id').defaultRandom().primaryKey(),
  caseId: uuid('case_id').notNull().references(() => cases.id, { onDelete: 'cascade' }),
  submittedByUserId: uuid('submitted_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  submittedByOrganizationId: uuid('submitted_by_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  submissionType: submissionTypeEnum('submission_type').notNull(),
  payloadJson: jsonb('payload_json').default({}).notNull(),
  status: submissionStatusEnum('status').default('pending_review').notNull(),
  reviewedByUserId: uuid('reviewed_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  reviewedAt: timestamp('reviewed_at', { withTimezone: true }),
  reviewNotes: text('review_notes'),
  createdAt: createdAt(),
  updatedAt: updatedAt()
});

export const invoices = pgTable('invoices', {
  id: uuid('id').defaultRandom().primaryKey(),
  invoiceNumber: varchar('invoice_number', { length: 50 }).notNull(),
  caseId: uuid('case_id').references(() => cases.id, { onDelete: 'set null' }),
  labOrganizationId: uuid('lab_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  providerOrganizationId: uuid('provider_organization_id').notNull().references(() => organizations.id, { onDelete: 'restrict' }),
  status: invoiceStatusEnum('status').default('draft').notNull(),
  subtotal: decimal('subtotal', { precision: 10, scale: 2 }).default('0.00').notNull(),
  tax: decimal('tax', { precision: 10, scale: 2 }).default('0.00').notNull(),
  discount: decimal('discount', { precision: 10, scale: 2 }).default('0.00').notNull(),
  total: decimal('total', { precision: 10, scale: 2 }).default('0.00').notNull(),
  balanceDue: decimal('balance_due', { precision: 10, scale: 2 }).default('0.00').notNull(),
  issuedAt: timestamp('issued_at', { withTimezone: true }),
  dueAt: timestamp('due_at', { withTimezone: true }),
  createdByUserId: uuid('created_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  updatedByUserId: uuid('updated_by_user_id').references(() => users.id, { onDelete: 'set null' }),
  createdAt: createdAt(),
  updatedAt: updatedAt()
}, table => ({
  invoiceNumberUnique: uniqueIndex('invoices_invoice_number_unique').on(table.invoiceNumber)
}));

export const invoiceLineItems = pgTable('invoice_line_items', {
  id: uuid('id').defaultRandom().primaryKey(),
  invoiceId: uuid('invoice_id').notNull().references(() => invoices.id, { onDelete: 'cascade' }),
  caseRestorationId: uuid('case_restoration_id').references(() => caseRestorations.id, { onDelete: 'set null' }),
  description: varchar('description', { length: 255 }).notNull(),
  quantity: integer('quantity').default(1).notNull(),
  unitPrice: decimal('unit_price', { precision: 10, scale: 2 }).default('0.00').notNull(),
  lineTotal: decimal('line_total', { precision: 10, scale: 2 }).default('0.00').notNull(),
  sortOrder: integer('sort_order').default(0).notNull(),
  createdAt: createdAt(),
  updatedAt: updatedAt()
});

export const payments = pgTable('payments', {
  id: uuid('id').defaultRandom().primaryKey(),
  invoiceId: uuid('invoice_id').notNull().references(() => invoices.id, { onDelete: 'cascade' }),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  paymentMethod: paymentMethodEnum('payment_method').notNull(),
  referenceNumber: varchar('reference_number', { length: 120 }),
  paidAt: timestamp('paid_at', { withTimezone: true }).defaultNow().notNull(),
  recordedByUserId: uuid('recorded_by_user_id').notNull().references(() => users.id, { onDelete: 'restrict' }),
  createdAt: createdAt()
});

export const auditLogs = pgTable('audit_logs', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').references(() => users.id, { onDelete: 'set null' }),
  organizationId: uuid('organization_id').references(() => organizations.id, { onDelete: 'set null' }),
  action: varchar('action', { length: 120 }).notNull(),
  entityType: varchar('entity_type', { length: 120 }).notNull(),
  entityId: varchar('entity_id', { length: 120 }),
  ipAddress: varchar('ip_address', { length: 100 }),
  userAgent: text('user_agent'),
  beforeJson: jsonb('before_json'),
  afterJson: jsonb('after_json'),
  metadataJson: jsonb('metadata_json').default({}).notNull(),
  createdAt: createdAt()
}, table => ({
  auditCreatedIdx: index('audit_logs_created_idx').on(table.createdAt)
}));

export const userSessions = pgTable('user_sessions', {
  id: uuid('id').defaultRandom().primaryKey(),
  userId: uuid('user_id').notNull().references(() => users.id, { onDelete: 'cascade' }),
  tokenHash: varchar('token_hash', { length: 128 }).notNull(),
  deviceName: varchar('device_name', { length: 180 }),
  ipAddress: varchar('ip_address', { length: 100 }),
  userAgent: text('user_agent'),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  revokedAt: timestamp('revoked_at', { withTimezone: true }),
  createdAt: createdAt()
}, table => ({
  tokenHashUnique: uniqueIndex('user_sessions_token_hash_unique').on(table.tokenHash)
}));

export const usersRelations = relations(users, ({ many }) => ({
  memberships: many(organizationMemberships)
}));

export const organizationsRelations = relations(organizations, ({ many }) => ({
  memberships: many(organizationMemberships)
}));
