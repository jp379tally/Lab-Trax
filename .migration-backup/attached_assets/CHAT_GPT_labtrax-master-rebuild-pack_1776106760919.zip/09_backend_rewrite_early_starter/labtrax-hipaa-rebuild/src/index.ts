import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import { env } from './config/env.js';
import authRoutes from './routes/auth.js';
import organizationRoutes from './routes/organizations.js';
import caseRoutes from './routes/cases.js';
import invoiceRoutes from './routes/invoices.js';
import reportRoutes from './routes/reports.js';
import { errorHandler } from './middleware/error-handler.js';
import { ok } from './lib/http.js';

const app = express();

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' }
}));
app.use(cors({
  origin: env.APP_ORIGIN,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(morgan(env.NODE_ENV === 'production' ? 'combined' : 'dev'));

app.get('/health', (_req, res) => ok(res, { status: 'ok' }));
app.use('/api/auth', authRoutes);
app.use('/api/organizations', organizationRoutes);
app.use('/api/cases', caseRoutes);
app.use('/api', invoiceRoutes);
app.use('/api/reports', reportRoutes);

app.use(errorHandler);

app.listen(env.PORT, () => {
  console.log(`LabTrax HIPAA backend listening on port ${env.PORT}`);
});
