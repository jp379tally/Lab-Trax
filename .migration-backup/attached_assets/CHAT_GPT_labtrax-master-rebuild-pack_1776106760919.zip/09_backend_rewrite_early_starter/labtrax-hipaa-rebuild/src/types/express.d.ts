import type { users } from '../db/schema.js';

declare global {
  namespace Express {
    interface Request {
      auth?: {
        userId: string;
        sessionId: string;
      };
      user?: typeof users.$inferSelect;
    }
  }
}

export {};
