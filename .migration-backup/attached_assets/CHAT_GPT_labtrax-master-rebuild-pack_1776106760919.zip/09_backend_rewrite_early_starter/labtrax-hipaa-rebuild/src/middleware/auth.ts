import { and, eq, isNull, gt } from 'drizzle-orm';
import type { NextFunction, Request, Response } from 'express';
import { db } from '../db/client.js';
import { userSessions, users } from '../db/schema.js';
import { verifyAccessToken, extractBearerToken } from '../lib/auth.js';
import { HttpError } from '../lib/http.js';

export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const token = extractBearerToken(req);
  if (!token) {
    return next(new HttpError(401, 'Authentication required.'));
  }

  try {
    const payload = verifyAccessToken(token);
    const session = await db.query.userSessions.findFirst({
      where: and(
        eq(userSessions.id, payload.sid),
        eq(userSessions.userId, payload.sub),
        isNull(userSessions.revokedAt),
        gt(userSessions.expiresAt, new Date())
      )
    });

    if (!session) {
      return next(new HttpError(401, 'Session is invalid or expired.'));
    }

    const user = await db.query.users.findFirst({ where: eq(users.id, payload.sub) });
    if (!user || !user.isActive) {
      return next(new HttpError(401, 'User account is inactive.'));
    }

    req.auth = { userId: payload.sub, sessionId: payload.sid };
    req.user = user;
    return next();
  } catch {
    return next(new HttpError(401, 'Invalid access token.'));
  }
}
