import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { HttpError } from '../lib/http.js';

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) {
    return res.status(400).json({ ok: false, error: 'Validation failed.', details: err.flatten() });
  }

  if (err instanceof HttpError) {
    return res.status(err.statusCode).json({ ok: false, error: err.message, details: err.details ?? null });
  }

  console.error(err);
  return res.status(500).json({ ok: false, error: 'Internal server error.' });
}
