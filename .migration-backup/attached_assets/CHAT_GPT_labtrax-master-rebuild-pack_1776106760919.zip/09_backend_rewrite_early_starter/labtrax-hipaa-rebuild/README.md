# LabTrax HIPAA backend rewrite starter

This folder is a backend-first rewrite for the LabTrax data model and permission system.

It is designed to replace the weak parts of the current app architecture:
- plain-text-password auth
- grouping by practice name
- loose lab membership rules
- weak invoice permissions
- missing provider-submission approval queue
- missing audit trail foundation

## What is included
- PostgreSQL + Drizzle schema
- Express API starter
- bcrypt password hashing
- JWT auth with session tracking
- organizations + memberships + invites + join requests
- lab ↔ provider connection model
- cases + restorations + timeline events
- provider submission approval queue
- invoices + line items + payments
- audit log table and helper
- HIPAA-minded communication rules in the code comments and README

## What is not included yet
- your full mobile UI rewrite
- MFA UI and OTP provider integration
- real object storage uploads (S3 / GCS signed URL implementation)
- PDF rendering service
- email/SMS provider integration
- BAA / policy documents

## Important HIPAA note
This code gives you a safer technical foundation, but it does **not by itself** make LabTrax HIPAA compliant.
You still need:
- signed BAAs with each relevant vendor
- secure storage + secure notification providers
- policies, training, retention rules, breach procedures
- production secrets management
- MFA rollout for admin accounts

## Quick start
1. Create a new Replit for the backend or merge these files into your existing repo.
2. Copy `.env.example` to `.env` and fill in the secrets.
3. Run:
   - `npm install`
   - `npm run db:migrate`
   - `npm run dev`
4. Point your Expo app to this backend.

## Suggested rollout order
1. Replace auth + sessions first.
2. Migrate orgs and memberships.
3. Switch case access checks to organization-based rules.
4. Switch invoice generation to `case_restorations`.
5. Add provider submission review in the UI.
6. Add signed file uploads and secure notifications.

## Portal / role shell built into this rewrite
### Lab roles
- owner
- admin
- user
- billing
- read_only

### Provider roles
- owner
- admin
- user
- billing
- read_only

### Key rules
- only owner/admin can approve join requests
- only owner/admin can invite users
- only lab owner/admin/billing can edit invoices or view financial dashboards
- provider submissions do not become official case content until approved
- every sensitive action should be auditable

## API overview
### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/refresh`
- `POST /api/auth/logout`
- `GET /api/auth/me`

### Organizations
- `POST /api/organizations`
- `GET /api/organizations/:organizationId`
- `PATCH /api/organizations/:organizationId`
- `GET /api/organizations/:organizationId/members`
- `POST /api/organizations/:organizationId/invites`
- `POST /api/organizations/:organizationId/join-requests`
- `GET /api/organizations/:organizationId/join-requests`
- `POST /api/organizations/join-requests/:joinRequestId/approve`
- `POST /api/organizations/join-requests/:joinRequestId/reject`
- `POST /api/organizations/connections`
- `POST /api/organizations/connections/:connectionId/approve`
- `PATCH /api/organizations/memberships/:membershipId`

### Cases
- `POST /api/cases`
- `GET /api/cases`
- `GET /api/cases/:caseId`
- `POST /api/cases/:caseId/notes`
- `POST /api/cases/:caseId/location-changes`
- `POST /api/cases/:caseId/submissions`
- `GET /api/cases/:caseId/submissions`
- `POST /api/cases/submissions/:submissionId/approve`
- `POST /api/cases/submissions/:submissionId/reject`

### Invoices / reports
- `POST /api/cases/:caseId/generate-invoice`
- `GET /api/invoices`
- `GET /api/invoices/:invoiceId`
- `PATCH /api/invoices/:invoiceId`
- `POST /api/invoices/:invoiceId/payments`
- `POST /api/invoices/:invoiceId/send-email`
- `GET /api/reports/sales`
- `GET /api/reports/provider-balance/:providerOrganizationId`
- `GET /api/reports/ar-aging`

## Frontend integration reminders
- never trust role checks only in the app UI
- never let provider uploads become official immediately
- only send secure portal links over email/SMS unless you have approved encrypted workflows
- use org IDs everywhere instead of practice name matching
