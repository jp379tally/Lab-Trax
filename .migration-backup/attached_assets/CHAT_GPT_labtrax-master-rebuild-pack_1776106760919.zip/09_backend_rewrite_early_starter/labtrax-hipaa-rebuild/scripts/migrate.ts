import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from '../src/db/client.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function run() {
  const migrationSql = await readFile(path.join(__dirname, '../drizzle/0001_initial.sql'), 'utf8');
  await pool.query(migrationSql);
  console.log('Migration applied.');
  await pool.end();
}

run().catch(async error => {
  console.error(error);
  await pool.end();
  process.exit(1);
});
