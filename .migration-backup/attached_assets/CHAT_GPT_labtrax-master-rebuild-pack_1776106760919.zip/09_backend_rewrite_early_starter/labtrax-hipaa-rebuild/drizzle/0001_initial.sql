CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
  CREATE TYPE organization_type AS ENUM ('lab', 'provider');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE membership_role AS ENUM ('owner', 'admin', 'user', 'billing', 'read_only');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE membership_status AS ENUM ('active', 'pending', 'invited', 'suspended');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE join_request_status AS ENUM ('pending', 'approved', 'rejected', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE invite_status AS ENUM ('pending', 'accepted', 'expired', 'revoked');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE connection_status AS ENUM ('pending', 'active', 'rejected', 'inactive');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE case_status AS ENUM ('received', 'in_design', 'in_milling', 'in_porcelain', 'qc', 'shipped', 'delivered', 'on_hold', 'remake', 'cancelled');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE case_priority AS ENUM ('normal', 'rush');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE note_visibility AS ENUM ('internal_lab_only', 'shared_with_provider');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE submission_type AS ENUM ('note', 'photo', 'video', 'document');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE submission_status AS ENUM ('pending_review', 'approved', 'rejected');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE invoice_status AS ENUM ('draft', 'open', 'partially_paid', 'paid', 'void');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  CREATE TYPE payment_method AS ENUM ('card', 'ach', 'check', 'cash', 'other');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email varchar(320) NOT NULL,
  phone varchar(30),
  password_hash text NOT NULL,
  first_name varchar(120) NOT NULL,
  last_name varchar(120) NOT NULL,
  initials varchar(10) NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  must_rotate_password boolean NOT NULL DEFAULT false,
  mfa_enabled boolean NOT NULL DEFAULT false,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users ((lower(email)));

CREATE TABLE IF NOT EXISTS organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type organization_type NOT NULL,
  name varchar(180) NOT NULL,
  display_name varchar(180),
  billing_email varchar(320),
  phone varchar(30),
  address_line_1 varchar(255),
  address_line_2 varchar(255),
  city varchar(120),
  state varchar(50),
  zip varchar(20),
  is_active boolean NOT NULL DEFAULT true,
  created_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organization_memberships (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role membership_role NOT NULL,
  status membership_status NOT NULL DEFAULT 'active',
  invited_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  approved_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  joined_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS memberships_org_user_unique ON organization_memberships (organization_id, user_id);
CREATE INDEX IF NOT EXISTS memberships_org_idx ON organization_memberships (organization_id);
CREATE INDEX IF NOT EXISTS memberships_user_idx ON organization_memberships (user_id);

CREATE TABLE IF NOT EXISTS organization_join_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  requested_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  requested_role membership_role NOT NULL,
  message text,
  status join_request_status NOT NULL DEFAULT 'pending',
  reviewed_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS organization_invites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email varchar(320) NOT NULL,
  phone varchar(30),
  role_to_assign membership_role NOT NULL,
  token varchar(120) NOT NULL,
  status invite_status NOT NULL DEFAULT 'pending',
  invited_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  expires_at timestamptz NOT NULL,
  accepted_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  accepted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS organization_invites_token_unique ON organization_invites (token);

CREATE TABLE IF NOT EXISTS organization_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lab_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  provider_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  status connection_status NOT NULL DEFAULT 'pending',
  requested_by_org_id uuid NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  requested_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  approved_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT organization_connections_unique UNIQUE (lab_organization_id, provider_organization_id)
);

CREATE TABLE IF NOT EXISTS cases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_number varchar(50) NOT NULL,
  lab_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  provider_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  patient_first_name varchar(120) NOT NULL,
  patient_last_name varchar(120) NOT NULL,
  external_patient_id varchar(120),
  doctor_name varchar(160) NOT NULL,
  status case_status NOT NULL DEFAULT 'received',
  priority case_priority NOT NULL DEFAULT 'normal',
  due_date timestamptz,
  received_at timestamptz NOT NULL DEFAULT now(),
  created_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS cases_case_number_unique ON cases (case_number);
CREATE INDEX IF NOT EXISTS cases_lab_idx ON cases (lab_organization_id);
CREATE INDEX IF NOT EXISTS cases_provider_idx ON cases (provider_organization_id);

CREATE TABLE IF NOT EXISTS case_restorations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  tooth_number varchar(20) NOT NULL,
  restoration_type varchar(100) NOT NULL,
  material varchar(120),
  shade varchar(60),
  notes text,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric(10,2) NOT NULL DEFAULT 0.00,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS case_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  event_type varchar(80) NOT NULL,
  actor_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  actor_organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL,
  actor_initials varchar(10),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS case_events_case_idx ON case_events (case_id);

CREATE TABLE IF NOT EXISTS case_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  author_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  author_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  note_text text NOT NULL,
  visibility note_visibility NOT NULL DEFAULT 'shared_with_provider',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS case_attachments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  uploaded_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  uploaded_by_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  file_name varchar(255) NOT NULL,
  storage_key varchar(500) NOT NULL,
  file_type varchar(100) NOT NULL,
  visibility note_visibility NOT NULL DEFAULT 'shared_with_provider',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS case_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  location_code varchar(50) NOT NULL,
  location_name varchar(180) NOT NULL,
  moved_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  moved_at timestamptz NOT NULL DEFAULT now(),
  notes text
);

CREATE TABLE IF NOT EXISTS case_submission_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id uuid NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
  submitted_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  submitted_by_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  submission_type submission_type NOT NULL,
  payload_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  status submission_status NOT NULL DEFAULT 'pending_review',
  reviewed_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  review_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_number varchar(50) NOT NULL,
  case_id uuid REFERENCES cases(id) ON DELETE SET NULL,
  lab_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  provider_organization_id uuid NOT NULL REFERENCES organizations(id) ON DELETE RESTRICT,
  status invoice_status NOT NULL DEFAULT 'draft',
  subtotal numeric(10,2) NOT NULL DEFAULT 0.00,
  tax numeric(10,2) NOT NULL DEFAULT 0.00,
  discount numeric(10,2) NOT NULL DEFAULT 0.00,
  total numeric(10,2) NOT NULL DEFAULT 0.00,
  balance_due numeric(10,2) NOT NULL DEFAULT 0.00,
  issued_at timestamptz,
  due_at timestamptz,
  created_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  updated_by_user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS invoices_invoice_number_unique ON invoices (invoice_number);

CREATE TABLE IF NOT EXISTS invoice_line_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  case_restoration_id uuid REFERENCES case_restorations(id) ON DELETE SET NULL,
  description varchar(255) NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price numeric(10,2) NOT NULL DEFAULT 0.00,
  line_total numeric(10,2) NOT NULL DEFAULT 0.00,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL,
  payment_method payment_method NOT NULL,
  reference_number varchar(120),
  paid_at timestamptz NOT NULL DEFAULT now(),
  recorded_by_user_id uuid NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE SET NULL,
  organization_id uuid REFERENCES organizations(id) ON DELETE SET NULL,
  action varchar(120) NOT NULL,
  entity_type varchar(120) NOT NULL,
  entity_id varchar(120),
  ip_address varchar(100),
  user_agent text,
  before_json jsonb,
  after_json jsonb,
  metadata_json jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_logs_created_idx ON audit_logs (created_at);

CREATE TABLE IF NOT EXISTS user_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash varchar(128) NOT NULL,
  device_name varchar(180),
  ip_address varchar(100),
  user_agent text,
  expires_at timestamptz NOT NULL,
  revoked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS user_sessions_token_hash_unique ON user_sessions (token_hash);
