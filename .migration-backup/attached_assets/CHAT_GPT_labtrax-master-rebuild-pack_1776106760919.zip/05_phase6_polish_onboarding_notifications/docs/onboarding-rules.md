# Onboarding Rules

## Lab user
- Can create lab
- Becomes owner automatically
- Can invite users
- Can review join requests
- Can connect scanner integrations if owner/admin

## Provider user
- Can create provider office
- Becomes owner automatically
- Can connect to lab
- Can submit case content
- Submitted content is pending until lab admin approves

## Shared rules
- No org access until membership is active
- If user belongs to multiple orgs, require org switcher
- Show role badge on every main dashboard
- Show pending approvals prominently for admins
