# Release Checklist

## Security
- [ ] Production JWT secret set
- [ ] Storage provider configured
- [ ] HTTPS enabled
- [ ] Admin roles reviewed
- [ ] MFA plan scheduled
- [ ] Vendor BAAs confirmed

## Product
- [ ] Lab onboarding complete
- [ ] Provider onboarding complete
- [ ] Invite flow tested
- [ ] Join-request flow tested
- [ ] Case create flow tested
- [ ] Invoice link flow tested
- [ ] Submission approval flow tested
- [ ] Import queue flow tested

## QA
- [ ] Empty states
- [ ] Loading states
- [ ] Error banners
- [ ] Permission denials
- [ ] Role switching
- [ ] Multiple org memberships
