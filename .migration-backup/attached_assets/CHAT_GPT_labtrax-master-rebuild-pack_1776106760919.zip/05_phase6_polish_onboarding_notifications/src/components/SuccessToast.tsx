import React from "react";

type Props = {
  message: string;
};

export default function SuccessToast(_props: Props) {
  return null;
}
