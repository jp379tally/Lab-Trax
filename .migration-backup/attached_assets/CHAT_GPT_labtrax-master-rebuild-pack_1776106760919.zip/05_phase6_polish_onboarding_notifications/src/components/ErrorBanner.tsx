import React from "react";

type Props = {
  message: string;
};

export default function ErrorBanner(_props: Props) {
  return null;
}
