import React from "react";

type Props = {
  title: string;
  body: string;
};

export default function EmptyState(_props: Props) {
  return null;
}
