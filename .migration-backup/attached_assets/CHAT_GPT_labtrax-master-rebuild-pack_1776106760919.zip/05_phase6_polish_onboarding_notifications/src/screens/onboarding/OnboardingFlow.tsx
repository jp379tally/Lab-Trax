import React from "react";

export default function OnboardingFlow() {
  return null;
}

/*
Suggested flow:
1. Welcome
2. Choose portal type: Lab or Provider
3. Create org or join existing
4. Complete profile + initials
5. Invite team members
6. Connect scanner platforms (lab admin only)
7. Create first case
*/
