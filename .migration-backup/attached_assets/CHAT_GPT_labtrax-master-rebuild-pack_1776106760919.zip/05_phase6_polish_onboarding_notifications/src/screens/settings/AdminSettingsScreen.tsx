import React from "react";

export default function AdminSettingsScreen() {
  return null;
}

/*
Suggested sections:
- Organization profile
- Users and roles
- Invites
- Scanner integrations
- Notifications
- Billing and invoices
- Security
*/
