export type PendingCounts = {
  joinRequests: number;
  invites: number;
  submissionReviews: number;
  importQueue: number;
};

export const initialPendingCounts: PendingCounts = {
  joinRequests: 0,
  invites: 0,
  submissionReviews: 0,
  importQueue: 0,
};
