export type NotificationPayload = {
  type:
    | "join_request_received"
    | "invite_received"
    | "submission_pending_review"
    | "submission_approved"
    | "submission_rejected"
    | "invoice_ready"
    | "invoice_payment_received"
    | "case_status_changed";
  title: string;
  body: string;
  data?: Record<string, any>;
};

export async function sendInAppNotification(payload: NotificationPayload) {
  return payload;
}

export async function sendSecureEmailNotice(payload: NotificationPayload) {
  return {
    queued: true,
    note: "Send secure portal notices only. Do not place PHI in plain email body.",
    payload,
  };
}
