
CREATE TABLE scanner_integrations (
  id SERIAL PRIMARY KEY,
  organization_id INTEGER,
  platform TEXT,
  status TEXT,
  access_token TEXT,
  refresh_token TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE scanner_import_jobs (
  id SERIAL PRIMARY KEY,
  organization_id INTEGER,
  platform TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE scanner_import_files (
  id SERIAL PRIMARY KEY,
  job_id INTEGER,
  file_name TEXT,
  file_path TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
