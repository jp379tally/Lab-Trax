# LabTrax Backend with Scanner Integrations

## Features
- HIPAA-ready structure
- Scanner integrations (iTero, 3Shape, Shining)
- Import queue system
- Admin-only controls

## Setup
npm install
npm run dev

## Endpoints
- POST /api/integrations/connect
- GET /api/integrations
- GET /api/integrations/import-queue
- POST /api/integrations/import/:id/approve
