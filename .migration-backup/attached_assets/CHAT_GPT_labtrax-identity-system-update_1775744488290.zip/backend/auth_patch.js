
// simplified example
