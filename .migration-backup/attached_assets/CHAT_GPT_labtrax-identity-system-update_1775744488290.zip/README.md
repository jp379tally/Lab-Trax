LabTrax Identity System Update

Includes:
- Username + Phone authentication
- SMS verification
- Lab uniqueness rules
