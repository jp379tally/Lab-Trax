import { db } from "../server/db";

async function purgeDeletedLabs() {
  const labs = await db.query(
    `
    SELECT id
    FROM organizations
    WHERE type = 'lab'
      AND deleted_at IS NOT NULL
      AND recoverable_until < NOW()
    `
  );

  for (const row of labs.rows) {
    const labId = row.id;

    await db.query("BEGIN");
    try {
      await db.query(
        `DELETE FROM organization_memberships WHERE organization_id = $1`,
        [labId]
      );

      await db.query(
        `DELETE FROM organizations WHERE id = $1`,
        [labId]
      );

      await db.query("COMMIT");
    } catch (error) {
      await db.query("ROLLBACK");
      throw error;
    }
  }
}

purgeDeletedLabs()
  .then(() => {
    console.log("Deleted labs purged");
    process.exit(0);
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
