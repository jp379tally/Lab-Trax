import React, { useEffect, useState } from "react";
import {
  createLab,
  getDeletedLabs,
  restoreLab,
} from "../lib/api/labs";

type Props = {
  token: string;
};

export default function AdminSettingsMyLab({ token }: Props) {
  const [deletedLabs, setDeletedLabs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [newLabName, setNewLabName] = useState("");
  const [phone, setPhone] = useState("");
  const [addressLine1, setAddressLine1] = useState("");
  const [city, setCity] = useState("");
  const [stateValue, setStateValue] = useState("");
  const [zip, setZip] = useState("");

  async function loadDeletedLabs() {
    setLoading(true);
    try {
      const result = await getDeletedLabs(token);
      setDeletedLabs(result.deletedLabs || []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDeletedLabs();
  }, []);

  async function handleCreateLab() {
    await createLab(token, {
      name: newLabName,
      phone,
      addressLine1,
      city,
      state: stateValue,
      zip,
    });

    setNewLabName("");
    setPhone("");
    setAddressLine1("");
    setCity("");
    setStateValue("");
    setZip("");
  }

  async function handleRestoreLab(labId: number) {
    await restoreLab(token, labId);
    await loadDeletedLabs();
  }

  return null;
}
