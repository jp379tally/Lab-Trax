ALTER TABLE organizations
ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ NULL,
ADD COLUMN IF NOT EXISTS recoverable_until TIMESTAMPTZ NULL,
ADD COLUMN IF NOT EXISTS deleted_by_user_id BIGINT NULL REFERENCES users(id);

CREATE INDEX IF NOT EXISTS idx_organizations_deleted_at
ON organizations(deleted_at);

CREATE INDEX IF NOT EXISTS idx_organizations_recoverable_until
ON organizations(recoverable_until);
