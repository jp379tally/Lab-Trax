import { Router } from "express";
import { db } from "../db";
import { requireAuth } from "../middleware/requireAuth";

const router = Router();

async function requireLabAdmin(userId: number, labId: number) {
  const result = await db.query(
    `
    SELECT om.role
    FROM organization_memberships om
    JOIN organizations o ON o.id = om.organization_id
    WHERE om.user_id = $1
      AND om.organization_id = $2
      AND om.status = 'active'
      AND o.type = 'lab'
    `,
    [userId, labId]
  );

  if (result.rowCount === 0) return null;
  const role = result.rows[0].role;
  if (!["owner", "admin"].includes(role)) return null;
  return role;
}

router.post("/api/labs", requireAuth, async (req, res) => {
  const {
    name,
    displayName = null,
    billingEmail = null,
    phone = null,
    addressLine1 = null,
    addressLine2 = null,
    city = null,
    state = null,
    zip = null,
  } = req.body;

  if (!name) {
    return res.status(400).json({ error: "Lab name is required" });
  }

  await db.query("BEGIN");
  try {
    const createdLab = await db.query(
      `
      INSERT INTO organizations
      (
        type,
        name,
        display_name,
        billing_email,
        phone,
        address_line_1,
        address_line_2,
        city,
        state,
        zip,
        is_active,
        created_by_user_id,
        created_at,
        updated_at
      )
      VALUES
      (
        'lab',
        $1,$2,$3,$4,$5,$6,$7,$8,$9,
        true,
        $10,
        NOW(),
        NOW()
      )
      RETURNING *
      `,
      [
        name,
        displayName,
        billingEmail,
        phone,
        addressLine1,
        addressLine2,
        city,
        state,
        zip,
        req.user.id,
      ]
    );

    const lab = createdLab.rows[0];

    await db.query(
      `
      INSERT INTO organization_memberships
      (
        organization_id,
        user_id,
        role,
        status,
        approved_by_user_id,
        joined_at,
        created_at,
        updated_at
      )
      VALUES
      (
        $1,
        $2,
        'owner',
        'active',
        $2,
        NOW(),
        NOW(),
        NOW()
      )
      `,
      [lab.id, req.user.id]
    );

    await db.query("COMMIT");
    return res.status(201).json({ success: true, lab });
  } catch (error) {
    await db.query("ROLLBACK");
    console.error(error);
    return res.status(500).json({ error: "Failed to create lab" });
  }
});

router.delete("/api/labs/:labId", requireAuth, async (req, res) => {
  const labId = Number(req.params.labId);

  const role = await requireLabAdmin(req.user.id, labId);
  if (!role) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const orgResult = await db.query(
    `
    SELECT id, name, deleted_at
    FROM organizations
    WHERE id = $1
      AND type = 'lab'
    `,
    [labId]
  );

  if (orgResult.rowCount === 0) {
    return res.status(404).json({ error: "Lab not found" });
  }

  const lab = orgResult.rows[0];
  if (lab.deleted_at) {
    return res.status(400).json({ error: "Lab is already deleted" });
  }

  const result = await db.query(
    `
    UPDATE organizations
    SET
      deleted_at = NOW(),
      recoverable_until = NOW() + INTERVAL '30 days',
      deleted_by_user_id = $2,
      updated_at = NOW()
    WHERE id = $1
    RETURNING id, name, deleted_at, recoverable_until
    `,
    [labId, req.user.id]
  );

  return res.json({ success: true, lab: result.rows[0] });
});

router.post("/api/labs/:labId/restore", requireAuth, async (req, res) => {
  const labId = Number(req.params.labId);

  const membership = await db.query(
    `
    SELECT om.role
    FROM organization_memberships om
    JOIN organizations o ON o.id = om.organization_id
    WHERE om.user_id = $1
      AND om.organization_id = $2
      AND om.status = 'active'
      AND o.type = 'lab'
    `,
    [req.user.id, labId]
  );

  if (membership.rowCount === 0) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const role = membership.rows[0].role;
  if (!["owner", "admin"].includes(role)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const labResult = await db.query(
    `
    SELECT id, name, deleted_at, recoverable_until
    FROM organizations
    WHERE id = $1
      AND type = 'lab'
    `,
    [labId]
  );

  if (labResult.rowCount === 0) {
    return res.status(404).json({ error: "Lab not found" });
  }

  const lab = labResult.rows[0];

  if (!lab.deleted_at) {
    return res.status(400).json({ error: "Lab is not deleted" });
  }

  if (lab.recoverable_until && new Date(lab.recoverable_until) < new Date()) {
    return res.status(400).json({ error: "Recovery window expired" });
  }

  const restored = await db.query(
    `
    UPDATE organizations
    SET
      deleted_at = NULL,
      recoverable_until = NULL,
      deleted_by_user_id = NULL,
      updated_at = NOW()
    WHERE id = $1
    RETURNING id, name
    `,
    [labId]
  );

  return res.json({ success: true, lab: restored.rows[0] });
});

router.get("/api/my-labs/deleted", requireAuth, async (req, res) => {
  const result = await db.query(
    `
    SELECT
      o.id,
      o.name,
      o.display_name,
      o.deleted_at,
      o.recoverable_until,
      om.role
    FROM organizations o
    JOIN organization_memberships om
      ON om.organization_id = o.id
    WHERE om.user_id = $1
      AND om.status = 'active'
      AND om.role IN ('owner', 'admin')
      AND o.type = 'lab'
      AND o.deleted_at IS NOT NULL
      AND (
        o.recoverable_until IS NULL
        OR o.recoverable_until >= NOW()
      )
    ORDER BY o.deleted_at DESC
    `,
    [req.user.id]
  );

  return res.json({ deletedLabs: result.rows });
});

export default router;
