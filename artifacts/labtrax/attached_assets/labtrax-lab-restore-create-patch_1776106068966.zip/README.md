# LabTrax Lab Restore + Create Patch

This drag-and-drop patch adds:

1. Create Lab after account creation
2. Soft-delete Lab with 30-day recovery window
3. Restore deleted Lab from Admin Settings > My Lab
4. Deleted labs listing endpoint for admin users
5. Purge script for deleted labs after recovery window expires

## Apply order

1. Run `sql/lab_restore_create_patch.sql`
2. Merge `server/routes/labs.ts` into your Express app
3. Merge `lib/api/labs.ts` into your frontend API layer
4. Hook `components/AdminSettingsMyLab.tsx` into Admin Settings > My Lab
5. Add the purge script to a scheduled job if desired

## Endpoints

- `POST /api/labs`
- `DELETE /api/labs/:labId`
- `POST /api/labs/:labId/restore`
- `GET /api/my-labs/deleted`

## Notes

- Deleting a lab does NOT delete the user account.
- Deleted labs remain recoverable for 30 days.
- Only active owner/admin users can delete or restore labs.
- Deleted labs should be hidden from normal active-lab queries.
