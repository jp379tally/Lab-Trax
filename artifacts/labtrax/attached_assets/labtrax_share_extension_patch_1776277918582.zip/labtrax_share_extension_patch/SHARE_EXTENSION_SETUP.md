# LabTrax iPhone Share Sheet Integration Patch

This patch is for making **LabTrax appear in the iPhone share sheet** so a user can share screenshots, images, PDFs, and other files into the app.

## What this does

- Adds a real **iOS Share Extension** target for LabTrax
- Accepts images, PDFs, text, URLs, and generic files from the iPhone share sheet
- Saves the shared payload into an **App Group** container
- Opens the main LabTrax app through a deep link
- Lets the main app read the shared payload and route it into a screen like **Import / New Case / Attach to Case**

## Important note

For iOS, the reliable way to show up in the share sheet is to add a **native Share Extension target**. Expo documents app extensions through EAS Build, and also notes that receiving shared content through `expo-sharing` on iOS is experimental and opens the main target instead of a true share extension, which is not officially supported by Apple. That is why this patch uses a real iOS share extension. citeturn965581search0turn965581search3turn965581search6turn965581search1

## Replit integration steps

1. **Make sure your project has an `ios/` directory**.
   - If you are using Expo managed workflow, run prebuild first:
     - `npx expo prebuild -p ios`
2. In Xcode, open `ios/*.xcworkspace`.
3. Add a new target:
   - `File` -> `New` -> `Target` -> `iOS` -> `Share Extension`
   - Name it `LabTraxShare`
4. Replace the generated files with the files from this patch:
   - `ios/LabTraxShare/ShareViewController.swift`
   - `ios/LabTraxShare/Info.plist`
   - `ios/LabTraxShare/LabTraxShare.entitlements`
5. Add the same **App Group** entitlement to the main app target and the share extension target:
   - `group.com.labtrax.shared`
   - If your bundle id is different, keep the app group consistent across both targets.
6. Add the URL scheme to the main app so the extension can open it:
   - See the `app.config.ts.example` file in this patch.
7. Copy the JS files into your app:
   - `app/+native-intent.ts`
   - `src/lib/sharedInbox.ts`
   - `src/screens/ShareInboxScreen.tsx`
8. Add a route/screen in your app that uses `ShareInboxScreen`.
9. Build with EAS or Xcode.

## Recommended user flow

When a user shares a screenshot from Photos:
- Tap Share
- Tap **LabTrax**
- The share extension stores the file metadata in the shared app group
- The extension opens `labtrax://share-inbox`
- The main app opens a screen that reads the shared payload
- The user chooses:
  - Create new case
  - Attach to existing case
  - Save to import queue

## File types currently accepted

The share extension is configured for:
- images
- PDFs
- plain text
- URLs
- generic files/data

## Notes

- This patch does **not** edit your Xcode project automatically.
- It gives you the real files to drop into your project and wire up.
- If you want, the next step is to merge this directly into your current LabTrax source tree and wire it to your case intake flow.
