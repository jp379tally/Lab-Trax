import { NativeModules, Platform } from 'react-native';

export type SharedInboxItem = {
  type: string;
  uri?: string;
  text?: string;
  name?: string;
  source?: string;
};

type NativeShareInboxModule = {
  getSharedItems: () => Promise<SharedInboxItem[]>;
  clearSharedItems: () => Promise<void>;
};

const moduleRef = NativeModules.LabTraxShareInbox as NativeShareInboxModule | undefined;

export async function getSharedInboxItems(): Promise<SharedInboxItem[]> {
  if (Platform.OS !== 'ios' || !moduleRef?.getSharedItems) {
    return [];
  }
  return moduleRef.getSharedItems();
}

export async function clearSharedInboxItems(): Promise<void> {
  if (Platform.OS !== 'ios' || !moduleRef?.clearSharedItems) {
    return;
  }
  await moduleRef.clearSharedItems();
}
