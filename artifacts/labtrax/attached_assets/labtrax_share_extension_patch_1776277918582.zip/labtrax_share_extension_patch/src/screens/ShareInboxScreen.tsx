import React, { useCallback, useEffect, useState } from 'react';
import { Alert, FlatList, Pressable, Text, View } from 'react-native';
import { clearSharedInboxItems, getSharedInboxItems, SharedInboxItem } from '../lib/sharedInbox';

export default function ShareInboxScreen() {
  const [items, setItems] = useState<SharedInboxItem[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const nextItems = await getSharedInboxItems();
      setItems(nextItems);
    } catch (err: any) {
      Alert.alert('Share Inbox Error', err?.message || 'Failed to load shared items.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleClear() {
    await clearSharedInboxItems();
    setItems([]);
  }

  function handleCreateCase(item: SharedInboxItem) {
    Alert.alert('Next step', `Wire this item into your case intake flow: ${item.name || item.text || item.uri || item.type}`);
  }

  return (
    <View style={{ flex: 1, padding: 20, backgroundColor: '#fff' }}>
      <Text style={{ fontSize: 28, fontWeight: '700', marginBottom: 8 }}>Shared to LabTrax</Text>
      <Text style={{ fontSize: 15, color: '#667085', marginBottom: 20 }}>
        Screenshots, PDFs, links, and files shared from iPhone appear here.
      </Text>

      {loading ? <Text>Loading…</Text> : null}

      <FlatList
        data={items}
        keyExtractor={(item, index) => `${item.uri || item.text || item.name || item.type}-${index}`}
        contentContainerStyle={{ gap: 12 }}
        renderItem={({ item }) => (
          <View style={{ borderWidth: 1, borderColor: '#E4E7EC', borderRadius: 14, padding: 14 }}>
            <Text style={{ fontWeight: '600' }}>{item.name || item.type}</Text>
            {item.text ? <Text style={{ marginTop: 6 }}>{item.text}</Text> : null}
            {item.uri ? <Text style={{ marginTop: 6, color: '#475467' }}>{item.uri}</Text> : null}

            <View style={{ flexDirection: 'row', gap: 10, marginTop: 12 }}>
              <Pressable
                onPress={() => handleCreateCase(item)}
                style={{ backgroundColor: '#111827', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10 }}
              >
                <Text style={{ color: '#fff', fontWeight: '600' }}>Use in case</Text>
              </Pressable>
            </View>
          </View>
        )}
        ListEmptyComponent={!loading ? <Text>No shared items found.</Text> : null}
      />

      <Pressable
        onPress={handleClear}
        style={{ marginTop: 16, alignSelf: 'flex-start', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 10, backgroundColor: '#F2F4F7' }}
      >
        <Text style={{ fontWeight: '600' }}>Clear inbox</Text>
      </Pressable>
    </View>
  );
}
