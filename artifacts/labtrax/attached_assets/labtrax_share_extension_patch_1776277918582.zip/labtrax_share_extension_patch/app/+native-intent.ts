export async function redirectSystemPath({ path }: { path: string; initial: boolean }) {
  if (path.startsWith('labtrax://share-inbox')) {
    return '/share-inbox';
  }
  return path;
}
