import UIKit
import UniformTypeIdentifiers
import MobileCoreServices

final class ShareViewController: UIViewController {
  private let appGroupId = "group.com.labtrax.shared"
  private let userDefaultsKey = "LabTraxSharedItems"
  private let openURLString = "labtrax://share-inbox"

  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    handleShare()
  }

  private func handleShare() {
    guard let extensionItems = extensionContext?.inputItems as? [NSExtensionItem], !extensionItems.isEmpty else {
      completeRequest()
      return
    }

    let dispatchGroup = DispatchGroup()
    var payloads: [[String: Any]] = []

    for item in extensionItems {
      guard let attachments = item.attachments else { continue }
      for provider in attachments {
        dispatchGroup.enter()
        loadItem(from: provider) { payload in
          if let payload = payload {
            payloads.append(payload)
          }
          dispatchGroup.leave()
        }
      }
    }

    dispatchGroup.notify(queue: .main) {
      self.persist(payloads: payloads)
      self.openHostApp()
    }
  }

  private func loadItem(from provider: NSItemProvider, completion: @escaping ([String: Any]?) -> Void) {
    let supportedTypes: [UTType] = [
      .image,
      .pdf,
      .movie,
      .url,
      .plainText,
      .data,
      .content
    ]

    guard let matchedType = supportedTypes.first(where: { provider.hasItemConformingToTypeIdentifier($0.identifier) }) else {
      completion(nil)
      return
    }

    provider.loadItem(forTypeIdentifier: matchedType.identifier, options: nil) { item, error in
      guard error == nil else {
        completion(nil)
        return
      }

      if let url = item as? URL {
        let destination = self.copyToAppGroup(url: url)
        completion([
          "type": matchedType.identifier,
          "uri": destination?.absoluteString ?? url.absoluteString,
          "name": url.lastPathComponent,
          "source": "share-extension"
        ])
        return
      }

      if let text = item as? String {
        completion([
          "type": matchedType.identifier,
          "text": text,
          "source": "share-extension"
        ])
        return
      }

      if let image = item as? UIImage,
         let data = image.jpegData(compressionQuality: 0.92) {
        let filename = "shared_\(UUID().uuidString).jpg"
        let fileURL = self.writeDataToAppGroup(data: data, filename: filename)
        completion([
          "type": UTType.image.identifier,
          "uri": fileURL?.absoluteString ?? "",
          "name": filename,
          "source": "share-extension"
        ])
        return
      }

      if let data = item as? Data {
        let filename = "shared_\(UUID().uuidString).bin"
        let fileURL = self.writeDataToAppGroup(data: data, filename: filename)
        completion([
          "type": matchedType.identifier,
          "uri": fileURL?.absoluteString ?? "",
          "name": filename,
          "source": "share-extension"
        ])
        return
      }

      completion(nil)
    }
  }

  private func persist(payloads: [[String: Any]]) {
    guard let defaults = UserDefaults(suiteName: appGroupId) else { return }
    let existing = defaults.array(forKey: userDefaultsKey) as? [[String: Any]] ?? []
    defaults.set(existing + payloads, forKey: userDefaultsKey)
    defaults.synchronize()
  }

  private func copyToAppGroup(url: URL) -> URL? {
    guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupId) else {
      return nil
    }

    let destinationDir = container.appendingPathComponent("SharedInbox", isDirectory: true)
    try? FileManager.default.createDirectory(at: destinationDir, withIntermediateDirectories: true)

    let destination = destinationDir.appendingPathComponent("\(UUID().uuidString)-\(url.lastPathComponent)")

    do {
      if FileManager.default.fileExists(atPath: destination.path) {
        try FileManager.default.removeItem(at: destination)
      }
      try FileManager.default.copyItem(at: url, to: destination)
      return destination
    } catch {
      return nil
    }
  }

  private func writeDataToAppGroup(data: Data, filename: String) -> URL? {
    guard let container = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: appGroupId) else {
      return nil
    }

    let destinationDir = container.appendingPathComponent("SharedInbox", isDirectory: true)
    try? FileManager.default.createDirectory(at: destinationDir, withIntermediateDirectories: true)

    let destination = destinationDir.appendingPathComponent(filename)
    do {
      try data.write(to: destination, options: .atomic)
      return destination
    } catch {
      return nil
    }
  }

  private func openHostApp() {
    guard let url = URL(string: openURLString) else {
      completeRequest()
      return
    }

    var responder: UIResponder? = self
    while responder != nil {
      if let application = responder as? UIApplication {
        application.performSelector(onMainThread: Selector(("openURL:")), with: url, waitUntilDone: false)
        break
      }
      responder = responder?.next
    }

    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
      self.completeRequest()
    }
  }

  private func completeRequest() {
    extensionContext?.completeRequest(returningItems: [], completionHandler: nil)
  }
}
