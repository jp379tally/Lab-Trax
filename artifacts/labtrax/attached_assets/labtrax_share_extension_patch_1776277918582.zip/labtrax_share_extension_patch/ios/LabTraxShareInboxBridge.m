#import <React/RCTBridgeModule.h>

@interface RCT_EXTERN_MODULE(LabTraxShareInbox, NSObject)
RCT_EXTERN_METHOD(getSharedItems:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
RCT_EXTERN_METHOD(clearSharedItems:(RCTPromiseResolveBlock)resolve rejecter:(RCTPromiseRejectBlock)reject)
@end
