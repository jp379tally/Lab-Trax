import Foundation

@objc(LabTraxShareInbox)
class LabTraxShareInbox: NSObject {
  private let appGroupId = "group.com.labtrax.shared"
  private let userDefaultsKey = "LabTraxSharedItems"

  @objc
  func getSharedItems(_ resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    guard let defaults = UserDefaults(suiteName: appGroupId) else {
      resolve([])
      return
    }
    let items = defaults.array(forKey: userDefaultsKey) as? [[String: Any]] ?? []
    resolve(items)
  }

  @objc
  func clearSharedItems(_ resolve: RCTPromiseResolveBlock, rejecter reject: RCTPromiseRejectBlock) {
    guard let defaults = UserDefaults(suiteName: appGroupId) else {
      resolve(nil)
      return
    }
    defaults.removeObject(forKey: userDefaultsKey)
    defaults.synchronize()
    resolve(nil)
  }

  @objc
  static func requiresMainQueueSetup() -> Bool {
    false
  }
}
